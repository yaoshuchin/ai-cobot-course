extends RefCounted
# 教學核心：RGB 手算 HSV → 顏色遮罩 → 四方向連通區域 → 面積與重心。
var mask: Image

func hsv(c: Color) -> Vector3:
	var hi: float = maxf(c.r, maxf(c.g, c.b))
	var lo: float = minf(c.r, minf(c.g, c.b))
	var d: float = hi - lo
	var h: float = 0.0
	if d > 0.00001:
		if hi == c.r:
			h = 60.0 * fposmod((c.g - c.b) / d, 6.0)
		elif hi == c.g:
			h = 60.0 * ((c.b - c.r) / d + 2.0)
		else:
			h = 60.0 * ((c.r - c.g) / d + 4.0)
	return Vector3(h, d / hi if hi > 0 else 0.0, hi)

func matches(p: Vector3, rule: Dictionary) -> bool:
	var h: Array = rule.h
	var hue_ok: bool = (p.x >= h[0] and p.x <= h[1]) if h[0] <= h[1] else (p.x >= h[0] or p.x <= h[1])
	return hue_ok and p.y >= rule.s[0] and p.y <= rule.s[1] and p.z >= rule.v[0] and p.z <= rule.v[1]

func detect(img: Image, cfg: Dictionary) -> Array:
	var w: int = img.get_width()
	var h: int = img.get_height()
	var labels: PackedInt32Array = PackedInt32Array()
	labels.resize(w * h)
	labels.fill(-1)
	var colors: Array = cfg.colors.keys()
	mask = Image.create(w, h, false, Image.FORMAT_RGB8)
	mask.fill(Color.BLACK)
	# 每一格像素獨立判斷，不讀取 3D 物件名稱或位置。
	for y in range(h):
		for x in range(w):
			var p: Vector3 = hsv(img.get_pixel(x, y))
			for k in range(colors.size()):
				if matches(p, cfg.colors[colors[k]]):
					labels[y * w + x] = k
					mask.set_pixel(x, y, Color.WHITE)
					break
	var result: Array = []
	var ids: Array = []
	ids.resize(colors.size())
	ids.fill(0)
	for start in range(w * h):
		var k: int = labels[start]
		if k < 0:
			continue
		# BFS：相鄰、同色的白點才屬於同一物件，斜角不相連。
		var queue: PackedInt32Array = PackedInt32Array([start])
		labels[start] = -1
		var head: int = 0
		var sum_x: float = 0.0
		var sum_y: float = 0.0
		var min_x: int = w
		var min_y: int = h
		var max_x: int = 0
		var max_y: int = 0
		while head < queue.size():
			var i: int = queue[head]
			head += 1
			var x: int = i % w
			var y: int = floori(float(i) / w)
			sum_x += x
			sum_y += y
			min_x = mini(min_x, x)
			max_x = maxi(max_x, x)
			min_y = mini(min_y, y)
			max_y = maxi(max_y, y)
			for n in [i - 1, i + 1, i - w, i + w]:
				if n < 0 or n >= w * h:
					continue
				if absi(n % w - x) + absi(n / w - y) != 1:
					continue
				if labels[n] == k:
					labels[n] = -1
					queue.append(n)
		if queue.size() >= int(cfg.min_area):
			ids[k] += 1
			result.append({"color":colors[k],"id":ids[k],"rect":Rect2(min_x,min_y,max_x-min_x+1,max_y-min_y+1),"center":Vector2(sum_x,sum_y)/queue.size(),"area":queue.size()})
	return result
