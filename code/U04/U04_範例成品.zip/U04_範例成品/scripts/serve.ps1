﻿$root = Split-Path $PSScriptRoot -Parent
& (Join-Path $PSScriptRoot '本機測試網頁版.ps1') -Dir (Join-Path $root '網頁版')
