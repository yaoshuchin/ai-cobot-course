extends Node
# 主程式：安全讀設定、定時取相機圖像，以及不依賴渲染的自我測試。
const Vision = preload("res://vision.gd")
const World = preload("res://scene3d.gd")
const Hud = preload("res://hud.gd")
var vision: RefCounted = Vision.new()
var world: Node3D
var hud: Control
var vc: Dictionary
var sc: Dictionary
var rc: Dictionary
var notices: Array[String] = []
var timer: float = 0
var elapsed: float = 0
var demo: bool = false
var captured: bool = false
var demo_rearrange: int = 0
var demo_mask: int = 0

func read_config(path: String, fallback: Dictionary) -> Dictionary:
	if FileAccess.file_exists(path):
		var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
		if raw is Dictionary and valid_config(path,raw):
			return raw
	notices.append("設定讀不到或格式不合：%s，已用預設值。" % path.get_file())
	return fallback.duplicate(true)

func valid_config(path: String, data: Dictionary) -> bool:
	if path.ends_with("vision.json"):
		if not (data.get("camera_width") is float or data.get("camera_width") is int) or not data.get("colors") is Dictionary:
			return false
		if float(data.camera_width)<32 or float(data.camera_width)>1280 or float(data.get("camera_height",0))<32 or float(data.get("camera_height",0))>960 or float(data.get("update_seconds",0))<0.05 or float(data.get("min_area",0))<1:
			return false
		if data.colors.is_empty():
			return false
		for key in data.colors:
			if not data.colors.get(key) is Dictionary:
				return false
			for part in ["h","s","v"]:
				var bounds: Variant = data.colors[key].get(part)
				if not bounds is Array or bounds.size()!=2:
					return false
				for value in bounds:
					if not (value is float or value is int) or value<0 or value>(360 if part=="h" else 1):
						return false
			if not Color.html_is_valid(str(data.colors[key].get("draw","#FFFFFF"))):
				return false
		return true
	if path.ends_with("scene.json"):
		if not (data.get("table_size") is Array and data.table_size.size()==2 and data.get("objects") is Array and data.get("shapes") is Array and not data.shapes.is_empty() and data.get("object_colors") is Dictionary and is_number(data.get("seed"))):
			return false
		for dimension in data.table_size:
			if not is_number(dimension) or float(dimension)<4 or float(dimension)>30:
				return false
		for kind in data.shapes:
			if kind not in ["box","sphere","cylinder"]:
				return false
		for group in data.objects:
			if not group is Dictionary or not group.get("color") is String or not is_number(group.get("count")):
				return false
			if group.count<0 or group.count>30 or not data.object_colors.get(group.color) is String or not Color.html_is_valid(data.object_colors[group.color]):
				return false
		return true
	return data.get("name") is String and data.get("body_color") is String and Color.html_is_valid(data.body_color) and data.get("accent_color") is String and Color.html_is_valid(data.accent_color) and is_number(data.get("speed")) and is_number(data.get("turn_speed")) and data.speed>0 and data.turn_speed>0

func is_number(value: Variant) -> bool:
	return value is float or value is int

func _ready() -> void:
	vc = read_config("res://vision.json",{"camera_width":320,"camera_height":240,"update_seconds":0.2,"min_area":40,"colors":{"紅":{"h":[340,20],"s":[0.45,1],"v":[0.35,1],"draw":"#FF554D"},"綠":{"h":[90,160],"s":[0.4,1],"v":[0.3,1],"draw":"#67EC8B"},"藍":{"h":[200,250],"s":[0.45,1],"v":[0.3,1],"draw":"#5EB7FF"},"黃":{"h":[40,70],"s":[0.55,1],"v":[0.5,1],"draw":"#FFDE3B"}}})
	sc = read_config("res://scene.json",{"table_size":[8,8],"objects":[{"color":"紅","count":3},{"color":"綠","count":3},{"color":"藍","count":3},{"color":"黃","count":3}],"shapes":["box","sphere","cylinder"],"object_colors":{"紅":"#E53935","綠":"#43BB47","藍":"#1E88E5","黃":"#FDD835"},"seed":7})
	rc = read_config("res://robot.json",{"name":"小眼","body_color":"#ECEFF1","accent_color":"#FFB347","speed":2.0,"turn_speed":1.6})
	if "--self-test" in OS.get_cmdline_user_args():
		self_test()
		return
	demo = "--demo" in OS.get_cmdline_user_args()
	world = World.new()
	add_child(world)
	world.setup(sc,rc,vc)
	var layer: CanvasLayer = CanvasLayer.new()
	add_child(layer)
	hud = Hud.new()
	layer.add_child(hud)
	hud.setup(vc,world)
	hud.rearrange_requested.connect(world.rearrange)
	if not notices.is_empty():
		hud.status.text = "\n".join(notices)
	if "--qa" in OS.get_cmdline_user_args():
		run_qa()

func _process(delta: float) -> void:
	if world == null:
		return
	elapsed += delta
	world.move_robot(delta,demo,elapsed)
	if demo:
		var block: int = int(elapsed/8)
		if block != demo_rearrange:
			demo_rearrange = block
			world.rearrange()
		hud.masked = int(elapsed/5)%2 == 1
		hud.title.text = "示範中：機器人正在找%s色物件" % vc.colors.keys()[int(elapsed/5)%vc.colors.size()]
	timer += delta
	if timer < float(vc.update_seconds) or DisplayServer.get_name()=="headless":
		return
	timer = 0
	var image: Image = world.viewport.get_texture().get_image()
	if image == null or image.is_empty():
		return
	var found: Array = vision.detect(image,vc)
	hud.display(world.viewport.get_texture(),vision.mask,found)
	# 實測必須來自相機渲染，不以場景中積木數量冒充結果。
	if not captured and elapsed>2:
		captured = true
		var totals: Dictionary = {}
		for color_name in vc.colors:
			totals[color_name] = 0
		for item in found:
			totals[item.color] = totals.get(item.color,0)+1
		print("CAMERA_COUNTS ",JSON.stringify(totals))
		if "--capture" in OS.get_cmdline_user_args():
			image.save_png("res://.test-data/相機實測.png")
			vision.mask.save_png("res://.test-data/遮罩實測.png")
			var file: FileAccess = FileAccess.open("res://.test-data/相機實測.json",FileAccess.WRITE)
			file.store_string(JSON.stringify({"counts":totals,"objects":found},"  "))
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png("res://.test-data/教具畫面.png")
			get_tree().quit()

func self_test() -> void:
	var image: Image = Image.create(320,240,false,Image.FORMAT_RGB8)
	image.fill(Color("202020"))
	image.fill_rect(Rect2i(20,20,30,30),Color.RED)
	image.fill_rect(Rect2i(100,30,40,20),Color.RED)
	image.fill_rect(Rect2i(240,160,30,30),Color.BLUE)
	for y in range(90,131):
		for x in range(140,181):
			if Vector2(x-160,y-110).length()<=20:
				image.set_pixel(x,y,Color.GREEN)
	for i in range(3):
		image.fill_rect(Rect2i(5+i*10,210,i+1,1),Color.RED)
	image.fill_rect(Rect2i(30,140,20,20),Color.YELLOW)
	image.fill_rect(Rect2i(70,140,20,20),Color.YELLOW)
	image.fill_rect(Rect2i(110,140,20,20),Color.YELLOW)
	image.set_pixel(300,220,Color.YELLOW)
	var found: Array = vision.detect(image,vc)
	var expected: Array = [["紅",Vector2(34.5,34.5)],["紅",Vector2(119.5,39.5)],["綠",Vector2(160,110)],["藍",Vector2(254.5,174.5)]]
	expected.append_array([["黃",Vector2(39.5,149.5)],["黃",Vector2(79.5,149.5)],["黃",Vector2(119.5,149.5)]])
	var ok: bool = found.size()==7 and notices.is_empty()
	for target in expected:
		var matched: bool = false
		for item in found:
			if item.color==target[0] and item.center.distance_to(target[1])<=2:
				matched = true
		ok = ok and matched
	# 驗證缺檔與壞格式會退回預設設定，而不是當掉。
	var fallback: Dictionary = read_config("user://missing-vision.json",vc)
	ok = ok and fallback==vc and not valid_config("vision.json",{})
	print("SELF_TEST PASS 紅2 綠1 藍1 黃3；中心誤差≤2像素；1～3像素雜點已過濾；三份設定與缺檔回復通過" if ok else "SELF_TEST FAIL 數量、中心或設定不符："+str(found))
	get_tree().quit(0 if ok else 1)

func run_qa() -> void:
	# 渲染測試另行執行：直接讀真實相機，不用合成測試圖代替。
	await get_tree().create_timer(3).timeout
	var report: Dictionary = {}
	var image: Image = world.viewport.get_texture().get_image()
	var initial: Array = vision.detect(image,vc)
	report["預設找到十二個物件"] = initial.size()==12
	for color_name in vc.colors:
		report["相機找到%s色三個" % color_name] = initial.filter(func(item: Dictionary) -> bool: return item.color==color_name).size()==3
	report["相機畫面至少佔一半寬度"] = hud.image_view.size.x>=hud.get_viewport_rect().size.x*0.5
	report["黃色畫框來自設定檔"] = hud.overlay.color_rules["黃"].draw=="#FFDE3B"
	hud.select.select(3)
	hud.sync_sliders()
	hud.sliders[0].value = 50
	report["黃色滑桿與目前顏色標示"] = vc.colors["黃"].h[0]==50 and hud.color_heading.text=="目前調整：黃色"
	hud.reset_button.pressed.emit()
	report["按鈕還原黃色門檻"] = vc.colors["黃"]==hud.defaults.colors["黃"] and hud.sliders[0].value==40
	hud.select.select(0)
	hud.sync_sliders()
	report["門檻與還原按鈕開啟即見"] = hud.reset_button.get_global_rect().end.y<hud.panel.get_global_rect().end.y and hud.sliders[0].global_position.y>=hud.panel.global_position.y
	vc.colors["紅"].s = [0.99,1.0]
	var narrow: Array = vision.detect(image,vc)
	report["門檻太窄會漏掉紅色"] = narrow.filter(func(item: Dictionary) -> bool: return item.color=="紅").is_empty()
	vc.colors["紅"].h = [0,360]
	vc.colors["紅"].s = [0,1]
	vc.colors["紅"].v = [0,1]
	var wide: Array = vision.detect(image,vc)
	report["門檻太寬整張圖合成一塊"] = wide.size()==1 and wide[0].area==image.get_width()*image.get_height()
	vc.colors = hud.defaults.colors.duplicate(true)
	hud.sync_sliders()
	hud.sliders[0].value = 330
	report["滑桿立即更改規則"] = vc.colors["紅"].h[0]==330
	vc.colors = hud.defaults.colors.duplicate(true)
	hud.sync_sliders()
	var before: Vector3 = world.robot.position
	world.touch = Vector2.LEFT
	world.move_robot(0.2,false,0)
	world.touch = Vector2.ZERO
	report["方向按鈕移動小眼"] = world.robot.position.x<before.x
	var angle: float = world.head.rotation.y
	world.turn_touch = 1
	world.move_robot(0.2,false,0)
	world.turn_touch = 0
	report["轉頭改變相機方向"] = world.head.rotation.y>angle
	world.robot.position = before
	world.head.rotation.y = 0
	hud.masked = true
	await get_tree().create_timer(0.5).timeout
	report["遮罩畫面已切換"] = hud.image_view.texture is ImageTexture
	hud.enlarged = true
	hud.layout_ui()
	report["放大視角隱藏側欄"] = not hud.panel.visible and hud.image_view.size.x>500
	hud.enlarged = false
	hud.masked = false
	hud.layout_ui()
	world.rearrange()
	report["重新擺放仍有十二個物件"] = world.objects.get_child_count()==12
	world.move_robot(0.1,true,10)
	report["示範模式自動移動"] = world.robot.position.distance_to(before)>0.1
	var file: FileAccess = FileAccess.open("res://.test-data/互動檢查.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"  "))
	var ok: bool = not report.values().has(false)
	print("INTERACTION_QA ",JSON.stringify(report))
	get_tree().quit(0 if ok else 1)
