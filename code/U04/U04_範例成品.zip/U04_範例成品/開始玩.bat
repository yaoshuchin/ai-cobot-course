@echo off
cd /d "%~dp0"
set "G="
for %%F in ("..\Godot\Godot_v4*_win64.exe") do if exist "%%~F" if not defined G set "G=%%~fF"
if not defined G (echo Godot not found & pause & exit /b 1)
start "" "%G%" --path "%~dp0" --audio-driver Dummy %*
