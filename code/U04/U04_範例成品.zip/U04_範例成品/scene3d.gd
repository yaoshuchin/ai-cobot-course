extends Node3D
# 全部使用 Godot 內建幾何形狀；不需要網路素材。
var robot: Node3D
var head: Node3D
var camera: Camera3D
var viewport: SubViewport
var objects: Node3D
var settings: Dictionary
var robot_settings: Dictionary
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var touch: Vector2 = Vector2.ZERO
var turn_touch: float = 0.0

func shape(parent: Node3D, mesh: Mesh, at: Vector3, tint: Color) -> MeshInstance3D:
	var m: MeshInstance3D = MeshInstance3D.new()
	m.mesh = mesh
	m.position = at
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = tint
	mat.roughness = 0.85
	m.material_override = mat
	parent.add_child(m)
	return m

func box(parent: Node3D, at: Vector3, dimensions: Vector3, tint: Color) -> MeshInstance3D:
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = dimensions
	return shape(parent, mesh, at, tint)

func setup(sc: Dictionary, rc: Dictionary, vc: Dictionary) -> void:
	settings = sc
	robot_settings = rc
	rng.seed = int(sc.seed)
	var env: WorldEnvironment = WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR
	env.environment.background_color = Color("142330")
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color.WHITE
	env.environment.ambient_light_energy = 0.65
	add_child(env)
	var light: DirectionalLight3D = DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-55,-25,0)
	light.light_energy = 0.65
	light.shadow_enabled = true
	add_child(light)
	box(self, Vector3(0,-0.2,0),Vector3(sc.table_size[0],0.35,sc.table_size[1]),Color("9B7858"))
	# 細木條形成木紋，顏色保持低飽和以免誤認成積木。
	for i in range(32):
		var x: float = -float(sc.table_size[0])/2.0 + i * float(sc.table_size[0])/32.0
		box(self,Vector3(x,-0.018,0),Vector3(0.015,0.005,sc.table_size[1]),Color("80674F"))
	for x in [-3,3]:
		for z in [-3,3]:
			box(self,Vector3(x,-1.5,z),Vector3(0.18,2.5,0.18),Color("465461"))
	box(self,Vector3(0,-2.85,0),Vector3(200,0.1,200),Color("233440"))
	objects = Node3D.new()
	add_child(objects)
	robot = Node3D.new()
	add_child(robot)
	robot.position = Vector3(0,0,3.25)
	box(robot,Vector3(0,0.3,0),Vector3(0.8,0.35,0.8),Color(rc.body_color))
	for x in [-0.45,0.45]:
		for z in [-0.25,0.25]:
			var wheel: CylinderMesh = CylinderMesh.new()
			wheel.top_radius = 0.19
			wheel.bottom_radius = 0.19
			wheel.height = 0.12
			shape(robot,wheel,Vector3(x,0.18,z),Color("172532")).rotation_degrees.z = 90
	box(robot,Vector3(0,1.35,0),Vector3(0.09,2,0.09),Color("647483"))
	head = Node3D.new()
	robot.add_child(head)
	head.position.y = 2.9
	head.rotation.x = -0.68
	box(head,Vector3.ZERO,Vector3(0.6,0.34,0.4),Color(rc.accent_color))
	var lens: CylinderMesh = CylinderMesh.new()
	lens.top_radius = 0.14
	lens.bottom_radius = 0.14
	lens.height = 0.15
	shape(head,lens,Vector3(0,0,-0.25),Color("142330")).rotation_degrees.x = 90
	var badge: Label3D = Label3D.new()
	badge.text = str(rc.name)
	badge.font = load("res://fonts/NotoSansTC-Common.ttf")
	badge.font_size = 64
	badge.pixel_size = 0.006
	badge.position = Vector3(0,0.75,0.42)
	robot.add_child(badge)
	# 相機不拍到自己的外殼，總覽仍看得見完整的小眼。
	for part in robot.find_children("*","GeometryInstance3D",true,false):
		part.layers = 2
	var overview: Camera3D = Camera3D.new()
	add_child(overview)
	overview.position = Vector3(10,11,13)
	overview.look_at(Vector3(0,0.1,0))
	overview.fov = 48
	overview.h_offset = 3.2
	overview.cull_mask = 3
	overview.current = true
	viewport = SubViewport.new()
	viewport.size = Vector2i(vc.camera_width,vc.camera_height)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.world_3d = get_world_3d()
	add_child(viewport)
	camera = Camera3D.new()
	viewport.add_child(camera)
	camera.fov = 90
	camera.cull_mask = 1
	camera.current = true
	rearrange()
	sync_camera()

func rearrange() -> void:
	for child in objects.get_children():
		objects.remove_child(child)
		child.queue_free()
	# 動態列距讓新增積木仍在相機可見範圍。
	var total: int = 0
	for group in settings.objects:
		total += int(group.count)
	var rows: int = ceili(float(total)/3)
	var spacing: float = minf(1.8,3.6/maxi(1,rows-1))
	var index: int = 0
	for group in settings.objects:
		for j in range(int(group.count)):
			var x: float = (index % 3 - 1) * 2.0 + rng.randf_range(-0.23,0.23)
			var z: float = floori(float(index) / 3) * spacing - 1.8 + rng.randf_range(-0.18,0.18)
			var mesh: Mesh
			var kind: String = settings.shapes[j % settings.shapes.size()]
			if kind == "sphere":
				var ball: SphereMesh = SphereMesh.new()
				ball.radius = 0.35
				ball.height = 0.7
				mesh = ball
			elif kind == "cylinder":
				var cylinder: CylinderMesh = CylinderMesh.new()
				cylinder.top_radius = 0.32
				cylinder.bottom_radius = 0.32
				cylinder.height = 0.65
				mesh = cylinder
			else:
				var cube: BoxMesh = BoxMesh.new()
				cube.size = Vector3(0.65,0.65,0.65)
				mesh = cube
			var block: MeshInstance3D = shape(objects,mesh,Vector3(x,0.35,z),Color(settings.object_colors[group.color]))
			# 保持教學色卡的色相穩定，幾何物件仍在桌面投下陰影。
			block.material_override.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			index += 1

func move_robot(delta: float, demo: bool, elapsed: float) -> void:
	if demo:
		robot.position = Vector3(sin(elapsed*0.15)*3.2,0,cos(elapsed*0.15)*3.2)
		head.rotation.y = elapsed*0.15
	else:
		var direction: Vector2 = touch
		direction.x += float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT))
		direction.y += float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN))-float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP))
		robot.position += Vector3(direction.x,0,direction.y).limit_length()*float(robot_settings.speed)*delta
		robot.position.x = clampf(robot.position.x,-float(settings.table_size[0])/2+0.5,float(settings.table_size[0])/2-0.5)
		robot.position.z = clampf(robot.position.z,-float(settings.table_size[1])/2+0.5,float(settings.table_size[1])/2-0.5)
		head.rotation.y += (turn_touch + float(Input.is_physical_key_pressed(KEY_Q))-float(Input.is_physical_key_pressed(KEY_E)))*float(robot_settings.turn_speed)*delta
	sync_camera()

func sync_camera() -> void:
	camera.global_position = head.global_position + Vector3(0,0.02,0)
	camera.global_rotation = Vector3(-0.68,head.rotation.y,0)
