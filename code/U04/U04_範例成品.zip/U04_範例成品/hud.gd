extends Control
# 面板只顯示影像處理結果，不參與辨識；所有座標仍是原圖像素。
signal rearrange_requested
var cfg: Dictionary
var scene_ref: Node3D
var masked: bool = false
var enlarged: bool = false
var results: Array = []
var panel: PanelContainer
var image_view: TextureRect
var overlay: FrameOverlay
var title: Label
var status: Label
var counts: Label
var list: Label
var select: OptionButton
var sliders: Array[HSlider] = []
var slider_labels: Array[Label] = []
var keys: Array = ["h","h","s","s","v","v"]
var defaults: Dictionary
var syncing: bool = false
var reset_button: Button
var color_heading: Label
var image_heading: Label
var controls: VBoxContainer

class FrameOverlay extends Control:
	var items: Array = []
	var resolution: Vector2 = Vector2(320,240)
	var font: Font
	var color_rules: Dictionary = {}
	var label_font_size: int = 30
	func _draw() -> void:
		var factor: Vector2 = size / resolution
		var occupied: Array[Rect2] = []
		for item in items:
			var c: Color = Color(color_rules.get(item.color,{}).get("draw","#FFFFFF"))
			var r: Rect2 = item.rect
			draw_rect(Rect2(r.position*factor,r.size*factor),c,false,2.5)
			var p: Vector2 = item.center*factor
			draw_line(p-Vector2(7,0),p+Vector2(7,0),c,2)
			draw_line(p-Vector2(0,7),p+Vector2(0,7),c,2)
			var text: String = "%s #%d (%d, %d)" % [item.color,item.id,item.center.x,item.center.y]
			var label_width: float = font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,label_font_size).x+8
			var line_height: float = label_font_size+8
			var slots: int = maxi(1,floori(size.y/line_height))
			var first_slot: int = clampi(floori(r.position.y*factor.y/line_height)-1,0,slots-1)
			var at: Vector2 = Vector2(clampf(r.position.x*factor.x,0,maxf(0,size.x-label_width)),0)
			# 依實際字寬保留標籤空間，循環找空列，手機也不互相遮字。
			for attempt in range(slots):
				at.y = ((first_slot+attempt)%slots)*line_height+label_font_size
				var candidate: Rect2 = Rect2(at-Vector2(0,label_font_size),Vector2(label_width,line_height))
				var overlap: bool = false
				for rect in occupied:
					if rect.intersects(candidate):
						overlap = true
				if not overlap:
					break
			occupied.append(Rect2(at-Vector2(0,label_font_size),Vector2(label_width,line_height)))
			draw_line(at+Vector2(12,3),p,Color(c,0.45),1)
			draw_string_outline(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,label_font_size,6,Color("142330"))
			draw_string(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,label_font_size,c)

func label(text: String, parent: Node, font_size: int = 25) -> Label:
	var l: Label = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size",font_size)
	parent.add_child(l)
	return l

func button(text: String, parent: Node, action: Callable) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.custom_minimum_size.y = 52
	b.pressed.connect(action)
	parent.add_child(b)
	return b

func setup(vc: Dictionary, world: Node3D) -> void:
	cfg = vc
	defaults = vc.duplicate(true)
	scene_ref = world
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme_res: Theme = Theme.new()
	theme_res.default_font = load("res://fonts/NotoSansTC-Common.ttf")
	theme_res.default_font_size = 25
	var normal: StyleBoxFlat = StyleBoxFlat.new()
	normal.bg_color = Color("263E50")
	normal.content_margin_left = 12
	normal.content_margin_right = 12
	normal.corner_radius_top_left = 10
	normal.corner_radius_bottom_right = 10
	var focus: StyleBoxFlat = normal.duplicate()
	focus.border_color = Color("7DE4D8")
	focus.set_border_width_all(3)
	theme_res.set_stylebox("normal","Button",normal)
	theme_res.set_stylebox("hover","Button",focus)
	theme_res.set_stylebox("focus","Button",focus)
	var background: StyleBoxFlat = normal.duplicate()
	background.bg_color = Color("102331")
	background.set_content_margin_all(18)
	theme_res.set_stylebox("panel","PanelContainer",background)
	theme = theme_res
	title = label("機器人的眼睛　／　小眼的像素實驗室",self,36)
	title.position = Vector2(30,18)
	image_heading = label("機器人看到的畫面｜320 × 240 像素",self,30)
	image_view = TextureRect.new()
	image_view.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image_view.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(image_view)
	overlay = FrameOverlay.new()
	overlay.font = theme_res.default_font
	overlay.color_rules = cfg.colors
	overlay.resolution = Vector2(vc.camera_width,vc.camera_height)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	image_view.add_child(overlay)
	panel = PanelContainer.new()
	add_child(panel)
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var column: VBoxContainer = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation",10)
	scroll.add_child(column)
	color_heading = label("",column,30)
	select = OptionButton.new()
	for color_name in cfg.colors:
		select.add_item(color_name)
	column.add_child(select)
	select.item_selected.connect(func(_i: int) -> void: sync_sliders())
	label("H／S／V 門檻｜下限、上限",column,25)
	for i in range(6):
		var l: Label = label("",column,23)
		slider_labels.append(l)
		var slider: HSlider = HSlider.new()
		slider.custom_minimum_size = Vector2(420,32)
		slider.max_value = 360 if i < 2 else 1
		slider.step = 1.0 if i < 2 else 0.01
		slider.value_changed.connect(func(value: float) -> void: change_rule(i,value))
		column.add_child(slider)
		sliders.append(slider)
	reset_button = button("門檻還原",column,reset_thresholds)
	counts = label("正在讀取相機像素…",column,28)
	counts.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label("偵測清單｜中心（像素）・面積",column,23)
	list = label("",column,24)
	label("紅色跨過零度：下限可大於上限\n編號依每次掃描順序，並非追蹤身分。",column,21)
	controls = VBoxContainer.new()
	add_child(controls)
	var row: HBoxContainer = HBoxContainer.new()
	controls.add_child(row)
	button("重新擺放",row,func() -> void: rearrange_requested.emit())
	button("切換視角",row,func() -> void:
		enlarged = not enlarged
		layout_ui())
	button("遮罩畫面",row,func() -> void: masked = not masked)
	var moves: HBoxContainer = HBoxContainer.new()
	controls.add_child(moves)
	for entry in [["←",Vector2.LEFT],["↑",Vector2.UP],["↓",Vector2.DOWN],["→",Vector2.RIGHT]]:
		var b: Button = button(entry[0],moves,func() -> void: pass)
		b.custom_minimum_size.x = 65
		b.button_down.connect(func() -> void: scene_ref.touch = entry[1])
		b.button_up.connect(func() -> void: scene_ref.touch = Vector2.ZERO)
	for entry in [["左轉頭",1.0],["右轉頭",-1.0]]:
		var b: Button = button(entry[0],moves,func() -> void: pass)
		b.button_down.connect(func() -> void: scene_ref.turn_touch = entry[1])
		b.button_up.connect(func() -> void: scene_ref.turn_touch = 0.0)
	status = label("方向鍵／WASD 移動　Q／E 轉頭\n白色＝符合規則；中心點從左上角（0, 0）算起。",controls,24)
	get_viewport().size_changed.connect(layout_ui)
	sync_sliders()
	layout_ui()

func layout_ui() -> void:
	var window: Window = get_window()
	var portrait_window: bool = window.size.y > window.size.x
	var target: Vector2i = Vector2i(800,1422) if portrait_window else Vector2i(1600,900)
	if window.content_scale_size != target:
		window.content_scale_size = target
	var s: Vector2 = get_viewport_rect().size
	var portrait: bool = s.y > s.x
	title.add_theme_font_size_override("font_size",30 if portrait else 36)
	if not scene_ref.get_parent().demo:
		title.text = "小眼的像素實驗室" if portrait else "機器人的眼睛　／　小眼的像素實驗室"
	panel.visible = not enlarged
	if enlarged:
		var height: float = minf(s.y-220,s.x*0.75)
		image_view.size = Vector2(height*4/3,height)
		image_view.position = Vector2((s.x-image_view.size.x)/2,75)
	elif portrait:
		image_view.size = Vector2(s.x*0.7,s.x*0.525)
		image_view.position = Vector2(s.x*0.15,110)
		panel.position = Vector2(20,s.y*0.55)
		panel.size = Vector2(s.x-40,s.y*0.45-230)
	else:
		image_view.position = Vector2(30,110)
		image_view.size = Vector2(s.x*0.5,s.x*0.375)
		panel.position = Vector2(s.x*0.55,82)
		panel.size = Vector2(s.x*0.45-25,s.y-105)
	image_heading.position = image_view.position-Vector2(0,40)
	image_heading.visible = not enlarged
	overlay.label_font_size = 24 if portrait else 30
	overlay.size = image_view.size
	controls.position = Vector2(30,s.y-180 if not portrait else s.y-210)
	overlay.queue_redraw()

func sync_sliders() -> void:
	syncing = true
	var selected_color: String = select.get_item_text(select.selected)
	color_heading.text = "目前調整：%s色" % selected_color
	var rule: Dictionary = cfg.colors[selected_color]
	for i in range(6):
		sliders[i].value = rule[keys[i]][i%2]
		update_slider_text(i)
	syncing = false

func update_slider_text(i: int) -> void:
	var names: Array = ["色相下限（度）","色相上限（度）","飽和度下限","飽和度上限","亮度下限","亮度上限"]
	slider_labels[i].text = "%s：%.2f" % [names[i],sliders[i].value]

func change_rule(i: int, value: float) -> void:
	if syncing:
		return
	cfg.colors[select.get_item_text(select.selected)][keys[i]][i%2] = value
	update_slider_text(i)

func display(texture: Texture2D, mask_image: Image, found: Array) -> void:
	image_view.texture = ImageTexture.create_from_image(mask_image) if masked else texture
	results = found
	overlay.items = found
	overlay.queue_redraw()
	var totals: Dictionary = {}
	for color_name in cfg.colors:
		totals[color_name] = 0
	var lines: PackedStringArray = []
	for item in found:
		totals[item.color] = totals.get(item.color,0)+1
		lines.append("%s #%d　(%d, %d)　%d 格" % [item.color,item.id,item.center.x,item.center.y,item.area])
	var summary: PackedStringArray = []
	for color_name in totals:
		summary.append("%s %d" % [color_name,totals[color_name]])
	counts.text = "　".join(summary)+"　／　"+("遮罩" if masked else "彩色")
	list.text = "\n".join(lines) if not lines.is_empty() else "沒有符合規則的物件"

func reset_thresholds() -> void:
	# 還原目前顏色，保留其他顏色的課堂調整。
	var selected_color: String = select.get_item_text(select.selected)
	cfg.colors[selected_color] = defaults.colors[selected_color].duplicate(true)
	sync_sliders()
