extends CanvasLayer
# 大字、可觸控的操作面板；窄螢幕改成上下排列並可捲動。
signal action(name: String)
var root: MarginContainer
var body: BoxContainer
var step: Label
var status: Label
var counts: Label
var answer: Label
var votes: Label
var values: Label
var matrix: Control
var note: Label
var confidence: ProgressBar
var photo: TextureRect
var silhouette: TextureRect
var tiny_mask: TextureRect
var scatter: Control
var curve: Control
var buttons: Array[Button] = []
var axes: Array[OptionButton] = []
var tabs: TabContainer
var vision_row: HBoxContainer
var font: Font = preload("res://fonts/NotoSansTC-Common.ttf")
var feature_names: Array = ["寬高比例","填滿率","圓度","上半部占比","左右對稱度"]

func label(parent: Node, text: String, font_size: int = 28) -> Label:
	var item: Label = Label.new()
	item.text = text
	item.add_theme_font_size_override("font_size",font_size+4)
	item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(item)
	return item

func box(parent: Node) -> VBoxContainer:
	var panel: PanelContainer = PanelContainer.new()
	parent.add_child(panel)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var content: VBoxContainer = VBoxContainer.new()
	content.add_theme_constant_override("separation",12)
	panel.add_child(content)
	return content

func button(parent: Node, text: String, command: String) -> Button:
	var item: Button = Button.new()
	item.text = text
	item.custom_minimum_size.y = 62
	item.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(item)
	item.pressed.connect(func() -> void: action.emit(command))
	buttons.append(item)
	return item

func setup(config: Dictionary, camera_texture: Texture2D, stage: SubViewportContainer) -> void:
	root = MarginContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","top","right","bottom"]:
		root.add_theme_constant_override("margin_"+side,24)
	add_child(root)
	var theme: Theme = Theme.new()
	theme.default_font = font
	theme.default_font_size = 28
	theme.set_color("font_color","Label",Color("e9f1f6"))
	theme.set_constant("separation","VBoxContainer",12)
	theme.set_constant("separation","HBoxContainer",12)
	for style_name in ["normal","hover","pressed","disabled","focus"]:
		var style: StyleBoxFlat = StyleBoxFlat.new()
		style.bg_color = Color("264857") if style_name=="normal" else Color("346a77")
		if style_name=="disabled":
			style.bg_color = Color("243440")
		style.set_corner_radius_all(10)
		style.content_margin_left = 16
		style.content_margin_right = 16
		if style_name=="focus":
			style.bg_color = Color.TRANSPARENT
			style.border_color = Color("f8c86b")
			style.set_border_width_all(3)
		theme.set_stylebox(style_name,"Button",style)
	var panel_style: StyleBoxFlat = StyleBoxFlat.new()
	panel_style.bg_color = Color("192f3f")
	panel_style.set_corner_radius_all(14)
	panel_style.content_margin_left = 18
	panel_style.content_margin_right = 18
	panel_style.content_margin_top = 12
	panel_style.content_margin_bottom = 12
	theme.set_stylebox("panel","PanelContainer",panel_style)
	root.theme = theme
	ResourceSaver.save(theme,"user://classroom_theme.tres")
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	var page: VBoxContainer = VBoxContainer.new()
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(page)
	label(page,str(config.title)+"　／　曾小亮老師的機器人教室",34)
	step = label(page,"① 收集　 →　 ② 訓練　 →　 ③ 考試",30)
	step.modulate = Color("60d9cc")
	body = BoxContainer.new()
	page.add_child(body)
	var left: VBoxContainer = box(body)
	left.size_flags_stretch_ratio = 0.85
	label(left,"形狀實驗台　｜　顏色相同，輪廓不同",26)
	stage.custom_minimum_size = Vector2(100,190)
	left.add_child(stage)
	stage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stage.stretch = true
	label(left,"① 請替眼前的物件貼標籤",26)
	var labels: HBoxContainer = HBoxContainer.new()
	left.add_child(labels)
	for cls in config.classes:
		button(labels,cls,"label:"+str(cls))
	counts = label(left,"",23)
	var row: HBoxContainer = HBoxContainer.new()
	left.add_child(row)
	button(row,"自動收集 %d 個" % int(config.auto_collect),"auto")
	button(row,"換一個物件","next")
	row = HBoxContainer.new()
	left.add_child(row)
	button(row,"② 訓練","train")
	button(row,"③ 考試 %d 題" % int(config.exam_questions),"exam")
	row = HBoxContainer.new()
	left.add_child(row)
	button(row,"儲存模型","save")
	button(row,"載入模型","load")
	button(row,"學習曲線","curve")
	status = label(left,"先貼標籤或自動收集，再按訓練。",23)
	var right: VBoxContainer = box(body)
	right.size_flags_stretch_ratio = 1.15
	vision_row = HBoxContainer.new()
	right.add_child(vision_row)
	for title in ["機器人看到的","亮度剪影","8×8 特徵"]:
		var column: VBoxContainer = VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vision_row.add_child(column)
		label(column,title,24)
		var texture: TextureRect = TextureRect.new()
		texture.custom_minimum_size = Vector2(200,264)
		texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		texture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		column.add_child(texture)
		if title=="機器人看到的":
			photo = texture
			photo.texture = camera_texture
		elif title=="亮度剪影":
			silhouette = texture
		else:
			tiny_mask = texture
			tiny_mask.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	answer = label(right,"等待機器人學習",28)
	confidence = ProgressBar.new()
	confidence.custom_minimum_size.y = 24
	right.add_child(confidence)
	tabs = TabContainer.new()
	tabs.custom_minimum_size = Vector2(100,420)
	right.add_child(tabs)
	var features_tab: VBoxContainer = VBoxContainer.new()
	features_tab.name = "特徵與投票"
	tabs.add_child(features_tab)
	values = label(features_tab,"",22)
	votes = label(features_tab,"信心＝鄰居投票比例，不代表保證答對。",22)
	var plot_tab: VBoxContainer = VBoxContainer.new()
	plot_tab.name = "特徵散布"
	tabs.add_child(plot_tab)
	row = HBoxContainer.new()
	plot_tab.add_child(row)
	for i in range(2):
		label(row,"橫軸" if i==0 else "縱軸",21)
		var select: OptionButton = OptionButton.new()
		for name_v in feature_names:
			select.add_item(name_v)
		select.select(i)
		row.add_child(select)
		axes.append(select)
		select.item_selected.connect(func(_index: int) -> void:
			scatter.axes = Vector2i(axes[0].selected,axes[1].selected)
			scatter.queue_redraw())
	scatter = preload("res://plots.gd").new()
	scatter.font = font
	scatter.classes = config.classes
	scatter.custom_minimum_size.y = 220
	plot_tab.add_child(scatter)
	label(plot_tab,"青：方塊　黃：球　紫：圓柱　粉：圓錐",20)
	var result_tab: VBoxContainer = VBoxContainer.new()
	result_tab.name = "考試混淆表"
	tabs.add_child(result_tab)
	matrix = preload("res://plots.gd").new()
	matrix.mode = "matrix"
	matrix.font = font
	matrix.classes = config.classes
	matrix.custom_minimum_size.y = 370
	matrix.size_flags_vertical = Control.SIZE_EXPAND_FILL
	result_tab.add_child(matrix)
	curve = preload("res://plots.gd").new()
	curve.name = "學習曲線"
	curve.font = font
	curve.mode = "curve"
	curve.custom_minimum_size.y = 370
	tabs.add_child(curve)
	note = label(page,"模型＝貼好標籤的樣本；訓練＝整理成可比較的特徵。所有辨識都在本機進行。",21)
	note.modulate = Color("a8bdcb")
	tabs.tab_changed.connect(update_tab_layout)
	update_tab_layout(0)
	get_viewport().size_changed.connect(responsive)
	responsive()

# 圖表分頁專心看大圖；回到作答分頁時恢復加倍的三張影像。
func update_tab_layout(index: int) -> void:
	vision_row.visible = index==0
	answer.visible = index==0
	confidence.visible = index==0
	tabs.custom_minimum_size.y = 270 if index==0 else 560

func responsive() -> void:
	var window: Window = get_window()
	var portrait: bool = window.size.x < window.size.y
	body.vertical = portrait
	var logical: Vector2i = Vector2i(800,1280) if portrait else Vector2i(1600,900)
	if window.content_scale_size != logical:
		window.content_scale_size = logical

func lock(value: bool) -> void:
	for item in buttons:
		item.disabled = value

func display_features(result: Dictionary) -> void:
	if result.vector.is_empty():
		values.text = "沒有拍到清楚剪影，請換一個物件。"
		return
	silhouette.texture = ImageTexture.create_from_image(result.mask)
	var tiny: Image = Image.create_empty(8,8,false,Image.FORMAT_RGB8)
	for i in range(64):
		var gray: float = result.vector[i+5]
		tiny.set_pixel(i%8,int(i/8.0),Color(gray,gray,gray))
	tiny_mask.texture = ImageTexture.create_from_image(tiny)
	values.text = "看輪廓：寬或窄、圓或方、上大下小。\n把剪影縮成 8×8 格，找形狀最像的樣本。"

func display_prediction(prediction: Dictionary) -> void:
	confidence.value = prediction.confidence*100
	votes.text = "鄰居投票："
	for cls in prediction.votes:
		votes.text += "%s %d 票　" % [cls,prediction.votes[cls]]
	votes.text += "\n票多的答案勝出，仍然可能答錯。"
