extends RefCounted
# 模型就是老師貼好標籤的樣本清單；沒有偷偷使用形狀答案。
var samples: Array = []
var k: int = 5

func train(data: Array) -> void:
	samples = data.duplicate(true)

func predict(vector: Array) -> Dictionary:
	if samples.is_empty():
		return {"label": "尚未訓練", "confidence": 0.0, "neighbors": [], "votes": {}}
	var distances: Array = []
	for s in samples:
		var distance: float = 0.0
		for i in range(vector.size()):
			var delta: float = float(vector[i])-float(s.vector[i])
			# 歐氏距離：每個正規化特徵的差平方相加，再開根號。
			distance += delta*delta
		distances.append({"label": s.label, "distance": sqrt(distance)})
	distances.sort_custom(func(a: Dictionary,b: Dictionary) -> bool: return a.distance < b.distance)
	var neighbors: Array = distances.slice(0,mini(k,distances.size()))
	var votes: Dictionary = {}
	var winner: String = neighbors[0].label
	for n in neighbors:
		votes[n.label] = int(votes.get(n.label,0))+1
		if votes[n.label] > int(votes.get(winner,0)):
			winner = n.label
	return {"label": winner, "confidence": float(votes[winner])/neighbors.size(), "neighbors": neighbors, "votes": votes}

func save_model(path: String = "user://model.json") -> bool:
	var file: FileAccess = FileAccess.open(path,FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify({"version":1,"k":k,"samples":samples}))
	return true

func load_model(path: String = "user://model.json") -> bool:
	if not FileAccess.file_exists(path):
		return false
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not data is Dictionary or not data.get("samples") is Array or data.samples.is_empty():
		return false
	for s in data.samples:
		if not s is Dictionary or not s.get("label") is String or not s.get("vector") is Array or s.vector.size()!=69:
			return false
		for v in s.vector:
			if not (v is float or v is int) or not is_finite(float(v)) or v<0 or v>1:
				return false
	samples = data.samples
	k = clampi(int(data.get("k",5)),1,99)
	return true
