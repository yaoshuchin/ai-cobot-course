extends Node
# 流程控制：相機取像→特徵→老師標籤→樣本模型→獨立考試。
const Features = preload("res://features.gd")
const KNN = preload("res://knn.gd")
var config: Dictionary = {"title":"教機器人認東西","classes":["方塊","球","圓柱","圓錐"],"object_color":"#CFD8DC","background_color":"#172B3A","k":5,"camera_width":160,"camera_height":120,"exam_questions":20,"auto_collect":20,"size_range":[0.8,1.2],"seed":11}
var config_note: String = ""
var table: Node3D
var hud: CanvasLayer
var model: RefCounted = KNN.new()
var samples: Array = []
var busy: bool = false
var dirty: bool = false
var latest: Dictionary = {}
var qa: bool = false
var results: Dictionary = {}
var demo_running: bool = false
var demo_stages: Array = []

func _ready() -> void:
	read_config()
	if "--self-test" in OS.get_cmdline_user_args():
		self_test()
		return
	qa = "--qa" in OS.get_cmdline_user_args()
	var background: ColorRect = ColorRect.new()
	background.color = Color("0c1c28")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = -1
	add_child(layer)
	layer.add_child(background)
	var stage: SubViewportContainer = SubViewportContainer.new()
	var viewport: SubViewport = SubViewport.new()
	viewport.size = Vector2i(720,300)
	viewport.own_world_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	stage.add_child(viewport)
	table = preload("res://turntable.gd").new()
	viewport.add_child(table)
	# 先將轉盤放進場景，才能取得共用的 3D 世界。
	add_child(stage)
	table.setup(config)
	hud = preload("res://hud.gd").new()
	add_child(hud)
	remove_child(stage)
	hud.setup(config,table.sensor.get_texture(),stage)
	hud.action.connect(handle_action)
	model.k = config.k
	refresh_counts()
	if not config_note.is_empty():
		hud.note.text = config_note
	await refresh_photo()
	if "--demo" in OS.get_cmdline_user_args() or qa:
		await demonstration()
		if qa:
			await screenshot("res://證據/桌面畫面.png")
			results.classroom_layout = {"chart_rect":str(hud.tabs.get_global_rect()),"photo_minimum":str(hud.photo.custom_minimum_size),"chart_fully_visible":hud.tabs.get_global_rect().end.y<=900,"model_samples_after_curve":model.samples.size(),"samples_after_curve":samples.size()}
			get_window().size = Vector2i(600,1000)
			await get_tree().create_timer(0.5).timeout
			await screenshot("res://證據/直式畫面.png")
			var file: FileAccess = FileAccess.open("res://證據/相機實測.json",FileAccess.WRITE)
			results.demo_stages = demo_stages
			file.store_string(JSON.stringify(results,"\t"))
			print("CAMERA_QA ",JSON.stringify(results))
			get_tree().quit()

func read_config() -> void:
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://teach.json")) if FileAccess.file_exists("res://teach.json") else null
	if not data is Dictionary:
		config_note = "設定檔讀不到，已使用預設設定。"
		return
	var valid: bool = true
	for key in config:
		if data.has(key):
			if typeof(data[key])==typeof(config[key]) or ((data[key] is float or data[key] is int) and config[key] is int):
				config[key] = data[key]
			else:
				valid = false
	var names: Array = []
	for name_v in config.classes:
		if name_v in ["方塊","球","圓柱","圓錐"] and not names.has(name_v):
			names.append(name_v)
	if names.is_empty():
		names = ["方塊","球","圓柱","圓錐"]
		valid = false
	config.classes = names
	for key in ["object_color","background_color"]:
		if not Color.html_is_valid(str(config[key])):
			config[key] = "#CFD8DC" if key=="object_color" else "#172B3A"
			valid = false
	config.k = clampi(int(config.k),1,99)
	config.seed = int(config.seed)
	for key in ["exam_questions","auto_collect"]:
		config[key] = clampi(int(config[key]),1,100)
	config.camera_width = clampi(int(config.camera_width),80,640)
	config.camera_height = clampi(int(config.camera_height),60,480)
	if config.size_range.size()!=2 or not (config.size_range[0] is float or config.size_range[0] is int) or not (config.size_range[1] is float or config.size_range[1] is int):
		config.size_range = [0.8,1.2]
		valid = false
	config.size_range = [clampf(float(config.size_range[0]),0.8,1.2),clampf(float(config.size_range[1]),0.8,1.2)]
	config.size_range.sort()
	if not valid:
		config_note = "部分設定不適用，已安全改用預設或合理範圍。"

func refresh_photo() -> Dictionary:
	# 等待兩次真正畫完；不把上一個物件的照片貼上新標籤。
	if DisplayServer.get_name()=="headless":
		return {}
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	latest = Features.extract(table.photo())
	hud.display_features(latest)
	hud.answer.text = "目前物件尚未作答"
	hud.confidence.value = 0
	hud.votes.text = "訓練後按考試，看最像的鄰居投給誰。\n信心是投票比例，不保證答對。"
	return latest

func refresh_counts() -> void:
	var text: String = ""
	for cls in config.classes:
		var count: int = 0
		for s in samples:
			if s.label == cls:
				count += 1
		text += "%s %d　" % [cls,count]
	hud.counts.text = text+"（共 %d）" % samples.size()
	hud.scatter.samples = samples
	hud.scatter.queue_redraw()

func set_busy(value: bool) -> void:
	busy = value
	hud.lock(value)

func handle_action(command: String) -> void:
	if busy:
		return
	set_busy(true)
	if command.begins_with("label:"):
		await add_current(command.trim_prefix("label:"))
	elif command=="next":
		table.show_next()
		await refresh_photo()
	elif command=="auto":
		await collect(int(config.auto_collect))
	elif command=="train":
		train_model()
	elif command=="exam":
		if model.samples.is_empty() or dirty:
			hud.status.text = "請先按訓練，讓模型整理目前的樣本。"
		else:
			await exam(int(config.exam_questions))
	elif command=="save":
		if model.samples.is_empty() or dirty:
			hud.status.text = "請先訓練，再儲存目前的模型。"
		else:
			hud.status.text = "模型已存入這個裝置。" if model.save_model() else "無法儲存，請檢查瀏覽器儲存權限。"
	elif command=="load":
		if model.load_model():
			samples = model.samples.duplicate(true)
			dirty = false
			refresh_counts()
			hud.status.text = "已載入模型，共 %d 個樣本；鄰居數 %d。" % [samples.size(),model.k]
		else:
			hud.status.text = "沒有可用的模型；先收集、訓練並儲存。"
	elif command=="curve":
		await learning_curve()
	set_busy(false)

func add_current(label_v: String) -> void:
	var f: Dictionary = await refresh_photo()
	if not f.is_empty() and not f.vector.is_empty():
		samples.append({"label":label_v,"vector":f.vector})
		dirty = true
		refresh_counts()
		hud.status.text = "已貼上「%s」；新增資料後記得再按訓練。" % label_v
	table.show_next()
	await refresh_photo()

func collect(total: int, per_class: bool = false) -> void:
	for i in range(total):
		if per_class:
			for cls in config.classes:
				table.show_next(table.shape_names.find(cls))
				await collect_one(cls)
		else:
			var cls: String = config.classes[i%config.classes.size()]
			table.show_next(table.shape_names.find(cls))
			await collect_one(cls)
	table.show_next()
	await refresh_photo()

func collect_one(label_v: String) -> void:
	var f: Dictionary = await refresh_photo()
	if not f.is_empty() and not f.vector.is_empty():
		samples.append({"label":label_v,"vector":f.vector})
		dirty = true
		refresh_counts()
		hud.status.text = "自動貼標籤中：已收集 %d 個（程式代替老師提供正解）。" % samples.size()

func train_model() -> void:
	if samples.is_empty():
		hud.status.text = "還沒有樣本，請先收集。"
		return
	model.train(samples)
	dirty = false
	hud.step.text = "① 收集完成　 →　 ② 訓練完成　 →　 ③ 可以考試"
	hud.status.text = "訓練完成：%d 個樣本。模型會找最近的 %d 個鄰居投票。" % [samples.size(),model.k]
	hud.tabs.current_tab = 1
	refresh_counts()

func empty_matrix() -> Array:
	var matrix_v: Array = []
	for _i in config.classes:
		var row: Array = []
		row.resize(config.classes.size())
		row.fill(0)
		matrix_v.append(row)
	return matrix_v

func summarize(matrix_v: Array) -> Dictionary:
	var total: int = 0
	var correct: int = 0
	var pair_count: int = 0
	var pair: String = "沒有互相認錯"
	for i in range(matrix_v.size()):
		for j in range(matrix_v.size()):
			total += matrix_v[i][j]
			if i==j:
				correct += matrix_v[i][j]
			elif i<j and matrix_v[i][j]+matrix_v[j][i]>pair_count:
				pair_count = matrix_v[i][j]+matrix_v[j][i]
				pair = "%s／%s（共 %d 次）" % [config.classes[i],config.classes[j],pair_count]
	return {"correct":correct,"total":total,"accuracy":float(correct)/maxi(total,1),"confused_pair":pair,"matrix":matrix_v}

func show_summary(summary: Dictionary) -> void:
	hud.matrix.matrix = summary.matrix
	hud.matrix.queue_redraw()
	hud.tabs.current_tab = 2
	hud.status.text = "答對 %d／%d，正確率 %d%%。最常混淆：%s" % [summary.correct,summary.total,roundi(summary.accuracy*100),summary.confused_pair]

func exam(total: int, fixed_seed: int = -1) -> Dictionary:
	var saved_state: int = table.rng.state
	if fixed_seed>=0:
		table.rng.seed = fixed_seed
	var matrix_v: Array = empty_matrix()
	hud.step.text = "③ 考試　｜　機器人只能看照片，不能看正解"
	for i in range(total):
		table.show_next(table.shape_names.find(config.classes[i%config.classes.size()]))
		var f: Dictionary = await refresh_photo()
		if f.is_empty() or f.vector.is_empty():
			hud.status.text = "無法擷取相機畫面，這次考試中止。"
			return {}
		var prediction: Dictionary = model.predict(f.vector)
		var answer_index: int = config.classes.find(prediction.label)
		if answer_index<0:
			hud.status.text = "模型含有目前設定以外的類別，請改回原設定。"
			return {}
		matrix_v[config.classes.find(table.truth)][answer_index] += 1
		hud.answer.text = "第 %d／%d 題：%s，把握 %.1f 成　%s\n正解：%s" % [i+1,total,prediction.label,prediction.confidence*10,"✓ 答對" if prediction.label==table.truth else "答錯",table.truth]
		hud.display_prediction(prediction)
		hud.tabs.current_tab = 0
		if not qa or demo_running:
			await get_tree().create_timer(0.65).timeout
	if fixed_seed>=0:
		table.rng.state = saved_state
	var summary: Dictionary = summarize(matrix_v)
	show_summary(summary)
	return summary

# 每段從切換分頁起計時，工作完成後補足四秒；檢查也走相同節奏。
func demo_hold(name_v: String, started: int) -> void:
	var elapsed: float = (Time.get_ticks_msec()-started)/1000.0
	await get_tree().create_timer(maxf(0.01,4.0-elapsed)).timeout
	# 計時器受畫面更新時間影響，用真實經過時間再次確認至少四秒。
	while Time.get_ticks_msec()-started<4000:
		await get_tree().create_timer(0.05).timeout
	demo_stages.append({"stage":name_v,"seconds":(Time.get_ticks_msec()-started)/1000.0,"tab":hud.tabs.current_tab})
	if qa and name_v=="收集":
		await screenshot("res://證據/大字作答畫面.png")

func demonstration() -> void:
	set_busy(true)
	demo_running = true
	samples.clear()
	table.rng.seed = config.seed
	for round_index in range(2):
		hud.tabs.current_tab = 0
		hud.step.text = "示範：先替每類收集 5 個樣本" if round_index==0 else "示範：每類再增加 15 個，合計 20 個"
		var started: int = Time.get_ticks_msec()
		await collect(5 if round_index==0 else 15,true)
		await demo_hold("收集",started)
		started = Time.get_ticks_msec()
		train_model()
		await demo_hold("訓練",started)
		started = Time.get_ticks_msec()
		hud.tabs.current_tab = 0
		var summary: Dictionary = await exam(10,9001)
		# 考試每題停留 0.65 秒，十題合計超過四秒。
		demo_stages.append({"stage":"考試","seconds":(Time.get_ticks_msec()-started)/1000.0,"tab":0})
		results["five_per_class" if round_index==0 else "twenty_per_class"] = summary
		started = Time.get_ticks_msec()
		hud.step.text = "混淆表　｜　綠色答對，紅色是認錯的次數"
		await demo_hold("混淆表",started)
		if qa:
			await screenshot("res://證據/大字混淆表.png")
	await learning_curve()
	await demo_hold("學習曲線",Time.get_ticks_msec())
	demo_running = false
	set_busy(false)

func learning_curve() -> void:
	set_busy(true)
	hud.tabs.current_tab = 3
	hud.step.text = "學習曲線　｜　建立獨立考卷，比較不同樣本數"
	var pool: Array = []
	var tests: Array = []
	var state: int = table.rng.state
	table.rng.seed = 4401
	# 同一個 40 樣本池逐步取前 2、5、10、20、40 個；考卷完全獨立。
	for cls in config.classes:
		for i in range(60):
			table.show_next(table.shape_names.find(cls))
			var f: Dictionary = await refresh_photo()
			if f.is_empty() or f.vector.is_empty():
				hud.status.text = "相機未產生剪影，無法繪製曲線。"
				set_busy(false)
				return
			var s: Dictionary = {"label":cls,"vector":f.vector,"index":i}
			if i<40:
				pool.append(s)
			else:
				tests.append(s)
			hud.status.text = "準備相機樣本 %d／%d；使用獨立的 %d 題考卷。" % [pool.size()+tests.size(),60*config.classes.size(),20*config.classes.size()]
	var points: Array = []
	for count in [2,5,10,20,40]:
		var subset: Array = []
		for s in pool:
			if s.index<count:
				subset.append(s)
		var curve_model: RefCounted = KNN.new()
		curve_model.k = config.k
		curve_model.train(subset)
		var matrix_v: Array = empty_matrix()
		for s in tests:
			var prediction: Dictionary = curve_model.predict(s.vector)
			matrix_v[config.classes.find(s.label)][config.classes.find(prediction.label)] += 1
		var summary: Dictionary = summarize(matrix_v)
		summary.count = count
		points.append(summary)
	results.learning_curve = points
	table.rng.state = state
	hud.curve.points = points
	hud.curve.queue_redraw()
	hud.tabs.current_tab = 3
	hud.step.text = "學習曲線完成　｜　每類 2、5、10、20、40 個樣本"
	hud.status.text = "每個點都用同一份獨立考卷；樣本增多通常有幫助，也可能持平或下降。原本的模型仍保留。"
	if not demo_running:
		set_busy(false)

func screenshot(path: String) -> void:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(path)

func self_test() -> void:
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 75
	var training: Array = []
	var testing: Array = []
	var failure: String = ""
	for kind in range(4):
		for i in range(30):
			var f: Dictionary = Features.extract(Features.synthetic(kind,rng))
			if f.vector.size()!=69:
				failure = "特徵維度錯誤"
			for v in f.vector:
				if not is_finite(v) or v<0 or v>1:
					failure = "特徵不在 0～1"
			var s: Dictionary = {"label":["方塊","球","圓柱","圓錐"][kind],"vector":f.vector}
			if i<20:
				training.append(s)
			else:
				testing.append(s)
	var test_model: RefCounted = KNN.new()
	test_model.k = 5
	test_model.train(training)
	var correct: int = 0
	for s in testing:
		if test_model.predict(s.vector).label==s.label:
			correct += 1
	if correct<32:
		failure = "辨識正確率低於 80%"
	if not test_model.save_model("user://self_test_model.json"):
		failure = "模型無法儲存"
	var restored: RefCounted = KNN.new()
	if not restored.load_model("user://self_test_model.json"):
		failure = "模型無法載入"
	else:
		for s in testing:
			var before: Dictionary = test_model.predict(s.vector)
			var after: Dictionary = restored.predict(s.vector)
			if before.label!=after.label or before.confidence!=after.confidence:
				failure = "讀回後預測不同"
	var black: Image = Image.create_empty(80,60,false,Image.FORMAT_RGB8)
	black.fill(Color.BLACK)
	if not Features.extract(black).vector.is_empty():
		failure = "空白影像檢查失敗"
	if failure.is_empty():
		print("SELF_TEST PASS 120 張剪影；80 張訓練／40 張獨立測試；69 特徵範圍與模型存取一致（正確率 %.1f%%）" % (correct*2.5))
		get_tree().quit(0)
	else:
		print("SELF_TEST FAIL ",failure)
		get_tree().quit(1)
