extends RefCounted
# 只讀相機像素，不接收物件種類；以四角背景亮度建立遮罩。
static func extract(image: Image) -> Dictionary:
	var w: int = image.get_width()
	var h: int = image.get_height()
	var bg: float = image.get_pixel(0, 0).get_luminance()
	var mask: PackedByteArray = PackedByteArray()
	mask.resize(w * h)
	var x0: int = w
	var y0: int = h
	var x1: int = -1
	var y1: int = -1
	var area: float = 0.0
	for y in range(h):
		for x in range(w):
			if image.get_pixel(x, y).get_luminance() > bg + 0.12:
				mask[y*w+x] = 1
				x0 = mini(x0, x)
				x1 = maxi(x1, x)
				y0 = mini(y0, y)
				y1 = maxi(y1, y)
				area += 1.0
	if area == 0:
		return {"vector": [], "area": 0, "mask": image}
	var bw: int = x1-x0+1
	var bh: int = y1-y0+1
	var perimeter: float = 0.0
	var upper: float = 0.0
	var same: float = 0.0
	var tiny: Array = []
	tiny.resize(64)
	tiny.fill(0.0)
	var cells: Array = []
	cells.resize(64)
	cells.fill(0.0)
	var preview: Image = Image.create_empty(w, h, false, Image.FORMAT_RGB8)
	preview.fill(Color("172b3a"))
	for y in range(y0, y1+1):
		for x in range(x0, x1+1):
			var v: int = mask[y*w+x]
			var cell: int = mini(7, int(float(y-y0)*8/bh))*8 + mini(7, int(float(x-x0)*8/bw))
			cells[cell] += 1.0
			tiny[cell] += v
			if v == mask[y*w+x1-(x-x0)]:
				same += 1.0
			if v == 0:
				continue
			preview.set_pixel(x, y, Color.WHITE)
			if y-y0 < bh/2.0:
				upper += 1.0
			for d in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
				var nx: int = x+d.x
				var ny: int = y+d.y
				if nx < 0 or nx >= w or ny < 0 or ny >= h or mask[ny*w+nx] == 0:
					perimeter += 1.0
	var vector: Array = [float(bw)/(bw+bh), area/(bw*bh), clampf(4.0*PI*area/(perimeter*perimeter),0,1), upper/area, same/(bw*bh)]
	for i in range(64):
		vector.append(tiny[i]/maxf(1.0,cells[i]))
	return {"vector": vector, "area": area, "mask": preview}

# 自我測試專用的合成剪影；正式操作完全使用 3D 相機影像。
static func synthetic(kind: int, rng: RandomNumberGenerator) -> Image:
	var image: Image = Image.create_empty(100,100,false,Image.FORMAT_RGB8)
	image.fill(Color.BLACK)
	var angle: float = rng.randf_range(-0.18,0.18)
	var scale_v: float = rng.randf_range(0.8,1.2)
	var center: Vector2 = Vector2(50+rng.randf_range(-5,5),50+rng.randf_range(-5,5))
	for y in range(100):
		for x in range(100):
			var p: Vector2 = (Vector2(x,y)-center).rotated(angle)/scale_v
			var inside: bool = false
			match kind:
				0: inside = absf(p.x)<25 and absf(p.y)<25
				1: inside = p.length()<27
				2: inside = absf(p.x)<23 and (absf(p.y)<22 or Vector2(p.x/23,(absf(p.y)-22)/7).length()<1)
				3: inside = p.y > -30 and p.y < 27 and absf(p.x)<(p.y+30)*0.48
			if inside:
				image.set_pixel(x,y,Color.WHITE)
	return image
