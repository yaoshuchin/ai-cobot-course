@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "APPDATA=%~dp0.runtime"
set "G="
for %%F in ("..\Godot\Godot_v4*_win64.exe") do if exist "%%~F" if not defined G set "G=%%~fF"
if not defined G (echo 找不到 Godot，請保留旁邊的 Godot 資料夾。 & pause & exit /b 1)
start "" "%G%" --audio-driver Dummy --path "%~dp0." %*