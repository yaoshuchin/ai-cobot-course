extends Node3D
# 轉盤是展示用；相機只看第二圖層的物件，避免把底座當成特徵。
var object: MeshInstance3D
var lamp: DirectionalLight3D
var sensor: SubViewport
var config: Dictionary
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var truth: String = ""
var shape_names: Array = ["方塊","球","圓柱","圓錐"]

func setup(settings: Dictionary) -> void:
	config = settings
	rng.seed = int(config.seed)
	var env: WorldEnvironment = WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR
	env.environment.background_color = Color(config.background_color)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color.WHITE
	env.environment.ambient_light_energy = 0.7
	add_child(env)
	lamp = DirectionalLight3D.new()
	lamp.light_energy = 1.0
	add_child(lamp)
	var base: MeshInstance3D = MeshInstance3D.new()
	var cylinder: CylinderMesh = CylinderMesh.new()
	cylinder.top_radius = 1.7
	cylinder.bottom_radius = 1.7
	cylinder.height = 0.18
	base.mesh = cylinder
	base.position.y = -1.25
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = Color("286d78")
	mat.metallic = 0.4
	base.material_override = mat
	add_child(base)
	object = MeshInstance3D.new()
	object.layers = 2
	mat = StandardMaterial3D.new()
	mat.albedo_color = Color(config.object_color)
	mat.roughness = 0.8
	object.material_override = mat
	add_child(object)
	var camera: Camera3D = Camera3D.new()
	camera.position = Vector3(3.5,2.0,6)
	add_child(camera)
	camera.look_at(Vector3(0,-0.2,0))
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 3.8
	sensor = SubViewport.new()
	sensor.size = Vector2i(int(config.camera_width),int(config.camera_height))
	sensor.world_3d = get_world_3d()
	sensor.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(sensor)
	var robot_camera: Camera3D = Camera3D.new()
	robot_camera.cull_mask = 2
	robot_camera.position = Vector3(0,0.65,6)
	sensor.add_child(robot_camera)
	robot_camera.look_at(Vector3.ZERO)
	robot_camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	robot_camera.size = 3.7
	show_next()

func show_next(kind: int = -1) -> void:
	if kind < 0:
		truth = str(config.classes[rng.randi_range(0,config.classes.size()-1)])
		kind = shape_names.find(truth)
	else:
		truth = shape_names[kind]
	match kind:
		0: object.mesh = BoxMesh.new()
		1:
			var sphere: SphereMesh = SphereMesh.new()
			sphere.radius = 0.63
			sphere.height = 1.26
			object.mesh = sphere
		2,3:
			var cylinder: CylinderMesh = CylinderMesh.new()
			cylinder.top_radius = 0.0 if kind==3 else 0.56
			cylinder.bottom_radius = 0.56
			cylinder.height = 1.45
			object.mesh = cylinder
	object.rotation = Vector3(rng.randf_range(-0.24,0.24),rng.randf_range(0,TAU),rng.randf_range(-0.18,0.18))
	object.scale = Vector3.ONE*rng.randf_range(float(config.size_range[0]),float(config.size_range[1]))
	lamp.rotation = Vector3(-0.7,rng.randf_range(-PI,PI),0)

func photo() -> Image:
	return sensor.get_texture().get_image()
