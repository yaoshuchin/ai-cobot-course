@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0u05-teach-robot\scripts\本機測試網頁版.ps1" -Dir "%~dp0網頁版"
pause