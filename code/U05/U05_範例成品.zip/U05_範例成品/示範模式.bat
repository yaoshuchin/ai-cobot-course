@echo off
chcp 65001 >nul
call "%~dp0開始玩.bat" -- --demo