extends Control
# 同一個圖表元件顯示特徵散布或真正測得的學習曲線。
var mode: String = "scatter"
var samples: Array = []
var points: Array = []
var classes: Array = []
var axes: Vector2i = Vector2i(0,1)
var colors: Array = [Color("60d9cc"),Color("f8c86b"),Color("adabfa"),Color("f392ac")]
var font: Font
var matrix: Array = []

# 投影用置中文字；數字與軸標籤都由真實考試結果繪製。
func centered(text: String, at: Vector2, width: float, font_size: int, color: Color = Color.WHITE) -> void:
	draw_string(font,at,text,HORIZONTAL_ALIGNMENT_CENTER,width,font_size,color)

func draw_matrix() -> void:
	centered("欄：機器人回答 →",Vector2(90,30),size.x-100,28)
	if matrix.is_empty():
		centered("考完後，這裡會出現彩色結果",Vector2(0,180),size.x,28)
		return
	var cell: Vector2 = Vector2((size.x-100)/classes.size(),(size.y-120)/classes.size())
	var maximum: int = 1
	for i in range(matrix.size()):
		for j in range(matrix.size()):
			if i!=j:
				maximum = maxi(maximum,int(matrix[i][j]))
	for i in range(classes.size()):
		centered(str(classes[i]),Vector2(100+i*cell.x,64),cell.x,28)
		centered(str(classes[i]),Vector2(0,80+(i+0.5)*cell.y+10),94,28)
		for j in range(classes.size()):
			var count: int = int(matrix[i][j])
			var tint: Color = Color("16845b") if i==j else Color("263c4b").lerp(Color("c52c39"),float(count)/maximum)
			var tile: Rect2 = Rect2(Vector2(100+j*cell.x,80+i*cell.y),cell-Vector2(4,4))
			draw_rect(tile,tint)
			centered(str(count),tile.position+Vector2(0,cell.y/2+14),tile.size.x,40)
	centered("列：正解　｜　綠色＝答對　紅色越深＝錯越多",Vector2(0,size.y-8),size.x,25)

func _draw() -> void:
	if font == null:
		return
	if mode == "matrix":
		draw_matrix()
		return
	var rect: Rect2 = Rect2(88,64,maxf(40,size.x-148),maxf(40,size.y-148))
	draw_rect(rect,Color("102330"))
	for i in range(5):
		var y: float = rect.end.y-rect.size.y*i/4.0
		draw_line(Vector2(rect.position.x,y),Vector2(rect.end.x,y),Color("284250"))
		draw_string(font,Vector2(2,y+9),str(i*25)+"%",HORIZONTAL_ALIGNMENT_LEFT,-1,26,Color("a8bdcb"))
	draw_line(rect.position,Vector2(rect.position.x,rect.end.y),Color("a8bdcb"),2)
	draw_line(Vector2(rect.position.x,rect.end.y),rect.end,Color("a8bdcb"),2)
	if mode == "scatter":
		for s in samples:
			var point: Vector2 = Vector2(rect.position.x+rect.size.x*float(s.vector[axes.x]),rect.end.y-rect.size.y*float(s.vector[axes.y]))
			var index: int = classes.find(s.label)
			draw_circle(point,5,colors[posmod(index,4)])
		draw_string(font,Vector2(70,size.y-10),"橫軸、縱軸皆為 0～1 的特徵值",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("a8bdcb"))
	else:
		draw_string(font,Vector2(2,29),"正確率",HORIZONTAL_ALIGNMENT_LEFT,-1,28,Color.WHITE)
		# 五種樣本數等距排列，避免 2 和 5 的標示擠在一起。
		for i in range(5):
			var x: float = rect.position.x+rect.size.x*i/4.0
			centered(str([2,5,10,20,40][i]),Vector2(x-26,rect.end.y+34),52,28)
		var last: Vector2 = Vector2.ZERO
		for p in points:
			var index: int = [2,5,10,20,40].find(int(p.count))
			var point: Vector2 = Vector2(rect.position.x+rect.size.x*index/4.0,rect.end.y-rect.size.y*float(p.accuracy))
			if last != Vector2.ZERO:
				draw_line(last,point,Color("60d9cc"),5,true)
			draw_circle(point,8,Color("f8c86b"))
			var caption_x: float = clampf(point.x-70,rect.position.x-20,size.x-142)
			centered("%s%%" % String.num(float(p.accuracy)*100,2).trim_suffix(".0"),Vector2(caption_x,point.y-17),140,30)
			last = point
		centered("每類樣本數（每次考同一份獨立考卷）",Vector2(0,size.y-5),size.x,26,Color("a8bdcb"))
