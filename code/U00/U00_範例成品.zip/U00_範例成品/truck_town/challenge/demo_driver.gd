﻿extends Node

# Guided road tour, active only in demo. Coins still require body_entered.
const ROUTE: Array[Vector3] = [
	Vector3(35.4, 0, 14.7), Vector3(20, 0, 14.7),
	Vector3(13.9, 0, 14.7), Vector3(13.9, 0, -5.5),
	Vector3(20, 0, -5.5), Vector3(30.7, 0, -2),
	Vector3(30.7, 0, 14.7),
]
var car: VehicleBody3D
var challenge: Node3D
var waypoint: int = 1
var report_time: float = 0.0
var screenshot_taken: bool = false


func _ready() -> void:
	process_physics_priority = 10
	car.freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
	car.freeze = true


func _physics_process(delta: float) -> void:
	if car == null:
		return
	var target: Vector3 = ROUTE[waypoint]
	var current: Vector3 = car.global_position
	target.y = current.y
	var next: Vector3 = current.move_toward(target, 4.0 * delta)
	var road: Vector3 = challenge.call("road_position", next)
	next.y = road.y + 0.35
	var direction: Vector3 = target - current
	direction.y = 0
	if direction.length() > 0.05:
		var yaw: float = atan2(direction.x, direction.z)
		car.global_rotation = Vector3(0, lerp_angle(car.global_rotation.y, yaw, minf(delta * 6, 1)), 0)
	car.global_position = next
	if Vector2(next.x - target.x, next.z - target.z).length() < 0.1:
		waypoint = (waypoint + 1) % ROUTE.size()
	car.engine_force = 0
	car.brake = 0
	car.linear_velocity = direction.normalized() * 4.0
	report_time += delta
	if report_time >= 5:
		report_time = 0
		print("示範駕駛：位置 %s，金幣 %d" % [car.global_position, int(challenge.get("count"))])
	if "--verify" in OS.get_cmdline_user_args() and not screenshot_taken and bool(challenge.get("finished")):
		screenshot_taken = true
		_save_verification.call_deferred()


func _save_verification() -> void:
	await RenderingServer.frame_post_draw
	var output: String = ProjectSettings.globalize_path("res://").path_join("../test_artifacts/demo_complete.png").simplify_path()
	var result: Error = get_viewport().get_texture().get_image().save_png(output)
	assert(result == OK, "驗證截圖儲存失敗")
	print("驗證截圖已儲存；挑戰完成，準備結束測試。")
	# Let the Dummy audio driver release the official looping engine stream.
	for audio: Node in get_tree().root.find_children("*", "AudioStreamPlayer3D", true, false):
		audio.call("stop")
	await get_tree().create_timer(0.3).timeout
	get_tree().quit.call_deferred()
