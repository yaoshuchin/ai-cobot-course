extends Node3D

const TOTAL: int = 10
const COIN: GDScript = preload("res://challenge/coin.gd")
const DRIVER: GDScript = preload("res://challenge/demo_driver.gd")

var count: int = 0
var elapsed: float = 0.0
var finished: bool = false
var score_label: Label
var timer_label: Label
var status_label: Label
var car: VehicleBody3D
const LOCATIONS: Array[Vector3] = [
	Vector3(26, 30, 14.7), Vector3(20, 30, 14.7),
	Vector3(13.9, 30, 11), Vector3(13.9, 30, 4),
	Vector3(13.9, 30, -3), Vector3(20, 30, -5.5),
	Vector3(27, 30, -2), Vector3(30.7, 30, 3),
	Vector3(30.7, 30, 8), Vector3(30.7, 30, 13.5),
]
var pending_spawn: bool = true
var demo: bool = "--demo" in OS.get_cmdline_user_args()


func _ready() -> void:
	car = get_tree().get_first_node_in_group(&"car") as VehicleBody3D
	_build_hud()
	if demo and car != null:
		var driver: Node = DRIVER.new()
		driver.set("car", car)
		driver.set("challenge", self)
		add_child(driver)


func _physics_process(_delta: float) -> void:
	# Query the imported terrain only once it has entered the physics world.
	if pending_spawn:
		pending_spawn = false
		for index: int in range(TOTAL):
			var location: Vector3 = LOCATIONS[index]
			location = road_position(location)
			location.y += 1.0
			var coin: Area3D = COIN.new()
			coin.name = "Coin%02d" % (index + 1)
			coin.position = location
			coin.connect("collected", _on_coin_collected)
			add_child(coin)


func _process(delta: float) -> void:
	if not finished:
		elapsed += delta
		timer_label.text = "經過時間 %.1f 秒" % elapsed


func _on_coin_collected(_coin: Area3D) -> void:
	count += 1
	score_label.text = "金幣 %d／%d" % [count, TOTAL]
	print("金幣 %d／%d，經過 %.1f 秒，車輛位置 %s" % [count, TOTAL, elapsed, car.global_position])
	if count == TOTAL:
		finished = true
		status_label.text = "挑戰完成！"
		print("挑戰完成，耗時 %.1f 秒" % elapsed)


func _build_hud() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	add_child(layer)
	var panel: PanelContainer = PanelContainer.new()
	panel.position = Vector2(24, 24)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.04, 0.07, 0.12, 0.88)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	panel.add_theme_stylebox_override("panel", style)
	layer.add_child(panel)
	var rows: VBoxContainer = VBoxContainer.new()
	rows.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(rows)
	score_label = _label(rows, "金幣 0／10", 38, Color(1, 0.82, 0.18))
	timer_label = _label(rows, "經過時間 0.0 秒", 28, Color.WHITE)
	status_label = _label(rows, "示範模式：自動駕駛中" if demo else "收集全部金幣，完成挑戰！", 22, Color.WHITE)
	# Move the original menu below the challenge; keep every original button.
	var original_ui: Control = get_parent().get_node("GameUI") as Control
	original_ui.position.y = 210


func _label(parent: VBoxContainer, text_value: String, font_size: int, tint: Color) -> Label:
	var label: Label = Label.new()
	label.text = text_value
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", tint)
	parent.add_child(label)
	return label


func road_position(location: Vector3) -> Vector3:
	var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(
		Vector3(location.x, 25, location.z), Vector3(location.x, -10, location.z))
	var excluded: Array[RID] = []
	if car != null:
		excluded.append(car.get_rid())
	for attempt: int in range(16):
		query.exclude = excluded
		var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
		if hit.is_empty():
			break
		var body: Node = hit["collider"]
		if body.name == &"Terrain":
			return hit["position"]
		excluded.append(hit["rid"])
	return Vector3(location.x, 8.7, location.z)
