extends Area3D

signal collected(coin: Area3D)

var taken: bool = false
var visual: MeshInstance3D
var age: float = 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1
	var shape: CollisionShape3D = CollisionShape3D.new()
	var sphere: SphereShape3D = SphereShape3D.new()
	sphere.radius = 1.25
	shape.shape = sphere
	add_child(shape)
	visual = MeshInstance3D.new()
	var disc: CylinderMesh = CylinderMesh.new()
	disc.top_radius = 0.65
	disc.bottom_radius = 0.65
	disc.height = 0.18
	visual.mesh = disc
	visual.rotation.x = PI / 2.0
	var gold: StandardMaterial3D = StandardMaterial3D.new()
	gold.albedo_color = Color(1.0, 0.7, 0.05)
	gold.metallic = 0.65
	gold.roughness = 0.25
	gold.emission_enabled = true
	gold.emission = Color(1.0, 0.55, 0.02)
	gold.emission_energy_multiplier = 1.8
	visual.material_override = gold
	add_child(visual)
	var light: OmniLight3D = OmniLight3D.new()
	light.light_color = Color(1.0, 0.65, 0.08)
	light.light_energy = 1.5
	light.omni_range = 3.0
	add_child(light)
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	age += delta
	rotation.y += delta * 2.2
	visual.position.y = sin(age * 3.0) * 0.12


func _on_body_entered(body: Node3D) -> void:
	if taken or not body.is_in_group(&"car"):
		return
	taken = true
	hide()
	set_deferred(&"monitoring", false)
	collected.emit(self)
	queue_free()
