@echo off
pushd "%~dp0"
"..\Godot\Godot_v4.7.2-stable_win64.exe" --path "truck_town" --audio-driver Dummy --rendering-method gl_compatibility
popd
