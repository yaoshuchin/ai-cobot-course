extends Control
# 僅用繪圖畫出地板、搜尋水波、路線與機器人；兩張圖共用同一份地圖。
signal painted(cell: Vector2i)
var lab: Control
var side: int = 0
var dragging: bool = false
var last_cell: Vector2i = Vector2i(-1,-1)
var cell_size: float = 24
var origin: Vector2 = Vector2.ZERO

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	custom_minimum_size = Vector2(0, 450)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL

func emit_cell(pos: Vector2) -> void:
	var cell: Vector2i = Vector2i(((pos - origin) / cell_size).floor())
	if cell == last_cell: return
	# 快速拖曳時補上中間格，避免滑鼠事件太疏而留下缺口。
	if last_cell.x >= 0 and last_cell.y >= 0:
		var difference: Vector2i = (cell - last_cell).abs()
		var count: int = mini(120, maxi(difference.x, difference.y))
		for i: int in range(1,count):
			painted.emit(Vector2i(Vector2(last_cell).lerp(Vector2(cell), float(i)/count).round()))
	last_cell = cell
	painted.emit(cell)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		dragging = event.pressed
		last_cell = Vector2i(-1,-1)
		if dragging: emit_cell(event.position)
		accept_event()
	elif event is InputEventMouseMotion and dragging:
		if event.button_mask & MOUSE_BUTTON_MASK_LEFT: emit_cell(event.position)
		else: dragging = false
	elif event is InputEventScreenTouch:
		dragging = event.pressed
		last_cell = Vector2i(-1,-1)
		if dragging: emit_cell(event.position)
		accept_event()
	elif event is InputEventScreenDrag:
		emit_cell(event.position)
		accept_event()

func _draw() -> void:
	if lab == null: return
	var data: RefCounted = lab.grid
	var robot: Dictionary = data.robots.astar if side == 0 else data.robots.bfs
	var tint: Color = Color(robot.color)
	var font: Font = get_theme_default_font()
	draw_style_box(lab.panel_style, Rect2(Vector2.ZERO, size))
	draw_string(font, Vector2(20, 38), robot.name, HORIZONTAL_ALIGNMENT_LEFT, -1, 30, tint)
	draw_string(font, Vector2(20, 70), "估計距離＋地形花費" if side == 0 else "由近到遠・先到先找", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color("a8bdd1"))
	cell_size = minf((size.x - 32) / data.rows[0].length(), (size.y - 125) / data.rows.size())
	origin = Vector2((size.x - cell_size * data.rows[0].length()) / 2, 90)
	var result: Dictionary = lab.results[side] if lab.results.size() > side else {}
	var order: Array = result.get("order", [])
	var visible_count: int = mini(int(lab.search_cursor), order.size())
	var seen: Dictionary = {}
	for i: int in range(visible_count): seen[order[i]] = i
	var path: Array = result.get("path", [])
	for y: int in range(data.rows.size()):
		for x: int in range(data.rows[0].length()):
			var p: Vector2i = Vector2i(x,y)
			var c: String = data.at(p)
			var rect: Rect2 = Rect2(origin + Vector2(p) * cell_size, Vector2.ONE * (cell_size - 1))
			var color: Color = Color("e7edf3")
			if c == "#": color = Color("354658")
			elif c == "~": color = Color("a97951")
			if seen.has(p): color = color.lerp(tint.lightened(0.45 - 0.32 * float(seen[p]) / maxf(1, order.size())), 0.6)
			if c == "S": color = Color("39b887")
			if c == "G": color = Color("ed6571")
			draw_rect(rect, color)
			var symbol: String = "S" if c == "S" else ("G" if c == "G" else ("×" + str(data.lab.mud_cost).trim_suffix(".0") if c == "~" else ""))
			if symbol == "" and data.lab.show_numbers and seen.has(p): symbol = str(int(seen[p])+1)
			if symbol != "": draw_string(font, rect.position + Vector2(2, cell_size * 0.76), symbol, HORIZONTAL_ALIGNMENT_CENTER, cell_size - 4, maxi(10,int(cell_size * 0.55)), Color("142434"))
			if c == "G":
				var pole: Vector2 = rect.position + Vector2(cell_size * 0.8,cell_size * 0.2)
				draw_line(pole, pole + Vector2(0, cell_size*0.55),Color("142434"),1)
				draw_colored_polygon(PackedVector2Array([pole,pole+Vector2(-cell_size*0.3,cell_size*0.12),pole+Vector2(0,cell_size*0.25)]),Color.WHITE)
	if lab.phase in ["move", "done"] and not path.is_empty():
		for i: int in range(1, path.size()):
			draw_line(center(path[i-1]), center(path[i]), Color(tint, 0.3), 3)
		var moved: int = lab.progress[side]
		for i: int in range(1, mini(moved + 1, path.size())):
			draw_line(center(path[i-1]), center(path[i]), Color(robot.trail), maxf(3, cell_size * 0.16))
	var robot_pos: Vector2 = center(data.start)
	var direction: Vector2 = Vector2.RIGHT
	if not path.is_empty() and lab.phase in ["move", "done"]:
		var idx: int = mini(lab.progress[side], path.size()-1)
		robot_pos = center(path[idx])
		if idx + 1 < path.size():
			direction = (Vector2(path[idx+1]) - Vector2(path[idx])).normalized()
			var ratio: float = clampf(lab.segment_time[side] / (data.cost(path[idx+1]) / float(data.robots.move_speed)), 0, 1)
			robot_pos = robot_pos.lerp(center(path[idx+1]), ratio)
	var radius: float = cell_size * 0.35
	draw_circle(robot_pos + Vector2(1,2), radius + 2, Color(0,0,0,0.35))
	match data.robots.shape:
		"square": draw_rect(Rect2(robot_pos - Vector2.ONE * radius, Vector2.ONE * radius * 2), tint)
		"triangle":
			var points: PackedVector2Array = PackedVector2Array([robot_pos + direction * radius * 1.25, robot_pos + direction.rotated(2.3) * radius, robot_pos + direction.rotated(-2.3) * radius])
			draw_colored_polygon(points, tint)
		_: draw_circle(robot_pos, radius, tint)
	draw_circle(robot_pos + Vector2(-radius * 0.25, -radius * 0.2), radius * 0.22, Color.WHITE)
	draw_circle(robot_pos + Vector2(radius * 0.3, -radius * 0.2), radius * 0.22, Color.WHITE)
	if lab.ranks[side] != "":
		var label_pos: Vector2 = robot_pos + Vector2(-85, -cell_size)
		label_pos.x = clampf(label_pos.x, 10, maxf(10, size.x-240))
		draw_rect(Rect2(label_pos + Vector2(-4,-28), Vector2(235,38)), Color("142434"))
		draw_string(font, label_pos, "抵達・" + lab.ranks[side], HORIZONTAL_ALIGNMENT_LEFT, -1, 24, tint)
	if not result.is_empty() and not result.found and lab.phase != "search":
		draw_string(font, Vector2(20,size.y-15), "找不到路・試著擦掉一些牆", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color("ffb0ad"))

func center(p: Vector2i) -> Vector2:
	return origin + (Vector2(p) + Vector2.ONE * 0.5) * cell_size
