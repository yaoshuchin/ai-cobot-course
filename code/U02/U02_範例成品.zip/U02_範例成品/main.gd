extends Control
# 教學實驗主控：先播搜尋，再讓兩台同時依地形成本移動。
const Grid = preload("res://grid.gd")
const Planner = preload("res://planner.gd")
const Board = preload("res://board.gd")
const Hud = preload("res://hud.gd")
var grid: RefCounted = Grid.new()
var results: Array[Dictionary] = []
var phase: String = "edit"
var search_cursor: float = 0
var progress: Array[int] = [0,0]
var segment_time: Array[float] = [0.0,0.0]
var elapsed: Array[float] = [0.0,0.0]
var ranks: Array[String] = ["", ""]
var tool: String = "#"
var boards: Array[Control] = []
var tools: Array[Button] = []
var panel_style: StyleBoxFlat
var status: Label
var warning_label: Label
var content: VBoxContainer
var arena: BoxContainer
var maps: GridContainer
var hud: PanelContainer
var start_button: Button
var paused: bool = false
var pause_button: Button
var step_button: Button
var map_name: String = "泥巴陷阱"
var demo: bool = false
var demo_time: float = 0
var demo_stage: int = -1
var race_time: float = 0
var portrait: bool = false

func _ready() -> void:
	grid.load_config()
	if "--self-test" in OS.get_cmdline_user_args():
		var test: RefCounted = load("res://self_test.gd").new()
		var ok: bool = test.run(grid)
		get_tree().quit(0 if ok else 1)
		return
	build_ui()
	demo = "--demo" in OS.get_cmdline_user_args()
	get_viewport().size_changed.connect(responsive)
	responsive()
	reset_race()
	if "--qa" in OS.get_cmdline_user_args():
		var runner: Node = load("res://qa/regression.gd").new()
		add_child(runner)
		runner.call_deferred("run", self)

func style(color: Color) -> StyleBoxFlat:
	var s: StyleBoxFlat = StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(14)
	s.content_margin_left = 20
	s.content_margin_right = 20
	s.content_margin_top = 16
	s.content_margin_bottom = 16
	return s

func build_ui() -> void:
	var t: Theme = Theme.new()
	t.default_font = load("res://fonts/NotoSansTC-Common.ttf")
	t.default_font_size = 26
	panel_style = style(Color("122235"))
	t.set_stylebox("panel", "PanelContainer", panel_style)
	t.set_stylebox("normal", "Button", style(Color("20374d")))
	t.set_stylebox("hover", "Button", style(Color("315571")))
	t.set_stylebox("pressed", "Button", style(Color("216f83")))
	var focus: StyleBoxFlat = style(Color(0,0,0,0))
	focus.border_color = Color("65e6c4")
	focus.set_border_width_all(3)
	t.set_stylebox("focus", "Button", focus)
	theme = t
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	var margin: MarginContainer = MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for key: String in ["margin_left","margin_right","margin_top","margin_bottom"]: margin.add_theme_constant_override(key,24)
	scroll.add_child(margin)
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation",16)
	margin.add_child(content)
	var title: Label = Label.new()
	title.text = grid.lab.title
	title.add_theme_font_size_override("font_size",42)
	content.add_child(title)
	var subtitle: Label = Label.new()
	subtitle.text = "曾小亮老師的科技實驗・同一張地圖，兩種找路思考"
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.add_theme_color_override("font_color",Color("a8bdd1"))
	content.add_child(subtitle)
	var toolbar: HFlowContainer = HFlowContainer.new()
	toolbar.add_theme_constant_override("h_separation",10)
	toolbar.add_theme_constant_override("v_separation",10)
	content.add_child(toolbar)
	var captions: Array[String] = ["牆","泥巴","橡皮擦","起點","終點"]
	var values: Array[String] = ["#","~",".","S","G"]
	for i: int in range(captions.size()):
		var button: Button = make_button(captions[i],toolbar,select_tool.bind(values[i]))
		button.toggle_mode = true
		tools.append(button)
	make_button("隨機迷宮",toolbar,randomize_map)
	make_button("清空",toolbar,clear_map)
	make_button("泥巴陷阱",toolbar,restore_map)
	make_button("迷宮地圖",toolbar,restore_maze)
	start_button = make_button("開始比賽",toolbar,start_race)
	make_button("重新比賽",toolbar,start_race)
	pause_button = make_button("暫停",toolbar,toggle_pause)
	step_button = make_button("下一格",toolbar,next_cell)
	var speed_row: HBoxContainer = HBoxContainer.new()
	content.add_child(speed_row)
	var speed_text: Label = Label.new()
	speed_text.text = "找路播放速度"
	speed_row.add_child(speed_text)
	var slider: HSlider = HSlider.new()
	slider.min_value = 5
	slider.max_value = 240
	slider.value = clampf(float(grid.lab.search_speed),5,240)
	grid.lab.search_speed = slider.value
	slider.custom_minimum_size = Vector2(240,56)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	speed_row.add_child(slider)
	var speed_value: Label = Label.new()
	speed_value.text = "%d 格／秒" % slider.value
	speed_row.add_child(speed_value)
	slider.value_changed.connect(func(value: float) -> void: grid.lab.search_speed = value; speed_value.text = "%d 格／秒" % value)
	status = Label.new()
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status.add_theme_color_override("font_color",Color("65e6c4"))
	content.add_child(status)
	arena = BoxContainer.new()
	arena.add_theme_constant_override("separation",16)
	content.add_child(arena)
	maps = GridContainer.new()
	maps.columns = 2
	maps.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	maps.add_theme_constant_override("h_separation",16)
	maps.add_theme_constant_override("v_separation",16)
	arena.add_child(maps)
	for i: int in range(2):
		var board: Control = Board.new()
		board.lab = self
		board.side = i
		board.painted.connect(paint)
		maps.add_child(board)
		boards.append(board)
	hud = Hud.new()
	hud.custom_minimum_size = Vector2(310,0)
	arena.add_child(hud)
	warning_label = Label.new()
	warning_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	warning_label.add_theme_font_size_override("font_size",22)
	warning_label.add_theme_color_override("font_color",Color("ffc28a"))
	warning_label.text = "；".join(grid.warnings) if not grid.warnings.is_empty() else "點選工具後，在任一張地圖點或拖曳。編輯會停止本輪比賽；外框、起點和終點受到保護。"
	content.add_child(warning_label)
	select_tool("#")

func make_button(caption: String, parent: Control, action: Callable) -> Button:
	var button: Button = Button.new()
	button.text = caption
	button.custom_minimum_size.y = 64
	button.pressed.connect(action)
	parent.add_child(button)
	return button

func responsive() -> void:
	if arena == null: return
	var physical: Vector2i = DisplayServer.window_get_size()
	# 網頁以實際視窗方向決定版面；直式保留適合閱讀的虛擬寬度。
	portrait = physical.y > physical.x
	get_window().content_scale_size = Vector2i(800,1280) if portrait else Vector2i(1600,900)
	maps.columns = 1 if portrait else 2
	arena.vertical = portrait
	hud.custom_minimum_size.x = 0 if portrait else 310
	for board: Control in boards:
		board.custom_minimum_size.y = 560.0 if portrait else maxf(460, size.y - 460)

func select_tool(value: String) -> void:
	tool = value
	var values: Array[String] = ["#","~",".","S","G"]
	for i: int in range(tools.size()): tools[i].button_pressed = values[i] == value

func reset_race() -> void:
	phase = "edit"
	paused = false
	results.clear()
	search_cursor = 0
	progress = [0,0]
	segment_time = [0.0,0.0]
	elapsed = [0.0,0.0]
	ranks = ["", ""]
	if status != null: status.text = map_name + "・先預測誰會贏，再按「開始比賽」"
	refresh_view()

func paint(cell: Vector2i) -> void:
	if grid.put(cell,tool):
		demo = false
		reset_race()

func randomize_map() -> void:
	demo = false
	grid.random_map()
	map_name = "隨機迷宮"
	reset_race()

func clear_map() -> void:
	demo = false
	grid.clear_map()
	map_name = "空白地圖"
	reset_race()

func restore_map() -> void:
	demo = false
	grid.parse_map(Grid.SAMPLE)
	map_name = "泥巴陷阱"
	reset_race()

func restore_maze() -> void:
	demo = false
	grid.parse_map(Grid.MAZE)
	map_name = "迷宮地圖"
	reset_race()

func toggle_pause() -> void:
	if phase not in ["search", "move"]: return
	demo = false
	paused = not paused
	refresh_view()

func next_cell() -> void:
	demo = false
	if phase == "done": return
	if phase == "edit": start_race()
	paused = true
	if phase == "search":
		search_cursor = floorf(search_cursor) + 1
		advance_race(0)
	elif phase == "move":
		# 前進到下一個抵達格子的時刻，保留泥巴的耗時差異。
		var remaining: float = INF
		for i: int in range(2):
			var path: Array = results[i].path
			if progress[i] + 1 < path.size():
				remaining = minf(remaining, grid.cost(path[progress[i]+1]) / float(grid.robots.move_speed) - segment_time[i])
		advance_race(maxf(0,remaining) if is_finite(remaining) else 0.0)
	refresh_view()

func refresh_view() -> void:
	if pause_button != null:
		pause_button.text = "繼續" if paused else "暫停"
		pause_button.disabled = phase not in ["search", "move"]
		step_button.disabled = phase == "done"
	for board: Control in boards: board.queue_redraw()
	if hud != null: hud.refresh(self)

func start_race() -> void:
	reset_race()
	var planner: RefCounted = Planner.new(grid)
	results = [planner.astar(grid.start,grid.goal),planner.bfs(grid.start,grid.goal)]
	phase = "search"
	status.text = "第一階段・淡色格子依序出現，看看誰找過的格子較少"
	race_time = 0
	refresh_view()

func _process(delta: float) -> void:
	if status == null: return
	if demo:
		demo_time += delta
		var stage: int = mini(2,int(demo_time / 6.0))
		if stage != demo_stage:
			demo_stage = stage
			if stage == 0: grid.parse_map(Grid.SAMPLE)
			elif stage == 1:
				grid.parse_map(Grid.SAMPLE)
				grid.put(Vector2i(3,1),"#")
			else: grid.random_map()
			start_race()
			print("DEMO_STAGE ", stage+1)
		if phase == "search": search_cursor += delta * 220
	if not paused: advance_race(delta)
	if demo:
		status.text = "示範 %d／3・%s（加速播放）" % [demo_stage+1,["泥巴陷阱比賽","自動加一道牆再比賽","隨機迷宮再比賽"][demo_stage]]
	refresh_view()

func advance_race(delta: float) -> void:
	if phase == "search":
		search_cursor += delta * float(grid.lab.search_speed)
		if search_cursor >= maxi(results[0].explored, results[1].explored):
			phase = "move"
			status.text = "第二階段・同時出發！地板花費 1，泥巴比較慢"
	elif phase == "move":
		var move_delta: float = delta * (2.0 if demo else 1.0)
		race_time += move_delta
		var finished: int = 0
		for i: int in range(2):
			var path: Array = results[i].path
			if path.is_empty():
				finished += 1
				continue
			segment_time[i] += move_delta
			while progress[i] + 1 < path.size():
				var duration: float = grid.cost(path[progress[i]+1]) / float(grid.robots.move_speed)
				if segment_time[i] + 0.000001 < duration: break
				segment_time[i] -= duration
				progress[i] += 1
			elapsed[i] = minf(race_time, float(results[i].cost) / float(grid.robots.move_speed))
			if progress[i] == path.size()-1:
				finished += 1
				var other: int = 1-i
				if not results[other].found: ranks[i] = "唯一抵達"
				elif is_equal_approx(float(results[i].cost),float(results[other].cost)): ranks[i] = "並列第一"
				else: ranks[i] = "第一名" if float(results[i].cost) < float(results[other].cost) else "第二名"
		if finished == 2:
			phase = "done"
			status.text = "比賽結束・比較找過幾格、步數與花費，再改地圖試一次！" if results[0].found else "找不到路・兩邊都被牆擋住了，試著用橡皮擦打開通道"
