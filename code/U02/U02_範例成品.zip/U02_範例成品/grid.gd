extends RefCounted
# 地圖與設定資料；檔案不完整時採用預設值，並保留中文提醒。
const MAZE: String = "######################\n#S.....#.............#\n#.####.#.#######.###.#\n#.#....#.......#...#.#\n#.#.######.###.###.#.#\n#...#~~~~~...#.....#.#\n###.#~~~~~.#.#####.#.#\n#...#~~~~~.#.....#...#\n#.###......#####.###.#\n#.....####.....#.....#\n#.###....#.###.#.###.#\n#...#..#.......#...#G#\n######################"
const SAMPLE: String = "######################\n#....................#\n#....................#\n#.....~~~~~~~~~~.....#\n#.....~~~~~~~~~~.....#\n#S....~~~~~~~~~~....G#\n#.....~~~~~~~~~~.....#\n#.....~~~~~~~~~~.....#\n#.....~~~~~~~~~~.....#\n#.....~~~~~~~~~~.....#\n#....................#\n#....................#\n######################"
var rows: Array[String] = []
var start: Vector2i = Vector2i(1, 1)
var goal: Vector2i = Vector2i(20, 11)
var lab: Dictionary = {"title":"機器人找路實驗室", "search_speed":40, "mud_cost":3, "diagonal":false, "show_numbers":false}
var robots: Dictionary = {"astar":{"name":"A* 小藍", "color":"#2E86FF", "trail":"#7FB8FF"}, "bfs":{"name":"BFS 小橘", "color":"#FF8C2E", "trail":"#FFC28A"}, "move_speed":6.0, "shape":"circle"}
var warnings: Array[String] = []

func read_json(path: String, defaults: Dictionary) -> Dictionary:
	var result: Dictionary = defaults.duplicate(true)
	var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(path)) if FileAccess.file_exists(path) else null
	if not raw is Dictionary:
		warnings.append(path.get_file() + " 無法讀取，已用預設值")
		return result
	for key: String in defaults:
		if not raw.has(key):
			warnings.append(path.get_file() + " 缺少 " + key + "，已用預設值")
		elif defaults[key] is Dictionary:
			if raw[key] is Dictionary:
				for field: String in defaults[key]:
					if raw[key].has(field) and raw[key][field] is String and (field == "name" or Color.html_is_valid(raw[key][field])):
						result[key][field] = raw[key][field]
					else:
						warnings.append("機器人 " + field + " 無效，已用預設值")
			else:
				warnings.append("機器人設定無效，已用預設值")
		elif typeof(raw[key]) == typeof(defaults[key]) or (raw[key] is float and defaults[key] is int) or (raw[key] is int and defaults[key] is float):
			result[key] = raw[key]
		else:
			warnings.append(key + " 格式無效，已用預設值")
	return result

func load_config() -> void:
	lab = read_json("res://lab.json", lab)
	robots = read_json("res://robot.json", robots)
	for key: String in ["mud_cost", "search_speed"]:
		if not is_finite(float(lab[key])) or float(lab[key]) < 1 or float(lab[key]) > 1000:
			warnings.append(key + " 超出範圍，已用預設值")
			lab[key] = 3 if key == "mud_cost" else 40
	if not is_finite(float(robots.move_speed)) or float(robots.move_speed) <= 0 or float(robots.move_speed) > 60:
		robots.move_speed = 6.0
		warnings.append("移動速度無效，已用預設值")
	if robots.shape not in ["circle", "square", "triangle"]:
		robots.shape = "circle"
		warnings.append("機器人形狀無效，已用圓形")
	var text: String = FileAccess.get_file_as_string("res://map.txt") if FileAccess.file_exists("res://map.txt") else ""
	if not parse_map(text):
		warnings.append("map.txt 無效，已用範例地圖")
		parse_map(SAMPLE)

func parse_map(text: String) -> bool:
	var candidate: PackedStringArray = text.strip_edges().split("\n")
	if candidate.size() < 5 or candidate.size() > 40:
		return false
	var width: int = candidate[0].strip_edges().length()
	if width < 5 or width > 60:
		return false
	var starts: int = 0
	var goals: int = 0
	for y: int in range(candidate.size()):
		candidate[y] = candidate[y].strip_edges()
		if candidate[y].length() != width:
			return false
		for x: int in range(width):
			var c: String = candidate[y][x]
			if c not in ["#", ".", "~", "S", "G"] or ((x == 0 or y == 0 or x == width - 1 or y == candidate.size() - 1) and c != "#"):
				return false
			starts += int(c == "S")
			goals += int(c == "G")
	if starts != 1 or goals != 1:
		return false
	rows.assign(candidate)
	for y: int in range(rows.size()):
		for x: int in range(width):
			if rows[y][x] == "S": start = Vector2i(x, y)
			if rows[y][x] == "G": goal = Vector2i(x, y)
	return true

func at(p: Vector2i) -> String:
	if p.y < 0 or p.y >= rows.size() or p.x < 0 or p.x >= rows[0].length(): return "#"
	return rows[p.y][p.x]

func cost(p: Vector2i) -> float:
	return float(lab.mud_cost) if at(p) == "~" else 1.0

func neighbors(p: Vector2i) -> Array[Vector2i]:
	var result: Array[Vector2i] = []
	var dirs: Array[Vector2i] = [Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT, Vector2i.UP]
	if lab.diagonal: dirs.append_array([Vector2i(1, 1), Vector2i(-1, 1), Vector2i(-1, -1), Vector2i(1, -1)])
	for d: Vector2i in dirs:
		if at(p + d) == "#": continue
		# 不可穿越牆角；斜走仍算一步，成本由目的格決定。
		if d.x != 0 and d.y != 0 and (at(p + Vector2i(d.x, 0)) == "#" or at(p + Vector2i(0, d.y)) == "#"): continue
		result.append(p + d)
	return result

func put(p: Vector2i, tool: String) -> bool:
	if p.x <= 0 or p.y <= 0 or p.x >= rows[0].length() - 1 or p.y >= rows.size() - 1: return false
	if tool == "S" or tool == "G":
		if (tool == "S" and p == goal) or (tool == "G" and p == start): return false
		var previous: Vector2i = start if tool == "S" else goal
		rows[previous.y][previous.x] = "."
		if tool == "S": start = p
		else: goal = p
	elif p == start or p == goal: return false
	rows[p.y][p.x] = tool
	return true

func clear_map() -> void:
	for y: int in range(1, rows.size() - 1):
		for x: int in range(1, rows[0].length() - 1):
			if Vector2i(x,y) != start and Vector2i(x,y) != goal: rows[y][x] = "."

func random_map() -> void:
	clear_map()
	for y: int in range(1, rows.size() - 1):
		for x: int in range(1, rows[0].length() - 1):
			put(Vector2i(x,y), "#" if randf() < 0.29 else ("~" if randf() < 0.15 else "."))
	# 留一條保證可走的走廊，避免每次隨機後都無路可走。
	var p: Vector2i = start
	while p.x != goal.x:
		p.x += 1 if goal.x > p.x else -1
		put(p, ".")
	while p.y != goal.y:
		p.y += 1 if goal.y > p.y else -1
		put(p, ".")
