extends PanelContainer
# 統計面板使用同一套計時規則：用時從行走開始計算，不含搜尋動畫。
var labels: Array[Label] = []
var conclusion: Label
var note: Label

func _ready() -> void:
	var box: VBoxContainer = VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	add_child(box)
	var heading: Label = Label.new()
	heading.text = "比賽觀察站"
	heading.add_theme_font_size_override("font_size", 30)
	box.add_child(heading)
	for i: int in range(2):
		var label: Label = Label.new()
		label.add_theme_font_size_override("font_size", 24)
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.add_theme_color_override("font_color", Color("7fb8ff") if i == 0 else Color("ffc28a"))
		box.add_child(label)
		labels.append(label)
	conclusion = Label.new()
	conclusion.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	conclusion.add_theme_font_size_override("font_size", 32)
	conclusion.add_theme_color_override("font_color", Color("65e6c4"))
	box.add_child(conclusion)
	note = Label.new()
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.add_theme_font_size_override("font_size", 20)
	box.add_child(note)
	note.text = "預測一下：步數少，就一定比較快嗎？\n\n地板花費 1・泥巴花費 3\n用時＝花費÷移動速度\n不包含找路動畫的時間。\n\nS 起點・G 終點\n深灰是牆・淡色是找過的格子"

func refresh(lab: Control) -> void:
	if labels.size() < 2: return
	for i: int in range(2):
		var robot: Dictionary = lab.grid.robots.astar if i == 0 else lab.grid.robots.bfs
		var r: Dictionary = lab.results[i] if lab.results.size() > i else {}
		var explored: int = mini(int(lab.search_cursor), int(r.get("explored",0)))
		labels[i].text = "%s\n找過 %d 格・%d 步\n花費 %s・%.2f 秒%s" % [robot.name, explored, r.get("steps",0), str(r.get("cost",0)).trim_suffix(".0"), lab.elapsed[i], ("\n" + lab.ranks[i]) if lab.ranks[i] != "" else ""]
	note.text = "地板 1・泥巴 %s\n速度 %s 單位／秒\n用時＝花費÷速度\n（不含搜尋動畫）\nS 起點・G 終點\n步數少就比較快嗎？" % [str(lab.grid.lab.mud_cost).trim_suffix(".0"), str(lab.grid.robots.move_speed).trim_suffix(".0")]

	conclusion.text = ""
	if lab.phase == "done" and lab.results.size() == 2:
		var a: Dictionary = lab.results[0]
		var b: Dictionary = lab.results[1]
		if not a.found or not b.found:
			conclusion.text = "找不到路，請打開通道再試一次"
		else:
			var steps: int = a.steps - b.steps
			var saving: float = b.cost - a.cost
			var step_text: String = "步數相同" if steps == 0 else (("多走 %d 步" if steps > 0 else "少走 %d 步") % absi(steps))
			var cost_text: String = "花費相同" if is_zero_approx(saving) else (("少花 %s 點力氣" if saving > 0 else "多花 %s 點力氣") % str(absf(saving)).trim_suffix(".0"))
			conclusion.text = "A* %s，但%s" % [step_text,cost_text] if steps != 0 and not is_zero_approx(saving) else "A* %s，%s" % [step_text,cost_text]
