extends RefCounted
# 自行實作佇列 BFS 與有權重 A*。探索順序定義為「取出並展開」，包含終點。
var grid: RefCounted

func _init(data: RefCounted) -> void:
	grid = data

func bfs(start: Vector2i, goal: Vector2i) -> Dictionary:
	var queue: Array[Vector2i] = [start]
	var parent: Dictionary = {start: start}
	var order: Array[Vector2i] = []
	var head: int = 0
	while head < queue.size():
		var p: Vector2i = queue[head]
		head += 1
		order.append(p)
		if p == goal: break
		for next: Vector2i in grid.neighbors(p):
			if not parent.has(next):
				parent[next] = p
				queue.append(next)
	return pack(parent, order, start, goal)

func heuristic(p: Vector2i, goal: Vector2i) -> float:
	var d: Vector2i = (p - goal).abs()
	# 四方向用曼哈頓距離；可斜走時用切比雪夫距離，維持最小花費保證。
	return float(maxi(d.x, d.y) if grid.lab.diagonal else d.x + d.y)

func astar(start: Vector2i, goal: Vector2i) -> Dictionary:
	var open: Array[Vector2i] = [start]
	var parent: Dictionary = {start: start}
	var scores: Dictionary = {start: 0.0}
	var closed: Dictionary = {}
	var order: Array[Vector2i] = []
	while not open.is_empty():
		var best: int = 0
		for i: int in range(1, open.size()):
			if float(scores[open[i]]) + heuristic(open[i], goal) < float(scores[open[best]]) + heuristic(open[best], goal): best = i
		var p: Vector2i = open[best]
		open.remove_at(best)
		if closed.has(p): continue
		closed[p] = true
		order.append(p)
		if p == goal: break
		for next: Vector2i in grid.neighbors(p):
			var tentative: float = float(scores[p]) + grid.cost(next)
			if tentative < float(scores.get(next, INF)):
				scores[next] = tentative
				parent[next] = p
				if not open.has(next): open.append(next)
	return pack(parent, order, start, goal)

func pack(parent: Dictionary, order: Array[Vector2i], start: Vector2i, goal: Vector2i) -> Dictionary:
	var path: Array[Vector2i] = []
	var total: float = 0
	if parent.has(goal):
		var p: Vector2i = goal
		while p != start:
			path.push_front(p)
			total += grid.cost(p)
			p = parent[p]
		path.push_front(start)
	return {"path":path, "order":order, "explored":order.size(), "steps":maxi(0, path.size()-1), "cost":total, "found":not path.is_empty()}
