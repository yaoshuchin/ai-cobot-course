extends RefCounted
# 與 A* 分開實作 Dijkstra；最少步數用全圖反覆鬆弛，避免拿 BFS 自己核對自己。
const Grid = preload("res://grid.gd")
const Planner = preload("res://planner.gd")
var failures: Array[String] = []
var checks: int = 0

func check(value: bool, message: String) -> void:
	checks += 1
	if not value: failures.append(message)

func dijkstra(data: RefCounted, weighted: bool) -> float:
	var distances: Dictionary = {data.start:0.0}
	var visited: Dictionary = {}
	while true:
		var best: Vector2i = Vector2i(-1,-1)
		var minimum: float = INF
		for p: Vector2i in distances:
			if not visited.has(p) and float(distances[p]) < minimum:
				minimum = distances[p]
				best = p
		if best == Vector2i(-1,-1): return INF
		if best == data.goal: return minimum
		visited[best] = true
		for next: Vector2i in data.neighbors(best):
			var candidate: float = minimum + (data.cost(next) if weighted else 1.0)
			if candidate < float(distances.get(next,INF)): distances[next] = candidate
	return INF

func minimum_steps(data: RefCounted) -> float:
	var distances: Dictionary = {data.start:0.0}
	for iteration: int in range(data.rows.size() * data.rows[0].length()):
		var changed: bool = false
		for y: int in range(data.rows.size()):
			for x: int in range(data.rows[0].length()):
				var p: Vector2i = Vector2i(x,y)
				if not distances.has(p): continue
				for next: Vector2i in data.neighbors(p):
					var d: float = float(distances[p])+1
					if d < float(distances.get(next,INF)):
						distances[next] = d
						changed = true
		if not changed: break
	return float(distances.get(data.goal,INF))

func verify(data: RefCounted, tag: String) -> void:
	var planner: RefCounted = Planner.new(data)
	var a: Dictionary = planner.astar(data.start,data.goal)
	var b: Dictionary = planner.bfs(data.start,data.goal)
	var optimum: float = dijkstra(data,true)
	var steps: float = minimum_steps(data)
	check(a.found == is_finite(optimum),tag+" A* 可達性")
	check(b.found == is_finite(steps),tag+" BFS 可達性")
	if a.found: check(is_equal_approx(a.cost,optimum),tag+" A* 最小花費")
	if b.found: check(is_equal_approx(float(b.steps),steps),tag+" BFS 最少步數")
	for r: Dictionary in [a,b]:
		var seen: Dictionary = {}
		for p: Vector2i in r.order:
			check(not seen.has(p) and data.at(p) != "#",tag+" 探索不重複且不穿牆")
			seen[p] = true
		var sum: float = 0
		for i: int in range(1,r.path.size()):
			check(data.neighbors(r.path[i-1]).has(r.path[i]),tag+" 路線相鄰")
			sum += data.cost(r.path[i])
		check(is_equal_approx(sum,r.cost),tag+" 花費加總")

func run(data: RefCounted) -> bool:
	seed(20261015)
	check(data.warnings.is_empty(),"預設設定檔讀取")
	check(data.rows.size() == 13 and data.rows[0].length() == 22,"範例尺寸 22×13")
	verify(data,"範例")
	var p: RefCounted = Planner.new(data)
	var a: Dictionary = p.astar(data.start,data.goal)
	var b: Dictionary = p.bfs(data.start,data.goal)
	check(a.steps == 25 and a.cost == 25 and b.steps == 19 and b.cost == 39,"預設泥巴陷阱：多走6步省14點")
	for cell: Vector2i in a.path:
		check(data.at(cell) != "~", "小藍完全避開泥巴")
	var mud_count: int = 0
	for cell: Vector2i in b.path:
		mud_count += int(data.at(cell) == "~")
	check(mud_count == 10, "小橘直線穿過10格泥巴")
	print("DEFAULT_METRICS A* explored=%d steps=%d cost=%s seconds=%.2f | BFS explored=%d steps=%d cost=%s seconds=%.2f" % [a.explored,a.steps,a.cost,a.cost/float(data.robots.move_speed),b.explored,b.steps,b.cost,b.cost/float(data.robots.move_speed)])
	var d: RefCounted = Grid.new()
	check(d.parse_map(Grid.MAZE),"保留迷宮地圖")
	check(FileAccess.get_file_as_string("res://maze_map.txt").replace("\r", "").strip_edges() == Grid.MAZE,"迷宮原圖備份一致")
	verify(d,"迷宮地圖")
	d.parse_map("#########\n#S~~~~~G#\n#.......#\n#.......#\n#########")
	verify(d,"泥巴比較")
	p = Planner.new(d)
	a = p.astar(d.start,d.goal)
	b = p.bfs(d.start,d.goal)
	check(a.cost < b.cost and a.steps > b.steps,"泥巴使 A* 繞路而 BFS 穿越")
	for trial: int in range(12):
		d.parse_map(Grid.SAMPLE)
		d.lab.diagonal = trial % 2 == 1
		d.lab.mud_cost = 1 + trial
		d.random_map()
		verify(d,"隨機 %d" % trial)
	d.lab.diagonal = false
	d.parse_map(Grid.MAZE)
	d.put(Vector2i(2,1),"#")
	d.put(Vector2i(1,2),"#")
	verify(d,"完全封住起點")
	check(not Planner.new(d).astar(d.start,d.goal).found,"找不到路")
	check(not d.parse_map("bad") and not d.parse_map("#####\n#S.G#\n#..#\n#####"),"拒絕破損地圖")
	check(not d.put(Vector2i(0,0),".") and not d.put(d.goal,"#"),"保護外框與端點")
	var cfg: Dictionary = d.read_json("res://不存在.json",{"title":"預設標題"}) # lint:ignore res_path
	check(cfg.title == "預設標題" and not d.warnings.is_empty(),"缺檔降級與提醒")
	if failures.is_empty():
		print("SELF_TEST PASS %d checks; config, 22x13 map, BFS minimum steps, A* = Dijkstra, mud, diagonal, 12 random maps, blocked route, fallback" % checks)
		return true
	print("SELF_TEST FAIL " + "；".join(failures))
	return false
