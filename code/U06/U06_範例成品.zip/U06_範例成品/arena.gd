extends Node3D
# 全部以內建立方體建場景；一個單位是一公尺，介面換算成公分。
var car: Node3D
var target: Vector3 = Vector3(1,0,0.75)
var moving: bool = false
var speed: float = 0.4
var trail_color: Color = Color.CYAN
var trail_last: Vector3
var trails: Node3D
var font: Font = preload("res://fonts/NotoSansTC-Common.ttf")
signal arrived

func box(parent: Node3D, pos: Vector3, dimensions: Vector3, color: Color) -> MeshInstance3D:
	var node: MeshInstance3D = MeshInstance3D.new()
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = dimensions
	node.mesh = mesh
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.85
	node.material_override = mat
	parent.add_child(node)
	node.position = pos
	return node

func build(markers: Array, cfg: Dictionary) -> void:
	box(self,Vector3(1,-0.025,0.75),Vector3(2,0.05,1.5),Color("#e0e8ec"))
	for x: int in range(21):
		box(self,Vector3(x*0.1,0.001,0.75),Vector3(0.004 if x%5==0 else 0.0015,0.002,1.5),Color("#718b9d") if x%5==0 else Color("#b7c8d1"))
	for z: int in range(16):
		box(self,Vector3(1,0.002,z*0.1),Vector3(2,0.002,0.004 if z%5==0 else 0.0015),Color("#718b9d") if z%5==0 else Color("#b7c8d1"))
	for x: int in range(0,201,50):
		floor_text(str(x),Vector3(clampf(x/100.0,0.12,1.88),0.035,1.40))
	for z: int in range(0,151,50):
		floor_text(str(z),Vector3(0.06,0.035,clampf(z/100.0,0.04,1.29)))
	for m: Dictionary in markers:
		var p: Array = m.pos
		var col: Color = Color(m.color)
		box(self,Vector3(p[0]/100.0,0.008,p[1]/100.0),Vector3(0.115,0.008,0.028),col)
		box(self,Vector3(p[0]/100.0,0.009,p[1]/100.0),Vector3(0.028,0.008,0.115),col)
	car = Node3D.new()
	add_child(car)
	car.position = target
	box(car,Vector3(0,0.055,0),Vector3(0.12,0.075,0.17),Color(cfg.body_color))
	box(car,Vector3(0,0.1,-0.04),Vector3(0.075,0.025,0.065),Color("#15304a"))
	box(car,Vector3(0,0.065,-0.09),Vector3(0.07,0.018,0.008),Color("#fff2ae"))
	for x: float in [-0.072,0.072]:
		for z: float in [-0.05,0.05]:
			box(car,Vector3(x,0.03,z),Vector3(0.025,0.05,0.05),Color("#182331"))
	speed = maxf(1.0,float(cfg.speed_cm))/100.0
	trail_color = Color(cfg.trail_color)
	trails = Node3D.new()
	add_child(trails)
	trail_last = car.position

func floor_text(value: String, pos: Vector3) -> void:
	var label: Label3D = Label3D.new()
	label.text = value
	label.font = font
	label.font_size = 96
	label.pixel_size = 0.001
	label.modulate = Color("#274157")
	label.no_depth_test = true
	add_child(label)
	label.position = pos
	# 兩個相機朝向不同，刻度各自朝向鏡頭，保持正向可讀。
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED

func drive(cm: Vector2) -> void:
	target = Vector3(cm.x/100.0,0,cm.y/100.0)
	moving = true

func _process(delta: float) -> void:
	# 保留最近五秒，最後兩秒淡出；停車後繼續消退。
	for dot: MeshInstance3D in trails.get_children():
		var age: float = float(dot.get_meta("age",0.0))+delta
		dot.set_meta("age",age)
		if age>=5.0:
			dot.free()
		else:
			var material: StandardMaterial3D = dot.material_override
			material.albedo_color.a = clampf((5.0-age)/2.0,0.0,1.0)
	if not moving:
		return
	var direction: Vector3 = target-car.position
	if direction.length() > 0.001:
		var angle: float = atan2(-direction.x,-direction.z)
		car.rotation.y = rotate_toward(car.rotation.y,angle,delta*4.0)
		if absf(angle_difference(car.rotation.y,angle)) > 0.05:
			return
	car.position = car.position.move_toward(target,speed*delta)
	if car.position.distance_to(trail_last)>0.025:
		var dot: MeshInstance3D = box(trails,car.position+Vector3(0,0.005,0),Vector3(0.018,0.004,0.018),trail_color)
		var material: StandardMaterial3D = dot.material_override
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		dot.set_meta("age",0.0)
		trail_last = car.position
		if trails.get_child_count()>600:
			trails.get_child(0).free()
	if car.position.distance_to(target)<0.00001:
		moving = false
		arrived.emit()
