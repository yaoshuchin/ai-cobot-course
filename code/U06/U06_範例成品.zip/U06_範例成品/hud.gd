extends Control
# 固定教室投影版面，畫面縮放時由 Godot 統一縮放；透明圖層畫的是 H 的反投影。
var owner_lab: Node
var feed: TextureRect
var map_feed: TextureRect
var status: Label
var results: Label
var comparison: Label
var matrix: Label
var note: Label
var hover: Label
var show_grid: bool = false
var map_rect: Rect2 = Rect2(1100,150,460,300)
var camera_rect: Rect2 = Rect2(30,150,1020,680)
var last_truth: Vector2 = Vector2(-1,-1)
var last_calc: Vector2 = Vector2(-1,-1)
var clicked: Array = []
var ui_font: Font = preload("res://fonts/NotoSansTC-Common.ttf")

func label_at(text_value: String, rect: Rect2, font_size: int = 26, col: Color = Color("#dbe9f4")) -> Label:
	var l: Label = Label.new()
	l.text = text_value
	l.position = rect.position
	l.size = rect.size
	l.add_theme_font_size_override("font_size",font_size)
	l.add_theme_color_override("font_color",col)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l

func button_at(text_value: String, rect: Rect2, action: Callable) -> Button:
	var b: Button = Button.new()
	b.text = text_value
	b.position = rect.position
	b.size = rect.size
	b.pressed.connect(action)
	add_child(b)
	return b

func build(lab: Node, viewport: SubViewport, map_view: SubViewport) -> void:
	owner_lab = lab
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var t: Theme = Theme.new()
	t.default_font = ui_font
	t.default_font_size = 24
	for state: String in ["normal","hover","pressed","focus"]:
		var style: StyleBoxFlat = StyleBoxFlat.new()
		style.bg_color = Color("#20384f") if state=="normal" else Color("#305c79")
		style.set_corner_radius_all(10)
		style.set_border_width_all(3 if state=="focus" else 1)
		style.border_color = Color("#57dac9")
		t.set_stylebox(state,"Button",style)
	theme = t
	label_at("座標轉換實驗室：點偏挑戰版",Rect2(30,18,700,60),42)
	label_at("曾小亮老師的科技教室　／　畫面點哪、車就到哪",Rect2(32,80,1000,40),26,Color("#91b7cc"))
	label_at("斜拍相機　｜　先校正，再點地板",Rect2(30,115,1020,35),24)
	label_at("俯視對照　｜　200 × 150 公分",Rect2(1100,110,470,40),24)
	feed = TextureRect.new()
	feed.texture = viewport.get_texture()
	feed.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	feed.position = camera_rect.position
	feed.size = camera_rect.size
	feed.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(feed)
	map_feed = TextureRect.new()
	map_feed.texture = map_view.get_texture()
	map_feed.position = map_rect.position
	map_feed.size = map_rect.size
	map_feed.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	map_feed.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(map_feed)
	# 另放最上層繪圖控制項，讓反投影線不會被影像蓋住。
	var overlay: Control = Control.new()
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.draw.connect(draw_overlay.bind(overlay))
	add_child(overlay)
	status = label_at("請點紅色標記（第 1／4 點）",Rect2(40,160,990,45),30,Color("#e6f5ff"))
	button_at("自動校正",Rect2(1100,470,220,52),lab.auto_calibrate)
	button_at("重新手點",Rect2(1340,470,220,52),lab.reset_calibration)
	button_at("顯示格線投影",Rect2(1100,535,270,52),func() -> void: show_grid = not show_grid)
	button_at("換角度",Rect2(1390,535,170,52),lab.change_angle)
	button_at("點偏示範",Rect2(1100,18,220,58),lab.start_challenge)
	comparison = label_at("",Rect2(1100,590,480,156),18,Color("#ffd988"))
	matrix = label_at("矩陣 H：等待四點校正\n\n像素 → 地面公分",Rect2(1100,824,470,76),14,Color("#83e1cf"))
	results = label_at("點擊後顯示換算結果與誤差",Rect2(1100,746,480,78),16)
	note = label_at("",Rect2(30,840,1030,52),22,Color("#ffd988"))
	hover = label_at("",Rect2(0,0,330,40),22,Color("#102737"))
	set_process(true)

func _process(_delta: float) -> void:
	# 每幀更新反投影圖層。
	for child: Node in get_children():
		if child is Control:
			child.queue_redraw()
	var local: Vector2 = get_local_mouse_position()
	hover.visible = camera_rect.has_point(local) and not owner_lab.calib.h.is_empty()
	if hover.visible:
		var cm: Vector2 = owner_lab.calib.to_ground(screen_to_pixel(local))
		hover.text = "地面（%.1f，%.1f）公分" % [cm.x,cm.y]
		hover.position = Vector2(clampf(local.x+14,35,700),clampf(local.y+20,210,780))

func screen_to_pixel(p: Vector2) -> Vector2:
	return (p-camera_rect.position)/camera_rect.size*Vector2(owner_lab.view.size)

func pixel_to_screen(p: Vector2) -> Vector2:
	return camera_rect.position+p/Vector2(owner_lab.view.size)*camera_rect.size

func draw_overlay(canvas: Control) -> void:
	if show_grid and not owner_lab.calib.h.is_empty():
		for x: int in range(0,201,10):
			projected_line(canvas,Vector2(x,0),Vector2(x,150),x%50==0)
		for y: int in range(0,151,10):
			projected_line(canvas,Vector2(0,y),Vector2(200,y),y%50==0)
	for i: int in range(clicked.size()):
		var p: Vector2 = pixel_to_screen(clicked[i])
		var actual_pixel: Vector2 = owner_lab.marker_pixel(i)
		var q: Vector2 = pixel_to_screen(actual_pixel)
		canvas.draw_line(p,q,Color.WHITE,2,true)
		canvas.draw_arc(p,10,0,TAU,32,Color("#ff64ba"),3,true)
		canvas.draw_line(q-Vector2(7,0),q+Vector2(7,0),Color("#54ffe0"),3,true)
		canvas.draw_line(q-Vector2(0,7),q+Vector2(0,7),Color("#54ffe0"),3,true)
		var label_pos: Vector2 = Vector2(clampf(q.x-85,40,800),clampf(q.y+34,220,765))
		canvas.draw_style_box(overlay_style(),Rect2(label_pos-Vector2(4,23),Vector2(245,82)))
		canvas.draw_string(ui_font,label_pos,"%d 你點的位置 ○" % [i+1],HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color.WHITE)
		canvas.draw_string(ui_font,label_pos+Vector2(0,23),"標記真正的位置 ＋",HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color("#54ffe0"))
		canvas.draw_string(ui_font,label_pos+Vector2(0,48),"差 %.1f 像素" % clicked[i].distance_to(actual_pixel),HORIZONTAL_ALIGNMENT_LEFT,-1,21,Color("#ffd988"))
	if last_truth.x>=0:
		var p: Vector2 = map_point(last_truth)
		canvas.draw_circle(p,9,Color("#ff4488"),false,3,true)
		p = map_point(last_calc)
		canvas.draw_line(p-Vector2(10,0),p+Vector2(10,0),Color("#008e9c"),3,true)
		canvas.draw_line(p-Vector2(0,10),p+Vector2(0,10),Color("#008e9c"),3,true)
		if not owner_lab.arena.moving:
			var pos: Vector3 = owner_lab.arena.car.position
			canvas.draw_circle(map_point(Vector2(pos.x,pos.z)*100),4,Color("#10263e"))

func map_point(cm: Vector2) -> Vector2:
	return map_rect.position+owner_lab.top_camera.unproject_position(Vector3(cm.x/100,0,cm.y/100))/Vector2(owner_lab.map_view.size)*map_rect.size

func projected_line(canvas: Control, a: Vector2, b: Vector2, major: bool) -> void:
	var p: Vector2 = pixel_to_screen(owner_lab.calib.to_pixel(a))
	var q: Vector2 = pixel_to_screen(owner_lab.calib.to_pixel(b))
	if camera_rect.has_point(p) and camera_rect.has_point(q):
		canvas.draw_line(p,q,Color(0.0,0.65,0.7,0.85 if major else 0.45),2.4 if major else 1.0,true)

func overlay_style() -> StyleBoxFlat:
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.04,0.09,0.15,0.92)
	style.set_corner_radius_all(5)
	return style
