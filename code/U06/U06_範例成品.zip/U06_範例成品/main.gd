extends Node
# 主流程只負責相機、設定與教學步驟；換算和場地各自分檔。
const Calib = preload("res://calib.gd")
const Arena = preload("res://arena.gd")
const Hud = preload("res://hud.gd")
var calib: RefCounted = Calib.new()
var arena: Node3D
var hud: Control
var view: SubViewport
var map_view: SubViewport
var camera: Camera3D
var top_camera: Camera3D
var markers: Array = []
var camera_cfg: Dictionary
var car_cfg: Dictionary
var points: Array = []
var warnings: Array[String] = []
var total_error: float = 0.0
var count: int = 0
var truth: Vector2
var demo: bool = false
var demo_time: float = 0.0
var demo_count: int = 0
# 用共同三個目標驗算，不用四個校正點本身。
const TARGETS: Array[Vector2] = [Vector2(50,45),Vector2(150,75),Vector2(100,115)]
const DEMO_HOLD: float = 4.0
var manual_average: float = -1.0
var auto_average: float = -1.0
var manual_errors: Array = []
var auto_errors: Array = []
var demo_stage: int = 0
var demo_steps: Array = []
var calibration_kind: String = "這次手點"
var changed: bool = false
var rng: RandomNumberGenerator = RandomNumberGenerator.new()

func read_config(path: String, defaults: Dictionary) -> Dictionary:
	if FileAccess.file_exists(path):
		var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(path).trim_prefix("\ufeff"))
		if raw is Dictionary and valid_config(path,raw):
			var result: Dictionary = defaults.duplicate(true)
			result.merge(raw,true)
			return result
	warnings.append(path.get_file()+" 讀取失敗，已使用預設值")
	return defaults

func valid_config(path: String, raw: Dictionary) -> bool:
	if path.ends_with("camera.json"):
		for key: String in ["height_cm","tilt_deg","fov_deg","image_width","image_height"]:
			if not (raw.get(key) is float or raw.get(key) is int):
				return false
		return raw.height_cm>0 and raw.tilt_deg>5 and raw.tilt_deg<=90 and raw.fov_deg>10 and raw.fov_deg<150 and raw.image_width>=320 and raw.image_width<=2048 and raw.image_height>=240 and raw.image_height<=2048 and valid_pair(raw.get("position_cm"))
	if path.ends_with("markers.json"):
		if not raw.get("markers") is Array or raw.markers.size()!=4:
			return false
		for m: Variant in raw.markers:
			if not m is Dictionary or not valid_pair(m.get("pos")) or not m.get("name") is String or not m.get("color") is String:
				return false
			if not Color.html_is_valid(m.color) or m.pos[0]<0 or m.pos[0]>200 or m.pos[1]<0 or m.pos[1]>150:
				return false
	if path.ends_with("car.json"):
		return raw.get("name") is String and raw.get("body_color") is String and raw.get("trail_color") is String and Color.html_is_valid(raw.body_color) and Color.html_is_valid(raw.trail_color) and (raw.get("speed_cm") is float or raw.get("speed_cm") is int) and raw.speed_cm>0
	return true

func valid_pair(raw: Variant) -> bool:
	return raw is Array and raw.size()==2 and (raw[0] is float or raw[0] is int) and (raw[1] is float or raw[1] is int)

func _ready() -> void:
	if "--self-test" in OS.get_cmdline_user_args():
		var result: String = calib.self_test()
		print(result)
		get_tree().quit(0 if result.begins_with("SELF_TEST PASS") else 1)
		return
	rng.seed = 206
	camera_cfg = read_config("res://camera.json",{"height_cm":160,"tilt_deg":50,"position_cm":[100,-60],"fov_deg":70,"image_width":960,"image_height":640})
	var marker_defaults: Dictionary = {"markers":[{"name":"紅","color":"#E53935","pos":[20,20]},{"name":"綠","color":"#43A047","pos":[180,20]},{"name":"藍","color":"#1E88E5","pos":[180,130]},{"name":"黃","color":"#FDD835","pos":[20,130]}]}
	markers = read_config("res://markers.json",marker_defaults).markers
	car_cfg = read_config("res://car.json",{"name":"小座標","body_color":"#FF7043","speed_cm":40,"trail_color":"#26C6DA"})
	view = SubViewport.new()
	view.size = Vector2i(camera_cfg.image_width,camera_cfg.image_height)
	view.own_world_3d = true
	view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(view)
	arena = Arena.new()
	view.add_child(arena)
	arena.build(markers,car_cfg)
	arena.arrived.connect(on_arrived)
	var light: DirectionalLight3D = DirectionalLight3D.new()
	arena.add_child(light)
	light.rotation_degrees = Vector3(-65,-25,0)
	light.light_energy = 1.1
	var world_env: WorldEnvironment = WorldEnvironment.new()
	var env: Environment = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("#23364b")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color.WHITE
	env.ambient_light_energy = 0.6
	world_env.environment = env
	arena.add_child(world_env)
	camera = Camera3D.new()
	view.add_child(camera)
	camera.current = true
	setup_camera()
	map_view = SubViewport.new()
	map_view.size = Vector2i(460,300)
	map_view.world_3d = view.find_world_3d()
	map_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(map_view)
	top_camera = Camera3D.new()
	map_view.add_child(top_camera)
	top_camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	top_camera.size = 1.65
	top_camera.position = Vector3(1,3,0.75)
	top_camera.rotation_degrees = Vector3(-90,0,0)
	top_camera.current = true
	hud = Hud.new()
	add_child(hud)
	hud.build(self,view,map_view)
	reset_calibration()
	hud.note.text = "；".join(warnings) if not warnings.is_empty() else "依序點紅 → 綠 → 藍 → 黃的十字中心。座標原點在地板左上角。"
	demo = "--demo" in OS.get_cmdline_user_args()
	if demo:
		start_challenge()
	if "--integration-test" in OS.get_cmdline_user_args():
		call_deferred("integration_test")
	if "--challenge-test" in OS.get_cmdline_user_args():
		call_deferred("challenge_test")
	if "--visual-test" in OS.get_cmdline_user_args():
		call_deferred("visual_test")

func setup_camera() -> void:
	camera.position = Vector3(camera_cfg.position_cm[0]/100.0,camera_cfg.height_cm/100.0,camera_cfg.position_cm[1]/100.0)
	camera.rotation_degrees = Vector3(-float(camera_cfg.tilt_deg),180,0)
	camera.fov = camera_cfg.fov_deg

func ground_points() -> Array:
	var result: Array = []
	for m: Dictionary in markers:
		result.append(Vector2(m.pos[0],m.pos[1]))
	return result

func reset_calibration() -> void:
	demo = false
	calibration_kind = "這次手點"
	manual_average = -1.0
	auto_average = -1.0
	manual_errors.clear()
	auto_errors.clear()
	hud.comparison.text = "共同三目標平均換算誤差（公分）\n這次手點：待校正　自動校正：待校正"
	arena.moving = false
	calib.h.clear()
	calib.inverse_h.clear()
	points.clear()
	hud.clicked.clear()
	hud.last_truth = Vector2(-1,-1)
	hud.matrix.text = "矩陣 H：等待四點校正\n\n像素 → 地面公分"
	total_error = 0.0
	count = 0
	hud.results.text = "尚無點擊紀錄"
	update_prompt()

func update_prompt() -> void:
	if points.size()<4:
		hud.status.text = "請點%s色標記（第 %d／4 點）" % [markers[points.size()].name,points.size()+1]

func finish_calibration() -> bool:
	if not calib.solve(points,ground_points()):
		hud.note.text = calib.message+"，請重新手點。"
		points.clear()
		hud.clicked.clear()
		update_prompt()
		return false
	hud.status.text = "校正完成！點地板，讓小車出發"
	hud.matrix.text = "矩陣 H　像素 → 公分（H33＝1）\n"
	for row: int in range(3):
		hud.matrix.text += "[ %.4f   %.4f   %.4f ]\n" % [calib.h[row*3],calib.h[row*3+1],calib.h[row*3+2]]
	update_comparison()
	return true

func auto_calibrate() -> void:
	var saved_manual: Array = manual_errors.duplicate()
	var saved_average: float = manual_average
	reset_calibration()
	manual_errors = saved_manual
	manual_average = saved_average
	calibration_kind = "自動校正"
	for g: Vector2 in ground_points():
		points.append(camera.unproject_position(Vector3(g.x/100.0,0,g.y/100.0)))
	if finish_calibration():
		hud.note.text = "自動校正用理想標記中心；手點越不準，換算誤差就越大。"

func change_angle() -> void:
	changed = not changed
	camera_cfg.tilt_deg = 43 if changed else 50
	setup_camera()
	reset_calibration()
	hud.note.text = "相機角度已改變，舊矩陣失效。請重新手點或按自動校正。"

func ray_truth(pixel: Vector2) -> Vector2:
	var origin: Vector3 = camera.project_ray_origin(pixel)
	var normal: Vector3 = camera.project_ray_normal(pixel)
	if absf(normal.y)<1e-8:
		return Vector2(INF,INF)
	var distance: float = -origin.y/normal.y
	if distance<0:
		return Vector2(INF,INF)
	var hit: Vector3 = origin+normal*distance
	return Vector2(hit.x,hit.z)*100.0

func inside(cm: Vector2) -> bool:
	return cm.is_finite() and cm.x>=0 and cm.x<=200 and cm.y>=0 and cm.y<=150

func click_pixel(pixel: Vector2) -> bool:
	if calib.h.is_empty():
		points.append(pixel)
		hud.clicked = points.duplicate()
		var index: int = points.size()-1
		var actual: Vector2 = marker_pixel(index)
		hud.note.text = "%s色：你點的位置（%.1f，%.1f）；標記真正的位置（%.1f，%.1f）；差 %.1f 像素" % [markers[index].name,pixel.x,pixel.y,actual.x,actual.y,pixel.distance_to(actual)]
		if points.size()==4:
			finish_calibration()
		else:
			update_prompt()
		return false
	var calculated: Vector2 = calib.to_ground(pixel)
	truth = ray_truth(pixel)
	if not inside(calculated) or not inside(truth):
		hud.note.text = "這裡超出 200 × 150 公分地板，請點地板範圍內。"
		return false
	if arena.moving:
		hud.note.text = "小車正在前往上一個目標，停下後再點一次。"
		return false
	var error_cm: float = calculated.distance_to(truth)
	total_error += error_cm
	count += 1
	hud.last_truth = truth
	hud.last_calc = calculated
	hud.results.text = "像素（%.0f，%.0f）→（%.1f，%.1f）公分\n換算誤差 %.1f 公分\n%d 次平均 %.1f 公分" % [pixel.x,pixel.y,calculated.x,calculated.y,error_cm,count,total_error/count]
	hud.note.text = "粉紅圈＝點擊真實目標　青色十字＝換算目標　黑點＝實際停點"
	arena.drive(calculated)
	return true

func on_arrived() -> void:
	var actual: Vector2 = Vector2(arena.car.position.x,arena.car.position.z)*100.0
	hud.note.text = "已停車｜距真實目標 %.1f 公分；距換算目標 %.1f 公分（理想模擬車）" % [actual.distance_to(truth),actual.distance_to(hud.last_calc)]

func _input(event: InputEvent) -> void:
	if not is_instance_valid(hud) or demo:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		var p: Vector2 = hud.get_local_mouse_position()
		if hud.camera_rect.has_point(p):
			click_pixel(hud.screen_to_pixel(p))

func marker_pixel(index: int) -> Vector2:
	var g: Vector2 = ground_points()[index]
	return camera.unproject_position(Vector3(g.x/100.0,0,g.y/100.0))

func target_errors(solver: RefCounted) -> Array:
	var errors: Array = []
	for g: Vector2 in TARGETS:
		var pixel: Vector2 = camera.unproject_position(Vector3(g.x/100.0,0,g.y/100.0))
		errors.append(solver.to_ground(pixel).distance_to(ray_truth(pixel)))
	return errors

func average(values: Array) -> float:
	var sum: float = 0.0
	for value: float in values:
		sum += value
	return sum/values.size()

func update_comparison() -> void:
	var ideal: RefCounted = Calib.new()
	var centers: Array = []
	for i: int in range(4):
		centers.append(marker_pixel(i))
	if not ideal.solve(centers,ground_points()):
		return
	auto_errors = target_errors(ideal)
	auto_average = average(auto_errors)
	if calibration_kind == "這次手點":
		manual_errors = target_errors(calib)
		manual_average = average(manual_errors)
	refresh_comparison()

func refresh_comparison() -> void:
	var manual_text: String = "待手點" if manual_average<0 else "%.1f" % manual_average
	hud.comparison.text = "共同三目標平均換算誤差（公分）\n這次手點　｜　自動校正\n　%s　　　｜　%.1f" % [manual_text,auto_average]
	if not manual_errors.is_empty():
		for i: int in range(3):
			hud.comparison.text += "\n目標%d　%.1f　｜　%.1f" % [i+1,manual_errors[i],auto_errors[i]]

func start_challenge() -> void:
	reset_calibration()
	# 每點向右偏 15 像素，距離恰為 15，非 x/y 各偏 15。
	for i: int in range(4):
		click_pixel(marker_pixel(i)+Vector2(15,0))
	if calib.h.is_empty():
		return
	demo = true
	demo_stage = 0
	demo_count = 0
	demo_time = 0.0
	demo_steps.clear()
	hud.status.text = "故意點偏：四點各向右偏 15 像素"
	hud.note.text = "先看點偏位置與比較表；接著跑三目標，再自動校正跑同樣三點。每段停留至少 4 秒。"

func _process(delta: float) -> void:
	if not demo or not is_instance_valid(arena):
		return
	# 停車後才開始算四秒，保留完整觀察時間。
	if arena.moving:
		demo_time = 0.0
		return
	demo_time += delta
	if demo_time<DEMO_HOLD:
		return
	demo_steps.append({"stage":demo_stage,"target":demo_count,"hold_seconds":demo_time})
	demo_time = 0.0
	if demo_count<3:
		var g: Vector2 = TARGETS[demo_count]
		if not click_pixel(camera.unproject_position(Vector3(g.x/100.0,0,g.y/100.0))):
			demo = false
			hud.note.text = "此相機／標記設定無法完成共同目標，請檢查設定。"
			return
		hud.status.text = "%s｜目標 %d／3（%.0f，%.0f 公分）" % ["故意點偏 15 像素" if demo_stage==0 else "自動校正",demo_count+1,g.x,g.y]
		demo_count += 1
	elif demo_stage==0:
		# 保留手點結果，相機與三個目標不變。
		var saved_manual: Array = manual_errors.duplicate()
		var saved_average: float = manual_average
		auto_calibrate()
		manual_errors = saved_manual
		manual_average = saved_average
		refresh_comparison()
		demo = true
		demo_stage = 1
		demo_count = 0
		hud.status.text = "改用自動校正｜重跑同樣三個目標"
	else:
		demo = false
		hud.status.text = "挑戰完成！比較右側兩輪誤差"
		hud.note.text = "各向右偏 15 像素：平均差 %.1f 公分；自動校正：%.1f 公分。可按「點偏示範」重播。" % [manual_average,auto_average]

func integration_test() -> void:
	await get_tree().process_frame
	auto_calibrate()
	var max_error: float = 0.0
	var max_stop_error: float = 0.0
	for i: int in range(10):
		var ground: Vector2 = Vector2(rng.randf_range(25,175),rng.randf_range(25,125))
		var pixel: Vector2 = camera.unproject_position(Vector3(ground.x/100,0,ground.y/100))
		if not Rect2(Vector2.ZERO,Vector2(view.size)).has_point(pixel) or not click_pixel(pixel):
			print("INTEGRATION FAIL 點擊未接受")
			get_tree().quit(1)
			return
		max_error = maxf(max_error,calib.to_ground(pixel).distance_to(ray_truth(pixel)))
		# 加速走車，但沿用實際逐步轉向、行駛、停車流程。
		for step: int in range(500):
			arena._process(0.1)
			if not arena.moving:
				break
		max_stop_error = maxf(max_stop_error,Vector2(arena.car.position.x,arena.car.position.z).distance_to(truth/100)*100)
		if arena.moving:
			print("INTEGRATION FAIL 小車未到達")
			get_tree().quit(1)
			return
	var summary: String = "INTEGRATION PASS 10 次點擊；平均誤差 %.8f 公分；最大換算誤差 %.8f；最大停車誤差 %.8f" % [total_error/count,max_error,max_stop_error]
	if max_error>=0.1 or max_stop_error>=0.1:
		summary = "INTEGRATION FAIL 誤差超過門檻"
	print(summary)
	var report: Dictionary = {"clicks":count,"average_error_cm":total_error/count,"max_error_cm":max_error,"max_stop_error_cm":max_stop_error,"summary":summary}
	var file: FileAccess = FileAccess.open("res://.test-data/實測.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"))
	# 改角度後校正，再測一次；也檢查界外拒絕。
	change_angle()
	auto_calibrate()
	var extra: Vector2 = camera.unproject_position(Vector3(1,0,0.75))
	assert(calib.to_ground(extra).distance_to(ray_truth(extra))<0.1)
	assert(not click_pixel(Vector2(-500,-500)))
	get_tree().quit(0 if summary.begins_with("INTEGRATION PASS") else 1)

func visual_test() -> void:
	await get_tree().process_frame
	start_challenge()
	demo = false
	hud.show_grid = true
	for i: int in range(90):
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("res://.test-data/畫面預覽.png")
	get_tree().quit()

func challenge_test() -> void:
	await get_tree().process_frame
	start_challenge()
	assert(hud.clicked.size()==4)
	for i: int in range(4):
		assert(absf(hud.clicked[i].distance_to(marker_pixel(i))-15.0)<0.001)
	var errors: Array = []
	var phase_errors: Array = []
	var last_stage: int = 0
	for step: int in range(3000):
		if arena.moving:
			arena._process(0.1)
			if not arena.moving:
				phase_errors.append((Vector2(arena.car.position.x,arena.car.position.z)*100.0).distance_to(truth))
		else:
			if demo_count<3:
				var before: int = demo_count
				_process(3.9)
				assert(demo_count==before)
				_process(0.11)
			else:
				_process(4.01)
		if demo_stage!=last_stage:
			errors.append(phase_errors.duplicate())
			phase_errors.clear()
			last_stage = demo_stage
		if not demo:
			break
	errors.append(phase_errors.duplicate())
	assert(not demo and demo_count==3)
	assert(errors.size()==2 and errors[0].size()==3 and errors[1].size()==3)
	assert(average(errors[0])>1.0 and average(errors[1])<0.1)
	assert(absf(average(errors[0])-manual_average)<0.01)
	for entry: Dictionary in demo_steps:
		assert(entry.hold_seconds>=4.0)
	arena._process(6.0)
	assert(arena.trails.get_child_count()==0)
	var report: Dictionary = {"manual_average_cm":manual_average,"auto_average_cm":auto_average,"actual_stop_errors_cm":errors,"targets_cm":[[50,45],[150,75],[100,115]],"offset_pixels":[15,0],"steps":demo_steps,"summary":"CHALLENGE PASS 偏移標示、兩輪同三點、平均誤差、四秒停留、軌跡淡出通過"}
	var file: FileAccess = FileAccess.open("res://.test-data/點偏挑戰實測.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"))
	print(report.summary,"；手點 %.1f 公分，自動 %.1f 公分" % [manual_average,auto_average])
	get_tree().quit()
