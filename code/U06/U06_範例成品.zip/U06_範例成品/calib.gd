extends RefCounted
# 自己組八條方程式，再用選主元高斯消去法求 H；不使用相機求換算答案。
var h: Array = []
var inverse_h: Array = []
var message: String = "尚未校正"

func solve(pixels: Array, ground: Array) -> bool:
	h.clear()
	inverse_h.clear()
	if pixels.size() != 4 or ground.size() != 4:
		message = "需要四組對應點"
		return false
	var rows: Array = []
	for i: int in range(4):
		var p: Vector2 = pixels[i]
		var ground_point: Vector2 = ground[i]
		rows.append([p.x,p.y,1.0,0.0,0.0,0.0,-ground_point.x*p.x,-ground_point.x*p.y,ground_point.x])
		rows.append([0.0,0.0,0.0,p.x,p.y,1.0,-ground_point.y*p.x,-ground_point.y*p.y,ground_point.y])
	for c: int in range(8):
		var pivot: int = c
		for r: int in range(c+1,8):
			if absf(rows[r][c]) > absf(rows[pivot][c]):
				pivot = r
		if absf(rows[pivot][c]) < 1e-10:
			message = "標記不可以排成一直線"
			return false
		var temp: Array = rows[c]
		rows[c] = rows[pivot]
		rows[pivot] = temp
		var divisor: float = rows[c][c]
		for j: int in range(c,9):
			rows[c][j] /= divisor
		for r: int in range(8):
			if r == c:
				continue
			var factor: float = rows[r][c]
			for j: int in range(c,9):
				rows[r][j] -= factor*rows[c][j]
	var candidate: Array = []
	for i: int in range(8):
		candidate.append(rows[i][8])
	candidate.append(1.0)
	# 用伴隨矩陣自己計算反矩陣，供格線投影使用。
	var a: float = candidate[0]; var b: float = candidate[1]; var c: float = candidate[2]
	var d: float = candidate[3]; var e: float = candidate[4]; var f: float = candidate[5]
	var g: float = candidate[6]; var k: float = candidate[7]
	var det: float = a*(e-f*k)-b*(d-f*g)+c*(d*k-e*g)
	if absf(det) < 1e-12:
		message = "標記不可以排成一直線"
		return false
	h = candidate
	inverse_h = [e-f*k,c*k-b,b*f-c*e,f*g-d,a-c*g,c*d-a*f,d*k-e*g,b*g-a*k,a*e-b*d]
	for i: int in range(9):
		inverse_h[i] /= det
	message = "校正完成"
	return true

func apply_matrix(m: Array, p: Vector2) -> Vector2:
	var w: float = m[6]*p.x + m[7]*p.y + m[8]
	if absf(w) < 1e-10:
		return Vector2(INF,INF)
	return Vector2((m[0]*p.x+m[1]*p.y+m[2])/w,(m[3]*p.x+m[4]*p.y+m[5])/w)

func to_ground(p: Vector2) -> Vector2:
	return apply_matrix(h,p)

func to_pixel(p: Vector2) -> Vector2:
	return apply_matrix(inverse_h,p)

func self_test() -> String:
	var known: Array = [0.5,0.125,4.0,-0.0625,0.75,8.0,0.00390625,0.0,1.0]
	var pixels: Array = [Vector2(0,0),Vector2(256,0),Vector2(256,256),Vector2(0,256)]
	var grounds: Array = []
	for p: Vector2 in pixels:
		grounds.append(apply_matrix(known,p))
	if not solve(pixels,grounds):
		return "SELF_TEST FAIL 求解失敗"
	var max_element: float = 0.0
	for i: int in range(9):
		max_element = maxf(max_element,absf(h[i]-known[i]))
	if max_element >= 1e-6:
		return "SELF_TEST FAIL 矩陣還原誤差"
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 206
	var max_error: float = 0.0
	for i: int in range(20):
		var p: Vector2 = Vector2(rng.randf_range(40,780),rng.randf_range(50,560))
		max_error = maxf(max_error,to_ground(p).distance_to(apply_matrix(known,p)))
		if to_pixel(to_ground(p)).distance_to(p) > 0.001:
			return "SELF_TEST FAIL 反投影"
	if max_error >= 0.1:
		return "SELF_TEST FAIL 換算超過 0.1 公分"
	var line: Array = [Vector2(0,0),Vector2(1,1),Vector2(2,2),Vector2(3,3)]
	if solve(line,line) or message != "標記不可以排成一直線":
		return "SELF_TEST FAIL 共線防護"
	return "SELF_TEST PASS 矩陣還原 < 1e-6；20 點誤差 < 0.1 公分；反投影與共線防護通過"
