"""使用本機 Chrome 與 Playwright，不下載任何元件。"""
import functools
import http.server
import json
import threading
from io import BytesIO
from PIL import Image, ImageChops
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
REPORT = ROOT / 'reports'
handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(ROOT / '網頁版'))
server = http.server.ThreadingHTTPServer(('127.0.0.1', 8061), handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
errors = []
results = {}
with sync_playwright() as p:
    browser = p.chromium.launch(channel='chrome', headless=True, args=['--mute-audio'])
    page = browser.new_page(viewport={'width': 1600, 'height': 900}, device_scale_factor=1)
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('console', lambda msg: errors.append(msg.text) if msg.type == 'error' else None)
    page.goto('http://127.0.0.1:8061/', wait_until='networkidle')
    page.wait_for_function('window.fleetSnapshot && window.fleetSnapshot.cars === 5', timeout=60000)
    def state():
        return page.evaluate('window.fleetSnapshot')
    def click(text):
        ui = state()['ui']
        item = next(b for b in ui['buttons'] if b['text'].startswith(text))
        page.mouse.click((item['x']+item['w']/2)*page.viewport_size['width']/ui['width'],
                         (item['y']+item['h']/2)*page.viewport_size['height']/ui['height'])
        page.wait_for_timeout(250)
    # 暫停狀態比較真實滑鼠操作前後畫面，確定瀏覽器有收到鏡頭輸入。
    page.wait_for_timeout(800)
    before = Image.open(BytesIO(page.screenshot())).convert('RGB')
    page.mouse.move(650,480)
    page.mouse.down(button='right')
    page.mouse.move(770,500,steps=12)
    page.mouse.up(button='right')
    page.wait_for_timeout(500)
    rotated = Image.open(BytesIO(page.screenshot())).convert('RGB')
    assert ImageChops.difference(before,rotated).getbbox(), '右鍵旋轉未改變畫面'
    page.mouse.wheel(0,-180)
    page.wait_for_timeout(500)
    zoomed = Image.open(BytesIO(page.screenshot())).convert('RGB')
    assert ImageChops.difference(rotated,zoomed).getbbox(), '滾輪縮放未改變畫面'
    page.screenshot(path=str(REPORT / '3d-web-camera.png'))
    results['right_drag_and_wheel'] = True
    page.reload(wait_until='networkidle')
    page.wait_for_function('window.fleetSnapshot && window.fleetSnapshot.cars === 5', timeout=60000)
    click('開始')
    page.wait_for_function('window.fleetSnapshot.ticks > 5')
    click('暫停')
    stopped = state()['ticks']
    page.wait_for_timeout(800)
    assert state()['ticks'] == stopped, '暫停後仍在前進'
    for expected in [2,4,1]:
        click('速度')
        assert state()['speed'] == expected
    for i in range(3): click('加一台')
    assert state()['cars'] == 8
    results['eight_cars'] = state()
    for i in range(3): click('減一台')
    assert state()['cars'] == 5
    click('協調模式')
    assert not state()['coordinated']
    click('開始')
    page.wait_for_function('window.fleetSnapshot.collisions > 0', timeout=60000)
    page.screenshot(path=str(REPORT / '3d-web-collision.png'))
    results['uncoordinated_collision_observed'] = state()
    click('協調模式')
    assert state()['coordinated']
    baseline = state()['collisions']
    tick = state()['ticks']
    page.wait_for_function('(window.fleetSnapshot.ticks - %d) >= 20' % tick, timeout=15000)
    assert state()['collisions'] == baseline, '恢復協調仍有新增碰撞'
    results['recovery'] = state()
    page.screenshot(path=str(REPORT / '網頁橫式.png'))
    page.set_viewport_size({'width': 900, 'height': 1600})
    page.wait_for_function('window.fleetSnapshot.portrait === true', timeout=10000)
    page.wait_for_timeout(1000)
    results['portrait'] = state()
    page.screenshot(path=str(REPORT / '網頁直式.png'))
    for name in ['eight_cars', 'portrait']:
        ui = results[name]['ui']
        for item in ui['buttons'] + ui['labels']:
            assert item['w'] > 0 and item['h'] > 0, (name, '元素沒有面積', item)
            assert item['x'] >= 0 and item['y'] >= 0 and item['x']+item['w'] <= ui['width']+1 and item['y']+item['h'] <= ui['height']+1, (name, '文字或按鈕超出畫面', item)
    click('重來')
    assert state()['completed'] == 0 and state()['collisions'] == 0
    assert not errors, errors
    results['console_errors'] = errors
    results['passed'] = True
    (REPORT / '網頁驗證.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    browser.close()
server.shutdown()
print('WEB_QA PASS：載入、開始暫停、三段速度、增減至八台、碰撞、恢復協調、重來、橫直式、無主控台錯誤')
