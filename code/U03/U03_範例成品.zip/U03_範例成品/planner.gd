extends RefCounted
# 自寫時間－空間 A*：節點 = (格子, 相對時間)，等待也能成為下一步。
# 頂點預約避免同格；反向邊預約避免迎面交換。關閉協調時退化為一般 A*。
const STEPS: Array[Vector2i] = [Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT, Vector2i.UP, Vector2i.ZERO]
const HORIZON: int = 64

# 二元堆積讓 A* 每次快速取出最小估計成本，避免大量等待狀態拖慢畫面。
func push_heap(heap: Array, item: Array) -> void:
	heap.append(item)
	var i: int = heap.size()-1
	while i > 0:
		var parent_index: int = floori(float(i-1)/2.0)
		if heap[parent_index][0] <= item[0]: break
		heap[i] = heap[parent_index]
		i = parent_index
	heap[i] = item

func pop_heap(heap: Array) -> Array:
	var result: Array = heap[0]
	var last: Array = heap.pop_back()
	if heap.is_empty(): return result
	var i: int = 0
	while i*2+1 < heap.size():
		var child: int = i*2+1
		if child+1 < heap.size() and heap[child+1][0] < heap[child][0]: child += 1
		if last[0] <= heap[child][0]: break
		heap[i] = heap[child]
		i = child
	heap[i] = last
	return result

func key(cell: Vector2i, time: int) -> Vector3i:
	return Vector3i(cell.x, cell.y, time)

func edge(a: Vector2i, b: Vector2i, time: int) -> String:
	return "%d,%d>%d,%d@%d" % [a.x,a.y,b.x,b.y,time]

func distance(a: Vector2i, b: Vector2i) -> int:
	return absi(a.x-b.x) + absi(a.y-b.y)

func find_path(start: Vector2i, goal: Vector2i, walkable: Dictionary, blocked: Dictionary, reserved: Dictionary, edges: Dictionary, coordinated: bool) -> Array:
	var first: Vector3i = key(start, 0)
	var opened: Array = [[distance(start,goal)*100+distance(start,goal),first]]
	var cost: Dictionary = {first: 0}
	var parent: Dictionary = {}
	var closed: Dictionary = {}
	var best: Vector3i = first
	var best_h: int = distance(start, goal)
	var expanded: int = 0
	while not opened.is_empty() and expanded < 1200:
		var entry: Array = pop_heap(opened)
		var current: Vector3i = entry[1]
		if closed.has(current): continue
		var cell: Vector2i = Vector2i(current.x,current.y)
		if cell == goal:
			best = current
			break
		closed[current] = true
		expanded += 1
		if current.z >= HORIZON:
			continue
		for direction in STEPS:
			if not coordinated and direction == Vector2i.ZERO:
				continue
			var next: Vector2i = cell + direction
			if not walkable.has(next) or blocked.has(next):
				continue
			var time: int = current.z + 1
			if coordinated and (reserved.has(key(next,time)) or edges.has(edge(next,cell,time))):
				continue
			var state: Vector3i = key(next,time if coordinated else 0)
			var new_cost: int = int(cost[current]) + 1
			if closed.has(state) or (cost.has(state) and int(cost[state]) <= new_cost):
				continue
			cost[state] = new_cost
			parent[state] = current
			push_heap(opened,[(new_cost+distance(next,goal))*100+distance(next,goal),state])
			var h: int = distance(next,goal)
			if h < best_h:
				best_h = h
				best = state
	var result: Array = []
	while best != first:
		result.push_front(Vector2i(best.x,best.y))
		best = parent[best]
	return result

func reserve(start: Vector2i, path: Array, vertices: Dictionary, edges: Dictionary) -> void:
	var previous: Vector2i = start
	# 目的地亦保留到時域末端，避免別台車衝進已停下的車。
	for time in range(1,HORIZON+1):
		var cell: Vector2i = path[time-1] if time <= path.size() else previous
		vertices[key(cell,time)] = true
		edges[edge(previous,cell,time)] = true
		previous = cell
