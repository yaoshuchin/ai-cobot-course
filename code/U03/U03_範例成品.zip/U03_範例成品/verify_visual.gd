extends SceneTree
# 使用真實車隊事件驗證畫面狀態；以 Dummy 音訊啟動，完全靜音。
var app: Node
var checks: Dictionary = {}

func _initialize() -> void:
	call_deferred("run")

func snapshot(filename: String) -> void:
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://reports/"+filename)

func run() -> void:
	app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.set_process(false)
	var world: Node3D = app.world
	assert(is_equal_approx(world.pitch,PI/4.0))
	var start_position: Vector3 = world.camera.position
	var drag: InputEventMouseMotion = InputEventMouseMotion.new()
	drag.button_mask = MOUSE_BUTTON_MASK_RIGHT
	drag.relative = Vector2(80,20)
	world._unhandled_input(drag)
	assert(world.camera.position.distance_to(start_position) > 1.0)
	var scroll: InputEventMouseButton = InputEventMouseButton.new()
	scroll.button_index = MOUSE_BUTTON_WHEEL_UP
	scroll.pressed = true
	var original_size: float = world.camera.size
	world._unhandled_input(scroll)
	assert(world.camera.size < original_size)
	world.yaw = 0.48
	world.pitch = PI/4.0
	world.zoom = 1.0
	world.update_camera()
	checks.camera_rotation_zoom = true
	var cargo_seen: bool = false
	var reroute_seen: bool = false
	for tick in range(600):
		app.sim.step()
		world.sync(app.sim)
		world.animate(app.sim,1.0)
		for i in range(app.sim.cars.size()):
			var car: Dictionary = app.sim.cars[i]
			var model: Dictionary = world.vehicles[i]
			assert(model.cargo.visible == (car.state == "送貨中"))
			if model.cargo.visible: cargo_seen = true
			if car.reroute > 0:
				assert(model.reroute.visible)
				if not reroute_seen:
					app.hud.refresh(app.sim)
					await snapshot("3d-reroute.png")
				reroute_seen = true
		if cargo_seen and reroute_seen: break
	assert(cargo_seen and reroute_seen)
	checks.cargo_and_reroute = true
	app.sim = app.fresh_fleet(false)
	var collision_seen: bool = false
	for tick in range(600):
		app.sim.step()
		if app.sim.collisions == 0: continue
		world.sync(app.sim)
		world.visual_time = 0.08
		world.animate(app.sim,1.0)
		for i in range(app.sim.cars.size()):
			if app.sim.cars[i].flash <= 0: continue
			assert(world.vehicles[i].alert.visible)
			assert(world.vehicles[i].body.material_override.emission_enabled)
		world.visual_time = 0.25
		world.animate(app.sim,1.0)
		for i in range(app.sim.cars.size()):
			if app.sim.cars[i].flash <= 0: continue
			assert(not world.vehicles[i].body.material_override.emission_enabled)
		world.visual_time = 0.08
		world.animate(app.sim,1.0)
		app.hud.refresh(app.sim)
		await snapshot("3d-collision.png")
		collision_seen = true
		break
	assert(collision_seen)
	checks.collision_blinks = true
	app.write_json("res://reports/3d-features.json",checks)
	print("VISUAL_QA PASS: 45 degree camera, right drag, zoom, cargo, reroute, collision blink")
	app.queue_free()
	quit()
