extends Node3D
# 入口負責設定、按鈕與時間。測試與遊戲使用相同 Fleet，沒有另造測試數字。
const Fleet = preload("res://fleet.gd")
const Warehouse = preload("res://warehouse.gd")
const Hud = preload("res://hud.gd")
const DEFAULT_MAP: String = "########################\n#C.C.C.C...............#\n#......................#\n#..BBBB..BBBB..BBBB....#\n#......................#\n#..BBBB..BBBB..BBBB....#\n#wwwwwwwwwwwwwwwwwwwwww#\n#..BBBB..BBBB..BBBB....#\n#......................#\n#..BBBB..BBBB..BBBB....#\n#......................#\n#......................#\n#...DD.......DD........#\n########################"
var settings: Dictionary = {}
var map_rows: Array = []
var warnings: Array = []
var sim: RefCounted
var world: Node3D
var hud: CanvasLayer
var running: bool = false
var speed: int = 1
var accumulator: float = 0.0
var demo: bool = false
var demo_time: float = 0.0
var demo_phase: int = 0
var qa_time: float = 0.0
var qa_stage: int = 0
var qa: bool = false
var is_portrait: bool = false

func load_json(path: String, defaults: Dictionary) -> Dictionary:
	var result: Dictionary = defaults.duplicate(true)
	if not FileAccess.file_exists(path):
		warnings.append(path.get_file()+" 讀不到，已用預設值")
		return result
	var parser: JSON = JSON.new()
	if parser.parse(FileAccess.get_file_as_string(path)) != OK or not parser.data is Dictionary:
		warnings.append(path.get_file()+" 格式有誤，已用預設值")
		return result
	for field in defaults:
		if parser.data.has(field):
			var value: Variant = parser.data[field]
			var expected: Variant = defaults[field]
			var valid: bool = typeof(value) == typeof(expected) or (typeof(value) in [TYPE_INT,TYPE_FLOAT] and typeof(expected) in [TYPE_INT,TYPE_FLOAT])
			if valid: result[field] = value
			else: warnings.append(path.get_file()+" 的 "+field+" 無效，已用預設值")
	return result

func load_settings() -> void:
	settings.fleet = load_json("res://fleet.json",{"count":5,"colors":["#2E86FF","#FF8C2E","#2ECC71","#B05CFF","#FF4D6D","#00B8D4"],"speed":3.0,"show_reserved_path":true})
	settings.orders = load_json("res://orders.json",{"interval":3.0,"max_waiting":6})
	settings.sim = load_json("res://sim.json",{"title":"倉儲搬運車調度中心","coordinated":true,"worker_cart":true,"seed":2026,"tick_seconds":0.33})
	settings.fleet.count = clampi(int(settings.fleet.count),1,8)
	settings.fleet.speed = clampf(float(settings.fleet.speed),0.1,20.0)
	settings.orders.interval = clampf(float(settings.orders.interval),0.33,120.0)
	settings.orders.max_waiting = clampi(int(settings.orders.max_waiting),1,100)
	settings.sim.tick_seconds = clampf(float(settings.sim.tick_seconds),0.05,2.0)
	var colors_valid: bool = not settings.fleet.colors.is_empty()
	for color in settings.fleet.colors:
		if not color is String or not Color.html_is_valid(str(color)): colors_valid = false
	if not colors_valid:
		settings.fleet.colors = ["#2E86FF","#FF8C2E","#2ECC71","#B05CFF","#FF4D6D","#00B8D4"]
		warnings.append("車隊顏色無效，已用預設值")
	var map_text: String = FileAccess.get_file_as_string("res://warehouse.txt") if FileAccess.file_exists("res://warehouse.txt") else ""
	var candidate: Array = Array(map_text.strip_edges().split("\n"))
	var valid: bool = candidate.size() >= 3 and candidate.size() <= 40
	var width: int = str(candidate[0]).length()
	var free: int = 0
	for i in range(candidate.size()):
		candidate[i] = str(candidate[i]).strip_edges()
		if candidate[i].length() != width or width > 60: valid = false
		for ch in candidate[i]:
			if ch not in ["#","B","C","D","w","."]: valid = false
			if ch not in ["#","B"]: free += 1
	if not map_text.contains("B") or not map_text.contains("D") or free < 8: valid = false
	# 貨架必須有可到達的相鄰取貨格，且所有走道必須連通。
	if valid:
		var cells: Dictionary = {}
		for y in range(candidate.size()):
			for x in range(width):
				if candidate[y][x] not in ["#","B"]: cells[Vector2i(x,y)] = true
		var seen: Dictionary = {}
		var opened: Array = [cells.keys()[0]]
		while not opened.is_empty():
			var p: Vector2i = opened.pop_back()
			if seen.has(p): continue
			seen[p] = true
			for d in [Vector2i.UP,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT]:
				if cells.has(p+d) and not seen.has(p+d): opened.append(p+d)
		if seen.size() != cells.size(): valid = false
		for y in range(candidate.size()):
			for x in range(width):
				if candidate[y][x] != "B": continue
				var adjacent: bool = false
				for d in [Vector2i.UP,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT]:
					if cells.has(Vector2i(x,y)+d): adjacent = true
				if not adjacent: valid = false
	if valid: map_rows = candidate
	else:
		map_rows = Array(DEFAULT_MAP.split("\n"))
		warnings.append("倉庫地圖讀不到或無法通行，已用範例地圖")

func fresh_fleet(enabled: bool) -> RefCounted:
	var model: RefCounted = Fleet.new()
	model.setup(map_rows,settings.duplicate(true))
	model.switch_mode(enabled)
	return model

func _ready() -> void:
	load_settings()
	var args: PackedStringArray = OS.get_cmdline_user_args()
	if "--self-test" in args:
		self_test()
		return
	if "--compare" in args:
		compare()
		return
	demo = "--demo" in args
	qa = "--qa" in args
	sim = fresh_fleet(bool(settings.sim.coordinated))
	world = Warehouse.new()
	add_child(world)
	world.build(sim)
	hud = Hud.new()
	add_child(hud)
	hud.build(self,"；".join(warnings))
	if demo:
		running = true
		speed = 2
		sim.switch_mode(true)
	if qa: running = true
	hud.refresh(sim)
	world.animate(sim,1)
	web_snapshot()

func _process(delta: float) -> void:
	if sim == null or world == null: return
	var portrait_now: bool = get_window().size.x < get_window().size.y
	if portrait_now != is_portrait:
		is_portrait = portrait_now
		get_window().content_scale_size = Vector2i(900,1600) if is_portrait else Vector2i(1600,900)
	if demo and running:
		demo_time += delta
		if demo_time >= 25 and demo_phase == 0:
			sim.switch_mode(false)
			demo_phase = 1
		if demo_time >= 40 and demo_phase == 1:
			sim.switch_mode(true)
			demo_phase = 2
	if running:
		# fleet.speed 與 tick_seconds 同時有效：前者控制車速，後者定義模擬時間。
		accumulator += delta*speed*float(settings.fleet.speed)*float(settings.sim.tick_seconds)
		var duration: float = float(settings.sim.tick_seconds)
		if accumulator >= duration:
			accumulator -= duration
			sim.step()
			world.sync(sim)
			hud.refresh(sim)
			web_snapshot()
	world.animate(sim,clampf(accumulator/float(settings.sim.tick_seconds),0,1) if running else 1.0)
	if qa:
		qa_time += delta
		if qa_time > 4 and qa_stage == 0:
			qa_stage = 1
			capture.call_deferred("res://reports/橫式畫面.png")
		if qa_time > 6 and qa_stage == 1:
			qa_stage = 2
			get_window().size = Vector2i(900,1600)
		if qa_time > 9 and qa_stage == 2:
			qa_stage = 3
			capture.call_deferred("res://reports/直式畫面.png")
		if qa_time > 11:
			print("QA_CAPTURE PASS")
			get_tree().quit()

func capture(path: String) -> void:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(path)

func toggle_running() -> void:
	demo = false
	running = not running
	hud.refresh(sim)
	web_snapshot()

func toggle_mode() -> void:
	demo = false
	sim.switch_mode(not sim.coordinated)
	world.sync(sim)
	hud.refresh(sim)
	web_snapshot()

func change_speed() -> void:
	speed = 2 if speed == 1 else (4 if speed == 2 else 1)
	hud.refresh(sim)
	web_snapshot()

func add_car() -> void:
	sim.add_car()
	world.sync(sim)
	hud.refresh(sim)
	web_snapshot()

func remove_car() -> void:
	sim.remove_car()
	world.sync(sim)
	hud.refresh(sim)
	web_snapshot()

func restart() -> void:
	demo = false
	sim = fresh_fleet(bool(settings.sim.coordinated))
	accumulator = 0
	world.sync(sim)
	hud.refresh(sim)
	web_snapshot()

func web_snapshot() -> void:
	# 提供本機網頁驗證使用的唯讀快照，不依賴額外外掛。
	if not OS.has_feature("web"): return
	var snapshot: Dictionary = sim.stats()
	snapshot.coordinated = sim.coordinated
	snapshot.running = running
	snapshot.speed = speed
	snapshot.cars = sim.cars.size()
	snapshot.portrait = is_portrait
	snapshot.ui = hud.bounds()
	JavaScriptBridge.eval("window.fleetSnapshot = "+JSON.stringify(snapshot),true)

func write_json(path: String, data: Variant) -> void:
	var file: FileAccess = FileAccess.open(path,FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(data,"\t"))

func self_test() -> void:
	var model: RefCounted = fresh_fleet(true)
	for i in range(600): model.step()
	var failures: Array = []
	if model.collisions != 0: failures.append("協調開仍有碰撞")
	if model.completed < 10: failures.append("完成訂單不足 10 張")
	if not model.violations.is_empty(): failures.append("路線穿牆或撞到推車")
	if bool(settings.sim.worker_cart) and model.replans < 1: failures.append("推車未觸發改道")
	# 小型反例：唯一出口被預約就必須等待；反向邊被占用不能交換。
	var p: RefCounted = model.planner
	var cells: Dictionary = {Vector2i(0,0):true,Vector2i(1,0):true}
	var route: Array = p.find_path(Vector2i(0,0),Vector2i(1,0),cells,{}, {p.key(Vector2i(1,0),1):true},{},true)
	if route.size() < 2 or route[0] != Vector2i.ZERO: failures.append("等待步驟失效")
	route = p.find_path(Vector2i(0,0),Vector2i(1,0),cells,{}, {},{p.edge(Vector2i(1,0),Vector2i(0,0),1):true},true)
	if route.size() < 2 or route[0] != Vector2i.ZERO: failures.append("迎面交換防護失效")
	# 模式復原：先跑無協調，再切回；復原後新增碰撞必須為零。
	var recovery: RefCounted = fresh_fleet(false)
	for i in range(182): recovery.step()
	recovery.switch_mode(true)
	var before: int = recovery.collisions
	for i in range(300): recovery.step()
	if recovery.collisions != before: failures.append("恢復協調後仍有新碰撞")
	model.add_car()
	model.remove_car()
	write_json("res://reports/self-test.json",{"stats":model.stats(),"failures":failures,"recovery_new_collisions":recovery.collisions-before,"planner_assertions":2})
	if failures.is_empty():
		print("SELF_TEST PASS 全部通過（完成 %d 張、碰撞 %d、重新規劃 %d 次）" % [model.completed,model.collisions,model.replans])
		get_tree().quit(0)
	else:
		print("SELF_TEST FAIL "+"；".join(failures))
		get_tree().quit(1)

func compare() -> void:
	var result: Dictionary = {}
	for enabled in [true,false]:
		var model: RefCounted = fresh_fleet(enabled)
		var count: int = floori(60.0/float(settings.sim.tick_seconds))
		for i in range(count): model.step()
		var values: Dictionary = model.stats()
		values.observation_seconds = 60
		result["協調開" if enabled else "協調關"] = values
		print("COMPARE "+("協調開 " if enabled else "協調關 ")+JSON.stringify(values))
	write_json("res://reports/60秒比較.json",result)
	get_tree().quit()
