extends CanvasLayer
# 投影用大字、觸控按鈕。窄螢幕時看板移到倉庫下方。
var root: Control
var heading: Label
var explanation: Label
var metrics: Label
var car_labels: Array = []
var panel: PanelContainer
var board: VBoxContainer
var toolbar: HFlowContainer
var mode_button: Button
var pause_button: Button
var speed_button: Button
var notice: Label
var legend: Label
var app: Node

func style(fill: Color, border: Color) -> StyleBoxFlat:
	var result: StyleBoxFlat = StyleBoxFlat.new()
	result.bg_color = fill
	result.border_color = border
	result.set_border_width_all(2)
	result.set_corner_radius_all(12)
	result.content_margin_left = 16
	result.content_margin_right = 16
	result.content_margin_top = 9
	result.content_margin_bottom = 9
	return result

func text_label(parent: Node, text: String, font_size: int = 27) -> Label:
	var item: Label = Label.new()
	item.text = text
	item.add_theme_font_size_override("font_size",font_size)
	parent.add_child(item)
	return item

func button(text: String, action: Callable) -> Button:
	var result: Button = Button.new()
	result.text = text
	result.custom_minimum_size = Vector2(140,58)
	result.pressed.connect(action)
	toolbar.add_child(result)
	return result

func build(controller: Node, warning: String) -> void:
	app = controller
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme: Theme = Theme.new()
	theme.default_font = preload("res://fonts/NotoSansTC-Common.ttf")
	theme.default_font_size = 26
	theme.set_color("font_color","Label",Color("e8f3fb"))
	theme.set_stylebox("normal","Button",style(Color("183246"),Color("30566c")))
	theme.set_stylebox("hover","Button",style(Color("28516a"),Color("67dcd0")))
	theme.set_stylebox("pressed","Button",style(Color("286558"),Color("7cf9c4")))
	theme.set_stylebox("focus","Button",style(Color(0,0,0,0),Color("fff19a")))
	theme.set_stylebox("panel","PanelContainer",style(Color("102636"),Color("29485c")))
	root.theme = theme
	add_child(root)
	heading = text_label(root,str(app.settings.sim.title)+"  ｜  曾小亮老師",34)
	heading.position = Vector2(26,12)
	toolbar = HFlowContainer.new()
	toolbar.add_theme_constant_override("h_separation",10)
	toolbar.add_theme_constant_override("v_separation",10)
	root.add_child(toolbar)
	pause_button = button("開始",app.toggle_running)
	mode_button = button("協調模式 開",app.toggle_mode)
	speed_button = button("速度 ×1",app.change_speed)
	button("加一台車",app.add_car)
	button("減一台車",app.remove_car)
	button("重來",app.restart)
	explanation = text_label(root,"",26)
	panel = PanelContainer.new()
	root.add_child(panel)
	board = VBoxContainer.new()
	board.add_theme_constant_override("separation",12)
	panel.add_child(board)
	text_label(board,"即時調度看板",32)
	metrics = text_label(board,"",29)
	text_label(board,"車隊任務",28)
	for i in range(8):
		car_labels.append(text_label(board,"",25))
	legend = text_label(root,"右鍵拖曳：旋轉｜滾輪：縮放\n同色方塊＝預計路線｜橘色貨架＝等待取貨",23)
	legend.add_theme_color_override("font_color",Color("adc8d9"))
	notice = text_label(root,warning if not warning.is_empty() else "教學觀察：同一格、同一時間，只能預約給一台車。",24)
	notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	notice.add_theme_color_override("font_color",Color("ffe6a1"))
	root.resized.connect(layout)
	layout()

func layout() -> void:
	var size: Vector2 = root.size
	var portrait: bool = size.x < size.y
	toolbar.position = Vector2(26,67)
	toolbar.size.x = size.x-52
	# 直接依按鈕寬度計算換行，避免 FlowContainer 尚未排版時說明壓到按鈕。
	var flow_rows: int = 1
	var used_width: float = 0
	for control in toolbar.get_children():
		var item_width: float = maxf(140,control.get_combined_minimum_size().x)
		if used_width > 0 and used_width+10+item_width > toolbar.size.x:
			flow_rows += 1
			used_width = 0
		used_width += item_width+10
	var top: float = toolbar.position.y+flow_rows*68+8
	explanation.position = Vector2(26,top)
	explanation.size = Vector2(size.x-52,70)
	explanation.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if portrait:
		panel.position = Vector2(22,size.y*0.53)
		panel.size = Vector2(size.x-44,size.y*0.42)
		app.world.set_layout(true)
	else:
		panel.position = Vector2(size.x-426,top+65)
		panel.size = Vector2(400,size.y-top-125)
		app.world.set_layout(false)
	legend.position = Vector2(26,size.y-135)
	legend.visible = not portrait
	notice.position = Vector2(26,size.y-57)
	notice.size = Vector2(size.x-52,55)

func refresh(sim: RefCounted) -> void:
	mode_button.text = "協調模式 " + ("開" if sim.coordinated else "關")
	pause_button.text = "暫停" if app.running else "開始"
	speed_button.text = "速度 ×%d" % app.speed
	var phase: String = "【自動示範】" if app.demo else ""
	explanation.text = phase + ("協調開啟｜先預約，再出發；遇到推車即時改道。" if sim.coordinated else "協調關閉｜各走各的，碰撞後會停 2 秒。")
	explanation.add_theme_color_override("font_color",Color("7bf0cc") if sim.coordinated else Color("ff998b"))
	var stats: Dictionary = sim.stats()
	metrics.text = "完成訂單    %d 張\n平均送達    %.1f 秒\n等待次數    %d 次\n重新規劃    %d 次\n碰撞次數    %d 次\n時間 %.1f 秒｜待單 %d" % [stats.completed,stats.average_seconds,stats.waits,stats.replans,stats.collisions,stats.seconds,sim.queue.size()]
	for i in range(car_labels.size()):
		car_labels[i].visible = i < sim.cars.size()
		if i >= sim.cars.size(): continue
		var car: Dictionary = sim.cars[i]
		car_labels[i].text = "%d 號  %s" % [car.id,car.state]
		if not car.job.is_empty(): car_labels[i].text += "  單 %03d" % int(car.job.number)
		car_labels[i].add_theme_color_override("font_color",Color(sim.config.fleet.colors[i%sim.config.fleet.colors.size()]).lightened(0.35))

func bounds() -> Dictionary:
	var result: Dictionary = {"width":root.size.x,"height":root.size.y,"buttons":[],"labels":[]}
	for control in toolbar.get_children():
		var rect: Rect2 = control.get_global_rect()
		result.buttons.append({"text":control.text,"x":rect.position.x,"y":rect.position.y,"w":rect.size.x,"h":rect.size.y})
	for control in [heading,explanation,metrics]+car_labels:
		if not control.visible: continue
		var rect: Rect2 = control.get_global_rect()
		result.labels.append({"text":control.text,"x":rect.position.x,"y":rect.position.y,"w":rect.size.x,"h":rect.size.y})
	return result
