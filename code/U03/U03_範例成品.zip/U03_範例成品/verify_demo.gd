extends SceneTree
# 測試示範的時間邊界與設定容錯；測試檔不修改使用者的設定與技能包。
func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var app: Node = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.demo = true
	app.running = true
	app.speed = 2
	app._process(24.9)
	assert(app.sim.coordinated and app.demo_phase == 0)
	app._process(0.2)
	assert(not app.sim.coordinated and app.demo_phase == 1)
	app._process(14.8)
	assert(not app.sim.coordinated)
	app._process(0.2)
	assert(app.sim.coordinated and app.demo_phase == 2)
	var result: Dictionary = app.load_json("res://不存在的設定檔.json",{"count":5}) # lint:ignore res_path
	assert(result.count == 5 and not app.warnings.is_empty())
	print("DEMO_CONFIG PASS：25 秒關閉、40 秒恢復、缺檔使用預設值")
	app.queue_free()
	quit()
