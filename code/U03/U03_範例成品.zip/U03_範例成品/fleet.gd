extends RefCounted
# 純模擬資料，畫面與自我測試共用同一個 step，數字不由畫面猜測。
const Planner = preload("res://planner.gd")
var planner: RefCounted = Planner.new()
var rows: Array = []
var walkable: Dictionary = {}
var shelves: Array = []
var docks: Array = []
var parking: Array = []
var worker_lane: Array = []
var cars: Array = []
var queue: Array = []
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var config: Dictionary
var coordinated: bool = true
var tick: int = 0
var completed: int = 0
var collisions: int = 0
var replans: int = 0
var waits: int = 0
var total_delivery: float = 0.0
var next_order: int = 1
var cart: Vector2i = Vector2i(-1,-1)
var cart_index: int = 10
var cart_direction: int = 1
var contacts: Dictionary = {}
var violations: Array = []
var last_reservations: Dictionary = {}

func setup(map_rows: Array, settings: Dictionary) -> void:
	rows = map_rows
	config = settings
	coordinated = bool(config.sim.coordinated)
	rng.seed = int(config.sim.seed)
	for y in range(rows.size()):
		for x in range(rows[y].length()):
			var p: Vector2i = Vector2i(x,y)
			var ch: String = rows[y][x]
			if ch not in ["#","B"]:
				walkable[p] = true
			if ch == "B": shelves.append(p)
			if ch == "D": docks.append(p)
			if ch == "C": parking.append(p)
			if ch == "w": worker_lane.append(p)
	if bool(config.sim.worker_cart) and not worker_lane.is_empty():
		cart_index = mini(cart_index,worker_lane.size()-1)
		cart = worker_lane[cart_index]
	for i in range(int(config.fleet.count)):
		add_car()

func add_car() -> void:
	if cars.size() >= 8: return
	var options: Array = parking.duplicate()
	options.append_array(walkable.keys())
	for p in options:
		var taken: bool = p == cart
		for car in cars:
			if car.cell == p: taken = true
			if planner.distance(car.cell,p) < 2: taken = true
		if not taken:
			cars.append({"id": cars.size()+1,"cell":p,"previous":p,"path":[],"state":"空閒","job":{},"goal":p,"freeze":0,"flash":0,"reroute":0})
			return

func remove_car() -> void:
	if cars.size() <= 1: return
	var car: Dictionary = cars.pop_back()
	if not car.job.is_empty():
		queue.push_front(car.job)

func switch_mode(enabled: bool) -> void:
	coordinated = enabled
	# 無協調時可能疊車；恢復協調先讓重疊車回到最近空格，保留其訂單。
	var occupied: Dictionary = {}
	for car in cars:
		if enabled and occupied.has(car.cell):
			var candidates: Array = walkable.keys()
			var origin: Vector2i = car.cell
			candidates.sort_custom(func(a: Vector2i,b: Vector2i) -> bool: return planner.distance(a,origin) < planner.distance(b,origin))
			for p in candidates:
				if not occupied.has(p) and p != cart:
					var overlaps: bool = false
					for other in cars:
						if other != car and other.cell == p: overlaps = true
					if not overlaps:
						car.cell = p
						car.previous = p
						break
		occupied[car.cell] = true
		car.freeze = 0
		car.path = []
	contacts.clear()

func step() -> void:
	tick += 1
	var seconds: float = float(config.sim.tick_seconds)
	var interval_ticks: int = maxi(1,roundi(float(config.orders.interval)/seconds))
	if (tick == 1 or tick % interval_ticks == 0) and queue.size() < int(config.orders.max_waiting):
		var shelf: Vector2i = shelves[rng.randi_range(0,shelves.size()-1)]
		var pickup: Vector2i = shelf + Vector2i.UP
		for direction in [Vector2i.UP,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT]:
			if walkable.has(shelf+direction):
				pickup = shelf+direction
				break
		queue.append({"number":next_order,"shelf":shelf,"pickup":pickup,"created":tick})
		next_order += 1
	# 最近的空車接單。以實際可走的路長比較，避免把隔牆距離當捷徑。
	for job in queue.duplicate():
		var nearest: Dictionary = {}
		var shortest: int = 99999
		for car in cars:
			if car.state != "空閒": continue
			var route: Array = planner.find_path(car.cell,job.pickup,walkable,{}, {},{},false)
			if (not route.is_empty() or car.cell == job.pickup) and route.size() < shortest:
				shortest = route.size()
				nearest = car
		if not nearest.is_empty():
			nearest.job = job
			nearest.goal = job.pickup
			nearest.state = "取貨中"
			queue.erase(job)
	var blocked: Dictionary = {}
	if cart != Vector2i(-1,-1):
		var next_index: int = cart_index
		if tick % 3 == 0:
			next_index += cart_direction
			if next_index < 0 or next_index >= worker_lane.size():
				cart_direction *= -1
				next_index = cart_index + cart_direction
			var occupied: bool = false
			for car in cars:
				if car.cell == worker_lane[next_index]: occupied = true
			if not occupied: cart_index = next_index
		cart = worker_lane[cart_index]
		blocked[cart] = true
	var vertices: Dictionary = {}
	var edges: Dictionary = {}
	# 每台車目前所在格先保留一個 tick，低順位車就算無路可走仍能安全等待。
	if coordinated:
		for car in cars: vertices[planner.key(car.cell,1)] = true
		for car in cars:
			if car.state == "空閒": planner.reserve(car.cell,[],vertices,edges)
	for offset in range(cars.size()):
		var car: Dictionary = cars[(tick+offset)%cars.size()]
		car.previous = car.cell
		car.flash = maxi(0,int(car.flash)-1)
		car.reroute = maxi(0,int(car.reroute)-1)
		if car.state == "空閒":
			car.path = []
			continue
		# 推車移入任何尚未走完的預定路線時，立即作廢並重新規劃。
		if car.path.has(cart):
			replans += 1
			car.reroute = 5
		if car.freeze > 0:
			car.freeze -= 1
			car.path = []
		else:
			if coordinated: vertices.erase(planner.key(car.cell,1))
			car.path = planner.find_path(car.cell,car.goal,walkable,blocked,vertices,edges,coordinated)
		if coordinated: planner.reserve(car.cell,car.path,vertices,edges)
	last_reservations = vertices
	# 同時提交所有車的下一步；每條可視路徑與實際提交使用同一份資料。
	for car in cars:
		if not car.path.is_empty():
			var next: Vector2i = car.path.pop_front()
			if not walkable.has(next) or planner.distance(car.cell,next) > 1:
				violations.append("路線穿牆或跳格")
			if blocked.has(next): violations.append("撞到人員推車")
			car.cell = next
		elif car.state != "空閒": waits += 1
		if car.cell == car.previous and car.state != "空閒":
			if not car.path.is_empty(): waits += 1
	var touching: Dictionary = {}
	for i in range(cars.size()):
		for j in range(i+1,cars.size()):
			var a: Dictionary = cars[i]
			var b: Dictionary = cars[j]
			if a.cell == b.cell or (a.cell == b.previous and b.cell == a.previous):
				var pair: String = "%d-%d" % [i,j]
				touching[pair] = true
				if not contacts.has(pair):
					collisions += 1
					a.freeze = ceili(2.0/seconds)
					b.freeze = ceili(2.0/seconds)
					a.flash = a.freeze
					b.flash = b.freeze
	contacts = touching
	for car in cars:
		for p in car.path:
			if not walkable.has(p): violations.append("預約路線穿牆")
		if car.cell != car.goal or car.freeze > 0: continue
		if car.state == "取貨中":
			car.state = "送貨中"
			var best_dock: Vector2i = docks[0]
			var best_length: int = 99999
			for dock in docks:
				var length: int = planner.distance(car.cell,dock)
				for other in cars:
					if other != car and (other.cell == dock or other.goal == dock): length += 15
				if length < best_length:
					best_length = length
					best_dock = dock
			car.goal = best_dock
			car.path = []
		elif car.state == "送貨中":
			completed += 1
			total_delivery += (tick-int(car.job.created))*seconds
			car.state = "空閒"
			car.job = {}
			car.path = []

func stats() -> Dictionary:
	return {"ticks":tick,"seconds":snappedf(tick*float(config.sim.tick_seconds),0.01),"completed":completed,"collisions":collisions,"replans":replans,"waits":waits,"average_seconds":snappedf(total_delivery/maxi(1,completed),0.01),"violations":violations.size()}
