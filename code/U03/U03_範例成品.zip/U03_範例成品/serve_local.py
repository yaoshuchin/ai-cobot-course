"""標準函式庫本機伺服器，只開放這台電腦，不下載任何元件。"""
import argparse
import functools
import http.server
import webbrowser
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--open', action='store_true')
parser.add_argument('--port', type=int, default=8060)
args = parser.parse_args()
root = Path(__file__).resolve().parent / '網頁版'

class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      '.wasm': 'application/wasm', '.pck': 'application/octet-stream'}
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

server = http.server.ThreadingHTTPServer(('127.0.0.1', args.port), functools.partial(Handler, directory=str(root)))
url = f'http://127.0.0.1:{args.port}/'
print('網頁版已開啟：' + url + '（關閉這個視窗即可停止）', flush=True)
if args.open:
    webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
