"""將本機既有 Godot 網頁外框的使用者提示改成繁體中文。"""
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
with ZipFile(ROOT.parent / 'Godot' / 'web_nothreads_release.zip') as archive:
    shell = archive.read('godot.html').decode('utf-8')
shell = shell.replace('<html lang="en">', '<html lang="zh-Hant">')
shell = shell.replace('Your browser does not support the canvas tag.', '您的瀏覽器無法顯示遊戲畫面，請改用新版瀏覽器。')
shell = shell.replace('An unknown error occurred.', '載入失敗，請關閉頁面後重新開啟。')
shell = shell.replace("setStatusNotice(err.message);", "setStatusNotice('載入失敗，請確認本機伺服器仍在執行，再重新整理頁面。');")
shell = shell.replace("setStatusNotice(err);", "setStatusNotice('載入失敗，請確認瀏覽器支援網頁 3D，再重新整理頁面。');")
shell = shell.replace('Error\\nThe following features required to run Godot projects on the Web are missing:\\n', '無法啟動\\n瀏覽器缺少必要功能，請改用新版瀏覽器。\\n')
shell = shell.replace("displayFailureNotice(missingMsg + missing.join('\\n'));", "displayFailureNotice(missingMsg);")
(ROOT / 'web_shell.html').write_text(shell, encoding='utf-8')
preset_path = ROOT / 'export_presets.cfg'
preset = preset_path.read_text(encoding='utf-8-sig')
preset = preset.replace('html/custom_html_shell=""', 'html/custom_html_shell="res://web_shell.html"')
preset_path.write_text(preset, encoding='utf-8')
launcher = ROOT / '開始玩.bat'
data = launcher.read_bytes()
if b'--audio-driver Dummy' not in data:
    launcher.write_bytes(data.replace(b'--path ', b'--audio-driver Dummy --path '))
