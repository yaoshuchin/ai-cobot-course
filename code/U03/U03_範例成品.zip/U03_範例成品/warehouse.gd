extends Node3D
# 全部模型由內建形狀組成，沒有網路素材。路線方塊的位置就是模擬格子。
const FONT = preload("res://fonts/NotoSansTC-Common.ttf")
var camera: Camera3D
var routes: Node3D
var vehicles: Array = []
var shelf_models: Dictionary = {}
var cart_model: Node3D
var colors: Array = []
var show_paths: bool = true
# 鏡頭與模型只讀取模擬資料，不改動調度座標。
var camera_target: Vector3
var yaw: float = 0.48
var pitch: float = PI / 4.0
var zoom: float = 1.0
var portrait_layout: bool = false
var scene_span: float = 24.0
var visual_time: float = 0.0

func glow(color: Color, strength: float = 1.0) -> StandardMaterial3D:
	var mat: StandardMaterial3D = material(color)
	mat.emission_enabled = true
	mat.emission = Color(color.r,color.g,color.b)
	mat.emission_energy_multiplier = strength
	return mat

func update_camera() -> void:
	camera.position = camera_target + Vector3(sin(yaw)*cos(pitch),sin(pitch),cos(yaw)*cos(pitch))*40.0
	camera.look_at(camera_target)
	camera.size = scene_span * (2.40 if portrait_layout else 1.10) * zoom
	camera.h_offset = 0.0 if portrait_layout else scene_span * 0.20
	camera.v_offset = -scene_span * 0.36 if portrait_layout else 0.2

func set_layout(portrait: bool) -> void:
	portrait_layout = portrait
	update_camera()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and event.button_mask & MOUSE_BUTTON_MASK_RIGHT:
		yaw -= event.relative.x * 0.006
		pitch = clampf(pitch + event.relative.y * 0.004,deg_to_rad(25),deg_to_rad(75))
		update_camera()
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP or event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom = clampf(zoom * (0.90 if event.button_index == MOUSE_BUTTON_WHEEL_UP else 1.10),0.55,1.7)
			update_camera()
			get_viewport().set_input_as_handled()

func carton(parent: Node3D, at: Vector3, dimensions: Vector3) -> Node3D:
	var pack: Node3D = Node3D.new()
	parent.add_child(pack)
	pack.position = at
	box(pack,Vector3.ZERO,dimensions,Color("bd8c56"))
	box(pack,Vector3(0,dimensions.y/2+0.004,0),Vector3(dimensions.x*0.18,0.012,dimensions.z+0.008),Color("ecd2a2"))
	box(pack,Vector3(0,0,-dimensions.z/2-0.006),Vector3(dimensions.x*0.18,dimensions.y,0.012),Color("ddbd88"))
	box(pack,Vector3(dimensions.x*0.25,0,-dimensions.z/2-0.014),Vector3(dimensions.x*0.23,dimensions.y*0.32,0.012),Color("eee4cc"))
	return pack

func wheel(parent: Node3D, at: Vector3) -> MeshInstance3D:
	var model: MeshInstance3D = MeshInstance3D.new()
	var tire: CylinderMesh = CylinderMesh.new()
	tire.top_radius = 0.14
	tire.bottom_radius = 0.14
	tire.height = 0.11
	tire.radial_segments = 12
	model.mesh = tire
	model.material_override = material(Color("14202b"))
	model.rotation.z = PI/2
	model.position = at
	parent.add_child(model)
	return model

func material(color: Color) -> StandardMaterial3D:
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.75
	if color.a < 1.0:
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return mat

func box(parent: Node3D, at: Vector3, dimensions: Vector3, color: Color) -> MeshInstance3D:
	var model: MeshInstance3D = MeshInstance3D.new()
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = dimensions
	model.mesh = mesh
	model.material_override = material(color)
	model.position = at
	parent.add_child(model)
	return model

func label(parent: Node3D, text: String, at: Vector3, tint: Color = Color.WHITE) -> Label3D:
	var caption: Label3D = Label3D.new()
	caption.font = FONT
	caption.text = text
	caption.font_size = 64
	caption.pixel_size = 0.011
	caption.outline_size = 12
	caption.modulate = tint
	caption.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	caption.no_depth_test = true
	caption.position = at
	parent.add_child(caption)
	return caption

func build(sim: RefCounted) -> void:
	colors = sim.config.fleet.colors
	show_paths = bool(sim.config.fleet.show_reserved_path)
	var environment: WorldEnvironment = WorldEnvironment.new()
	var sky: Environment = Environment.new()
	sky.background_mode = Environment.BG_COLOR
	sky.background_color = Color("101e2b")
	sky.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	sky.ambient_light_color = Color.WHITE
	sky.ambient_light_energy = 0.45
	environment.environment = sky
	add_child(environment)
	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-65,-20,0)
	sun.light_energy = 0.95
	sun.shadow_enabled = true
	add_child(sun)
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 23
	add_child(camera)
	var width: float = sim.rows[0].length()
	var height: float = sim.rows.size()
	camera_target = Vector3((width-1)/2.0,0,(height-1)/2.0)
	scene_span = maxf(width,height*1.25)
	update_camera()
	box(self,Vector3((width-1)/2,-0.30,(height-1)/2),Vector3(width+0.4,0.35,height+0.4),Color("273b4b"))
	camera.current = true
	for y in range(sim.rows.size()):
		for x in range(sim.rows[y].length()):
			var cell: Vector2i = Vector2i(x,y)
			var ch: String = sim.rows[y][x]
			var tint: Color = Color("adbfc6") if (x+y)%2 == 0 else Color("a8bac1")
			if ch == "C": tint = Color("637382")
			if ch == "D": tint = Color("2cba8c")
			if ch == "w": tint = Color("d8cb98")
			box(self,Vector3(x,-0.1,y),Vector3(0.97,0.16,0.97),tint)
			if ch == "#":
				box(self,Vector3(x,0.15,y),Vector3(0.98,0.35,0.98),Color("314859"))
			if ch == "B":
				# 四支鋼柱與三層橫梁，留空讓人看見貨架深度。
				var rack: Node3D = Node3D.new()
				add_child(rack)
				rack.position = Vector3(x,0,y)
				for sx in [-0.39,0.39]:
					for sz in [-0.34,0.34]:
						box(rack,Vector3(sx,1.0,sz),Vector3(0.065,2.0,0.065),Color("214e70"))
				for level in [0.20,0.95,1.70]:
					box(rack,Vector3(0,level,0),Vector3(0.88,0.065,0.78),Color("536779"))
					for sz in [-0.37,0.37]:
						box(rack,Vector3(0,level,sz),Vector3(0.88,0.10,0.045),Color("e79a45"))
					carton(rack,Vector3(-0.20,level+0.22,0),Vector3(0.31,0.36,0.49))
					if (x+y)%3 != 0:
						carton(rack,Vector3(0.20,level+0.19,0.02),Vector3(0.29,0.30,0.41))
				shelf_models[cell] = box(rack,Vector3(0,2.09,0),Vector3(0.72,0.10,0.55),Color("214e70"))
	label(self,"停車／充電",Vector3(15,0.5,0.1),Color("dae7f4"))
	label(self,"出貨口",Vector3(9,0.55,height-1.5),Color("bcffe2"))
	routes = Node3D.new()
	add_child(routes)
	cart_model = Node3D.new()
	add_child(cart_model)
	box(cart_model,Vector3(0,0.4,0),Vector3(0.72,0.8,0.75),Color("ffce38"))
	box(cart_model,Vector3(0,0.95,0.25),Vector3(0.65,0.3,0.09),Color("fff2a0"))
	label(cart_model,"人員推車",Vector3(0,1.45,0),Color("ffe783"))
	cart_model.visible = sim.cart != Vector2i(-1,-1)
	sync(sim)

func sync(sim: RefCounted) -> void:
	while vehicles.size() > sim.cars.size():
		var old: Dictionary = vehicles.pop_back()
		old.root.queue_free()
	while vehicles.size() < sim.cars.size():
		var index: int = vehicles.size()
		var color: Color = Color(colors[index%colors.size()])
		var root: Node3D = Node3D.new()
		add_child(root)
		var chassis: Node3D = Node3D.new()
		root.add_child(chassis)
		box(chassis,Vector3(0,0.19,0),Vector3(0.76,0.16,0.88),Color("26394a"))
		var body: MeshInstance3D = box(chassis,Vector3(0,0.37,0.02),Vector3(0.67,0.27,0.74),color)
		box(chassis,Vector3(0,0.52,-0.22),Vector3(0.52,0.12,0.24),color.darkened(0.25))
		box(chassis,Vector3(0,0.59,-0.22),Vector3(0.37,0.025,0.15),Color("19354a"))
		for sx in [-0.39,0.39]:
			for sz in [-0.28,0.28]: wheel(chassis,Vector3(sx,0.15,sz))
		for sx in [-0.22,0.22]:
			var lamp: MeshInstance3D = box(chassis,Vector3(sx,0.36,-0.40),Vector3(0.14,0.09,0.04),Color("e0fbff"))
			lamp.material_override = glow(Color("c9f6ff"),2.0)
		box(chassis,Vector3(0,0.25,-0.46),Vector3(0.62,0.08,0.06),Color("172433"))
		var cargo: Node3D = carton(chassis,Vector3(0,0.75,0.10),Vector3(0.46,0.42,0.43))
		var caption: Label3D = label(root,"",Vector3(0,1.35,0),color.lightened(0.5))
		caption.font_size = 48
		caption.pixel_size = 0.009
		var alert: Label3D = label(root,"碰撞！",Vector3(0,2.15,0),Color("ff6d70"))
		alert.visible = false
		var reroute: Label3D = label(chassis,"🔄",Vector3(0,1.12,-0.49),Color("a4fff1"))
		reroute.visible = false
		vehicles.append({"root":root,"chassis":chassis,"body":body,"cargo":cargo,"label":caption,"alert":alert,"reroute":reroute,"color":color,"normal_mat":body.material_override,"flash_mat":glow(Color("ff1835"),2.2)})
	for child in routes.get_children():
		routes.remove_child(child)
		child.queue_free()
	for rack in shelf_models.values():
		rack.material_override = material(Color("214e70"))
	for job in sim.queue:
		shelf_models[job.shelf].material_override = glow(Color("f8a635"),1.1)
	for i in range(sim.cars.size()):
		var car: Dictionary = sim.cars[i]
		var visual: Dictionary = vehicles[i]
		visual.cargo.visible = car.state == "送貨中"
		visual.label.text = "%d 號" % car.id
		if not car.job.is_empty():
			visual.label.text += "\n單 %03d" % int(car.job.number)
			if car.state == "取貨中": shelf_models[car.job.shelf].material_override = glow(Color("f8a635"),1.1)
		visual.reroute.visible = car.reroute > 0
		visual.alert.visible = car.freeze > 0
		if not show_paths: continue
		var route_color: Color = visual.color
		route_color.a = 0.45
		for k in range(car.path.size()):
			var p: Vector2i = car.path[k]
			var tile: MeshInstance3D = box(routes,Vector3(p.x,0.035+i*0.008,p.y),Vector3(0.47,0.016,0.47),route_color)
			tile.material_override = glow(route_color,1.25)
			tile.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			var halo_color: Color = Color(route_color,0.10)
			var halo: MeshInstance3D = box(routes,Vector3(p.x,0.024+i*0.008,p.y),Vector3(0.66,0.008,0.66),halo_color)
			halo.material_override = glow(halo_color,0.7)
			halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			if k < 3:
				var marker: Label3D = label(routes,str(k+2),Vector3(p.x,0.12,p.y),visual.color.lightened(0.2))
				marker.font_size = 32

func animate(sim: RefCounted, fraction: float) -> void:
	visual_time += get_process_delta_time()
	for i in range(mini(vehicles.size(),sim.cars.size())):
		var car: Dictionary = sim.cars[i]
		var p: Vector2 = Vector2(car.previous).lerp(Vector2(car.cell),fraction)
		var visual: Dictionary = vehicles[i]
		visual.root.position = Vector3(p.x,0,p.y)
		var direction: Vector2 = Vector2(car.cell-car.previous)
		if direction.length_squared() > 0.0:
			visual.chassis.rotation.y = atan2(-direction.x,-direction.y)
		var flashing: bool = car.flash > 0 and sin(visual_time*18.0) > 0.0
		visual.body.material_override = visual.flash_mat if flashing else visual.normal_mat
		visual.alert.position.y = 1.85 + absf(sin(visual_time*5.0))*0.25
		visual.reroute.position.y = 1.15 + sin(visual_time*5.0)*0.08
	cart_model.position = Vector3(sim.cart.x,0,sim.cart.y)
