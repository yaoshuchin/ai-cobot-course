"""驗證雙擊開啟網頁版所使用的本機伺服器。"""
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parent
process = subprocess.Popen(
    [sys.executable, str(root / 'serve_local.py')],
    cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    creationflags=subprocess.CREATE_NO_WINDOW)
try:
    for i in range(40):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8060/', timeout=1) as response:
                body = response.read()
                assert response.status == 200 and b'<canvas' in body
            with urllib.request.urlopen('http://127.0.0.1:8060/index.wasm', timeout=2) as response:
                assert response.headers['Content-Type'] == 'application/wasm'
            (root / 'reports' / '啟動伺服器.json').write_text(json.dumps({'passed': True, 'url': 'http://127.0.0.1:8060/', 'script': 'serve_local.py'}, ensure_ascii=False, indent=2), encoding='utf-8')
            print('LAUNCHER_SERVER PASS：雙擊啟動用的本機伺服器可提供首頁與網頁執行檔')
            break
        except (OSError, TimeoutError):
            if process.poll() is not None:
                raise RuntimeError(process.stdout.read().decode('utf-8', errors='replace'))
            time.sleep(0.25)
    else:
        raise RuntimeError('本機伺服器未能啟動')
finally:
    process.terminate()
    process.wait(timeout=5)
