extends Node3D
# 文字地圖轉成內建形狀：每格兩公尺，牆、水坑與加速板都依地圖建立。
const Pieces = preload("res://robot.gd")
var maker = Pieces.new()
var rows: Array[String] = []
var cubes: Array[Node3D] = []
var puddles: Array[MeshInstance3D] = []
var start := Vector3.ZERO
var width := 0
var height := 0
var cube_total := 0
var starts := 0
var flash_size := 0.4

func cell_pos(x: int, z: int) -> Vector3:
	return Vector3((x - width / 2.0) * 2, 0, (z - height / 2.0) * 2)

func setup(lines: Array[String], cfg: Dictionary) -> void:
	rows = lines
	flash_size = cfg.collect_flash_size
	height = rows.size()
	width = rows[0].length()
	for z in height:
		for x in width:
			var pos := cell_pos(x, z)
			var tile := rows[z][x]
			var floor_col := Color(cfg.floor_color_a if (x + z) % 2 == 0 else cfg.floor_color_b)
			maker.box(self, pos + Vector3(0, -0.12, 0), Vector3(1.97, 0.23, 1.97), floor_col)
			match tile:
				"#":
					var wall := StaticBody3D.new()
					add_child(wall)
					wall.position = pos
					var wall_height := 0.38 if x == 0 or x == width - 1 or z == 0 or z == height - 1 else 0.8
					maker.box(wall, Vector3(0, wall_height / 2, 0), Vector3(1.94, wall_height, 1.94), Color(cfg.wall_color))
					maker.box(wall, Vector3(0, wall_height + 0.02, 0), Vector3(1.98, 0.12, 1.98), Color(cfg.wall_color).lightened(0.3))
					var collision := CollisionShape3D.new()
					var b := BoxShape3D.new()
					b.size = Vector3(2, 1.5, 2)
					collision.shape = b
					collision.position.y = 0.75
					wall.add_child(collision)
				"R":
					start = pos
					starts += 1
				"*":
					var cube := Node3D.new()
					add_child(cube)
					cube.position = pos + Vector3(0, 0.9, 0)
					var core := maker.box(cube, Vector3.ZERO, Vector3.ONE * 0.62, Color(cfg.cube_color), true)
					core.material_override.emission_energy_multiplier = cfg.cube_emission
					# 相容模式用透明亮殼呈現光暈。
					var halo := maker.box(cube, Vector3.ZERO, Vector3.ONE * 0.83, Color(Color(cfg.cube_color), 0.16), true)
					halo.material_override.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
					halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
					var rim := maker.box(cube, Vector3.ZERO, Vector3(0.75, 0.08, 0.75), Color("ffffff"), true)
					rim.rotation.z = PI / 4
					cubes.append(cube)
					cube_total += 1
				"~":
					var water := maker.box(self, pos + Vector3(0, 0.02, 0), Vector3(1.92, 0.02, 1.92), Color(0.12, 0.65, 0.95, 0.55))
					water.material_override.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
					puddles.append(water)
				"^":
					maker.box(self, pos + Vector3(0, 0.02, 0), Vector3(1.8, 0.025, 1.8), Color("23465b"))
					for side in [-1, 1]:
						var arrow := maker.box(self, pos + Vector3(side * 0.22, 0.05, 0), Vector3(0.13, 0.035, 0.85), Color("ffe16b"), true)
						arrow.rotation.y = side * -PI / 4

func terrain(pos: Vector3) -> String:
	var x := roundi(pos.x / 2 + width / 2.0)
	var z := roundi(pos.z / 2 + height / 2.0)
	if z < 0 or z >= height or x < 0 or x >= width: return "#"
	return rows[z][x]

# 收集瞬間白色閃光膨脹消失，再散開一圈金色亮點。
func collect(cube: Node3D) -> void:
	cubes.erase(cube)
	var flash := maker.ball(self, cube.position, flash_size, Color.WHITE, true)
	flash.material_override.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	flash.material_override.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var burst := create_tween().set_parallel(true)
	burst.tween_property(flash, "scale", Vector3.ONE * 3, 0.24)
	burst.tween_property(flash, "material_override:albedo_color:a", 0.0, 0.24)
	burst.chain().tween_callback(flash.queue_free)
	var t := create_tween()
	t.tween_property(cube, "scale", Vector3.ZERO, 0.22)
	t.tween_callback(cube.queue_free)
	for i in 12:
		var spark := maker.ball(self, cube.position, 0.15, Color("fff1a6"), true)
		var tw := create_tween().set_parallel(true)
		tw.tween_property(spark, "position", cube.position + Vector3(cos(i * TAU / 12) * 1.4, 0.8, sin(i * TAU / 12) * 1.4), 0.4)
		tw.tween_property(spark, "scale", Vector3.ZERO, 0.4)
		tw.chain().tween_callback(spark.queue_free)

func _process(_delta: float) -> void:
	var time := Time.get_ticks_msec() / 1000.0
	for cube in cubes:
		cube.rotation.y = time * 1.4
		cube.position.y = 0.95 + sin(time * 2.5 + cube.position.x) * 0.16
	for water in puddles:
		water.material_override.albedo_color.a = 0.5 + sin(time * 2 + water.position.x) * 0.12

func _exit_tree() -> void:
	maker.free()
