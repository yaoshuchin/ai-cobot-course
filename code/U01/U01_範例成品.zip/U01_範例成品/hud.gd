extends CanvasLayer
# 大字介面與可同時觸控的搖桿，隨視窗大小重新排版。
signal restart
signal horn
signal camera_toggle
class Stick extends Control:
	var value := Vector2.ZERO
	var finger := -1
	var mouse_down := false
	func _draw() -> void:
		var center := size / 2
		draw_circle(center, 100, Color(0.04, 0.12, 0.22, 0.65))
		draw_arc(center, 100, 0, TAU, 64, Color("83cfff"), 4, true)
		draw_line(center + Vector2(-70, 0), center + Vector2(70, 0), Color(1, 1, 1, 0.18), 2)
		draw_line(center + Vector2(0, -70), center + Vector2(0, 70), Color(1, 1, 1, 0.18), 2)
		draw_circle(center + value * 65, 37, Color("ffd166"))
	func update_value(pos: Vector2) -> void:
		value = ((pos - global_position - size / 2) / 65).limit_length()
		queue_redraw()
	func _input(event: InputEvent) -> void:
		if event is InputEventScreenTouch:
			if event.pressed and finger == -1 and get_global_rect().has_point(event.position):
				finger = event.index
				update_value(event.position)
			elif not event.pressed and event.index == finger:
				finger = -1
				value = Vector2.ZERO
				queue_redraw()
		elif event is InputEventScreenDrag and event.index == finger:
			update_value(event.position)
		elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed and get_global_rect().has_point(event.position):
				mouse_down = true
				update_value(event.position)
			elif not event.pressed and mouse_down:
				mouse_down = false
				value = Vector2.ZERO
				queue_redraw()
		elif event is InputEventMouseMotion and mouse_down:
			update_value(event.position)

var root: Control
var title_label: Label
var status: Label
var help: Label
var warnings_label: Label
var stick: Stick
var horn_button: Button
var reset_button: Button
var camera_button: Button
var result: PanelContainer
var result_label: Label
var again: Button

func panel_style() -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = Color(0.035, 0.09, 0.17, 0.9)
	s.border_color = Color("4b799d")
	s.set_border_width_all(2)
	s.set_corner_radius_all(22)
	s.content_margin_left = 24
	s.content_margin_right = 24
	s.content_margin_top = 16
	s.content_margin_bottom = 16
	return s

func label_at(font_size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color("173750"))
	l.add_theme_color_override("font_shadow_color", Color("10253d"))
	l.add_theme_constant_override("shadow_offset_x", 0)
	l.add_theme_constant_override("shadow_offset_y", 0)
	return l

func button(text_value: String, callback: Callable) -> Button:
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.text = text_value
	b.add_theme_font_size_override("font_size", 34)
	b.add_theme_stylebox_override("normal", panel_style())
	b.add_theme_stylebox_override("hover", panel_style())
	b.add_theme_stylebox_override("pressed", panel_style())
	b.pressed.connect(callback)
	root.add_child(b)
	return b

func setup(title: String, warnings: Array[String]) -> void:
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	var theme := Theme.new()
	theme.default_font = load("res://fonts/NotoSansTC-Common.ttf")
	theme.default_font_size = 34
	root.theme = theme
	title_label = label_at(44)
	title_label.text = title
	root.add_child(title_label)
	status = label_at(36)
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	root.add_child(status)
	help = label_at(27)
	help.text = "方向鍵／WASD 駕駛　空白鍵 喇叭\n收集所有能量！水坑減速・箭頭加速"
	root.add_child(help)
	warnings_label = label_at(24)
	warnings_label.text = "\n".join(warnings)
	warnings_label.add_theme_color_override("font_color", Color("ffdb8c"))
	root.add_child(warnings_label)
	stick = Stick.new()
	stick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(stick)
	horn_button = button("喇叭", func(): horn.emit())
	reset_button = button("重來", func(): restart.emit())
	camera_button = button("切換鏡頭〔Tab〕", func(): camera_toggle.emit())
	result = PanelContainer.new()
	result.add_theme_stylebox_override("panel", panel_style())
	root.add_child(result)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 24)
	result.add_child(column)
	result_label = label_at(44)
	result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	result_label.add_theme_color_override("font_color", Color("f1f8ff"))
	column.add_child(result_label)
	again = Button.new()
	again.focus_mode = Control.FOCUS_NONE
	again.text = "再玩一次〔R〕"
	again.custom_minimum_size.y = 90
	again.pressed.connect(func(): restart.emit())
	column.add_child(again)
	result.hide()
	get_viewport().size_changed.connect(layout)
	layout()

func layout() -> void:
	var s := get_viewport().get_visible_rect().size
	title_label.position = Vector2(36, 24)
	status.position = Vector2(s.x - 660, 28)
	status.size = Vector2(620, 200)
	help.position = Vector2(36, 95)
	stick.position = Vector2(28, s.y - 260)
	stick.size = Vector2(220, 220)
	horn_button.position = Vector2(s.x - 230, s.y - 250)
	horn_button.size = Vector2(190, 95)
	reset_button.position = Vector2(s.x - 230, s.y - 140)
	reset_button.size = Vector2(190, 95)
	camera_button.position = Vector2(36, 195)
	camera_button.size = Vector2(330, 65)
	warnings_label.position = Vector2(280, s.y - 145)
	warnings_label.size.x = maxf(250, s.x - 560)
	warnings_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if s.x < 1000:
		title_label.add_theme_font_size_override("font_size", 40)
		status.add_theme_font_size_override("font_size", 32)
		status.position = Vector2(28, 100)
		status.size = Vector2(s.x - 56, 115)
		status.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		help.add_theme_font_size_override("font_size", 24)
		help.position = Vector2(28, 210)
		camera_button.position = Vector2(28, 295)
		warnings_label.position = Vector2(28, s.y - 370)
		warnings_label.size.x = s.x - 56
		result_label.add_theme_font_size_override("font_size", 34)
	else:
		title_label.add_theme_font_size_override("font_size", 44)
		status.add_theme_font_size_override("font_size", 36)
		status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		help.add_theme_font_size_override("font_size", 27)
		result_label.add_theme_font_size_override("font_size", 44)
	result.size = Vector2(minf(800, s.x - 48), 420)
	result.position = (s - result.size) / 2

func update_stats(robot_name: String, remaining: float, score: int, total: int, best: Dictionary, demo: bool) -> void:
	var record := "尚無紀錄"
	if best.get("score", -1) >= 0:
		record = "%d 顆／%.1f 秒" % [best.score, best.elapsed]
	status.text = "%s%s　剩餘 %02d 秒\n能量 %d／%d　｜　最佳 %s" % [robot_name, "〔示範〕" if demo else "", ceili(remaining), score, total, record]

func finish(score: int, total: int, elapsed: float, record: bool) -> void:
	result_label.text = "%s\n收集 %d／%d 顆能量\n用了 %.1f 秒\n%s" % ["任務完成！" if score == total else "時間到！再挑戰一次", score, total, elapsed, "恭喜！刷新最佳紀錄" if record else "每次探索都會更進步"]
	result.show()
	layout()

# ??????????????????????????
func _input(event: InputEvent) -> void:
	if not event is InputEventScreenTouch or not event.pressed or not root: return
	var buttons: Array = [again] if result.visible else [horn_button, reset_button, camera_button]
	for b in buttons:
		if b.get_global_rect().has_point(event.position):
			b.pressed.emit()
			get_viewport().set_input_as_handled()
			return
