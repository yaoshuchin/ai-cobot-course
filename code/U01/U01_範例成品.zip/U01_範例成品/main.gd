extends Node3D
# 主流程：讀取設定、建場地、計時記分與紀錄；測試和示範也使用同一套移動及收集程式。
const Robot = preload("res://robot.gd")
const Arena = preload("res://arena.gd")
const Hud = preload("res://hud.gd")
const ROBOT_DEFAULT := {"name":"小藍", "body":"car", "body_color":"#2E86FF", "accent_color":"#FFD166", "eye_color":"#FFFFFF", "size":1.0, "max_speed":6.0, "turn_speed":2.6, "headlight":true, "trail":{"show":true,"color":"#FFB703","width":0.25,"rainbow":false,"length":120}}
const GAME_DEFAULT := {"title":"機器人遊樂場","time_limit":60,"cube_color":"#00F5D4","sky_top":"#5AA9FF","sky_bottom":"#E8F4FF","floor_color_a":"#DDE6F0","floor_color_b":"#C9D6E3","wall_color":"#3D5A80","camera_distance": 3.4, "camera_height": 2.6, "camera_target_height": 1.0, "camera_fov": 90.0, "ambient_energy": 0.4, "sun_energy": 0.7, "exposure": 0.9, "cube_emission": 4.0, "collect_flash_size": 0.4}
const DEFAULT_MAP := "################\n#R....*....~~..#\n#.###....*.~~..#\n#.#...^........#\n#.#..####..*...#\n#*...#..#......#\n#....#*.#..^...#\n#..*.......###.#\n#.......*....*.#\n################"
var warnings: Array[String] = []
var robot_cfg: Dictionary
var game_cfg: Dictionary
var map_lines: Array[String] = []
var arena: Node3D
var robot: CharacterBody3D
var hud: CanvasLayer
var camera: Camera3D
var elapsed := 0.0
var score := 0
var ended := false
var overhead := false
var best: Dictionary = {}
var records: Dictionary = {}
var challenge := ""
var demo := false
var self_test := false
var demo_path: Array[Vector3] = []
var demo_target: Node3D
var stuck_time := 0.0
var previous_pos := Vector3.ZERO

# ???????????????????????????
func decode_json(text: String):
	var parser := JSON.new()
	return parser.data if parser.parse(text) == OK else null

func read_json(path: String, defaults: Dictionary) -> Dictionary:
	var parsed = decode_json(FileAccess.get_file_as_string(path).trim_prefix("\ufeff")) if FileAccess.file_exists(path) else null
	if not parsed is Dictionary:
		warnings.append("%s 無法讀取，已使用預設設定。" % path.get_file())
		parsed = {}
	return merge_settings(parsed, defaults, path.get_file())

func merge_settings(data: Dictionary, defaults: Dictionary, prefix: String) -> Dictionary:
	var result := defaults.duplicate(true)
	for key in defaults:
		var field: String = prefix + "." + key
		if not data.has(key):
			warnings.append("%s 缺少設定，已使用預設值。" % field)
			continue
		var val = data[key]
		var ref = defaults[key]
		if ref is Dictionary:
			if val is Dictionary: result[key] = merge_settings(val, ref, field)
			else: warnings.append("%s 格式有誤，已使用預設值。" % field)
			continue
		var valid := typeof(val) == typeof(ref) or ((val is float or val is int) and (ref is float or ref is int))
		if key.ends_with("color") or key in ["sky_top", "sky_bottom", "floor_color_a", "floor_color_b"]:
			valid = val is String and Color.html_is_valid(val)
		if key == "body": valid = val in ["car", "round", "tank", "ufo"]
		var ranges := {"size":[0.5,2],"max_speed":[2,15],"turn_speed":[1,6],"width":[0.05,0.6],"length":[10,500],"time_limit":[1,3600],"camera_distance":[2,12],"camera_height":[1.5,10],"camera_target_height":[0.5,2],"camera_fov":[60,110],"ambient_energy":[0.1,2],"sun_energy":[0.1,2],"exposure":[0.5,2],"cube_emission":[1,8],"collect_flash_size":[0.1,1]}
		if ranges.has(key):
			valid = (val is float or val is int) and val >= ranges[key][0] and val <= ranges[key][1]
		if valid: result[key] = val
		else: warnings.append("%s 設定無效，已使用預設值。" % field)
	return result

func load_map() -> void:
	var text := FileAccess.get_file_as_string("res://arena.txt").trim_prefix("\ufeff").strip_edges() if FileAccess.file_exists("res://arena.txt") else ""
	if text.is_empty():
		warnings.append("arena.txt 無法讀取，已使用範例地圖。")
		text = DEFAULT_MAP
	var lines := text.split("\n", false)
	var width := 0
	for line in lines: width = maxi(width, line.strip_edges().length())
	if width < 3 or lines.size() < 3 or width > 100 or lines.size() > 100:
		warnings.append("arena.txt 地圖大小有誤，已使用範例。")
		lines = DEFAULT_MAP.split("\n")
		width = 16
	var starts := 0
	for z in lines.size():
		var line := lines[z].strip_edges()
		if line.length() < width:
			warnings.append("arena.txt 第 %d 列長度不足，已補齊地板。" % (z + 1))
			line = line.left(-1) + ".".repeat(width - line.length()) + line.right(1) if line.ends_with("#") else line + ".".repeat(width - line.length())
		var fixed := ""
		for x in width:
			var ch := line[x]
			if not ch in ["#", ".", "R", "*", "~", "^"]:
				warnings.append("arena.txt 有未知符號，已改成地板。")
				ch = "."
			if z == 0 or z == lines.size() - 1 or x == 0 or x == width - 1:
				if ch != "#": warnings.append("arena.txt 外圈缺牆，已補上。")
				ch = "#"
			if ch == "R": starts += 1
			fixed += ch
		map_lines.append(fixed)
	if starts != 1:
		warnings.append("arena.txt 必須有一個起點，已使用範例地圖。")
		map_lines.clear()
		map_lines.assign(DEFAULT_MAP.split("\n"))

func responsive_view() -> void:
	var actual := get_window().size
	get_window().content_scale_size = Vector2i(720, 900) if actual.x < actual.y else Vector2i(1600, 900)

func _ready() -> void:
	responsive_view()
	get_window().size_changed.connect(responsive_view)
	self_test = "--self-test" in OS.get_cmdline_user_args()
	demo = "--demo" in OS.get_cmdline_user_args()
	robot_cfg = read_json("res://robot.json", ROBOT_DEFAULT)
	game_cfg = read_json("res://game.json", GAME_DEFAULT)
	load_map()
	arena = Arena.new()
	add_child(arena)
	arena.setup(map_lines, game_cfg)
	robot = Robot.new()
	add_child(robot)
	robot.setup(robot_cfg)
	robot.position = arena.start
	robot.rotation.y = -PI / 2
	previous_pos = robot.position
	challenge = ("\n".join(map_lines) + str(game_cfg.time_limit)).sha256_text()
	if FileAccess.file_exists("user://best.json"):
		var data = decode_json(FileAccess.get_file_as_string("user://best.json"))
		if data is Dictionary: records = data
	var saved = records.get(challenge, {})
	if saved is Dictionary and saved.get("score") is float and saved.get("elapsed") is float: best = saved
	if self_test:
		run_self_test.call_deferred()
		return
	build_world()
	hud = Hud.new()
	add_child(hud)
	hud.setup(game_cfg.title, warnings)
	hud.restart.connect(restart)
	hud.horn.connect(robot.honk)
	hud.camera_toggle.connect(func(): overhead = not overhead)
	if arena.cube_total == 0: finish()

# 藍天、亮度與近距離後方跟隨鏡頭都從 game.json 讀取。
func build_world() -> void:
	var env_node := WorldEnvironment.new()
	env_node.name = "WorldEnvironment"
	var env := Environment.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(game_cfg.sky_top)
	sky_mat.sky_curve = 0.7
	sky_mat.sky_energy_multiplier = 1.0
	sky_mat.ground_bottom_color = Color(game_cfg.sky_bottom)
	sky_mat.ground_curve = 0.7
	sky_mat.sky_horizon_color = Color(game_cfg.sky_bottom).lerp(Color(game_cfg.sky_top), 0.65)
	sky_mat.ground_horizon_color = Color(game_cfg.sky_bottom)
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("c7e5ff")
	env.ambient_light_energy = game_cfg.ambient_energy
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	env.tonemap_exposure = game_cfg.exposure
	env.fog_enabled = true
	env.fog_light_color = Color(game_cfg.sky_bottom)
	env.fog_density = 0.002
	env.fog_sky_affect = 0.0
	env_node.environment = env
	add_child(env_node)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_color = Color("fff1d6")
	sun.light_energy = game_cfg.sun_energy
	sun.shadow_enabled = true
	add_child(sun)
	camera = Camera3D.new()
	camera.fov = game_cfg.camera_fov
	camera.far = 180
	add_child(camera)
	camera.position = robot.position + robot.transform.basis.z * game_cfg.camera_distance + Vector3(0, game_cfg.camera_height, 0)
	camera.look_at(robot.position + Vector3.UP * game_cfg.camera_target_height)
	camera.current = true

func input_axes() -> Vector2:
	var throttle := float(Input.is_physical_key_pressed(KEY_UP) or Input.is_physical_key_pressed(KEY_W)) - float(Input.is_physical_key_pressed(KEY_DOWN) or Input.is_physical_key_pressed(KEY_S))
	var steer := float(Input.is_physical_key_pressed(KEY_RIGHT) or Input.is_physical_key_pressed(KEY_D)) - float(Input.is_physical_key_pressed(KEY_LEFT) or Input.is_physical_key_pressed(KEY_A))
	if hud.stick.value.length() > 0.08:
		throttle = -hud.stick.value.y
		steer = hud.stick.value.x
	return Vector2(throttle, steer)

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_R: restart()
		if event.physical_keycode == KEY_SPACE and robot: robot.honk()
		if event.physical_keycode == KEY_TAB: overhead = not overhead

func _physics_process(delta: float) -> void:
	if self_test or not hud: return
	if not ended:
		elapsed = minf(elapsed + delta, game_cfg.time_limit)
		var axes := demo_axes(delta) if demo else input_axes()
		robot.drive(delta, axes.x, axes.y, arena.terrain(robot.position))
		for cube in arena.cubes.duplicate():
			if Vector2(cube.position.x, cube.position.z).distance_to(Vector2(robot.position.x, robot.position.z)) < 0.95:
				collect_cube(cube)
		if score == arena.cube_total or elapsed >= game_cfg.time_limit: finish()
	var target: Vector3 = robot.position + Vector3.UP * game_cfg.camera_target_height
	var desired: Vector3 = robot.position + (Vector3(0, 28, 0.05) if overhead else robot.transform.basis.z * game_cfg.camera_distance + Vector3(0, game_cfg.camera_height, 0))
	camera.position = camera.position.lerp(desired, 1 - exp(-delta * 4))
	camera.look_at(target)
	hud.update_stats(robot_cfg.name, game_cfg.time_limit - elapsed, score, arena.cube_total, best, demo)

func collect_cube(cube: Node3D) -> void:
	arena.collect(cube)
	score += 1

func finish() -> void:
	ended = true
	var record: bool = score > best.get("score", -1) or (score == best.get("score", -1) and elapsed < best.get("elapsed", INF))
	if record:
		best = {"score": score, "elapsed": elapsed}
		if not demo:
			records[challenge] = best
			var file := FileAccess.open("user://best.json", FileAccess.WRITE)
			if file: file.store_string(JSON.stringify(records))
			else: hud.warnings_label.text += "\n最佳紀錄無法儲存，請確認瀏覽器儲存權限。"
	hud.finish(score, arena.cube_total, elapsed, record)

func restart() -> void:
	get_tree().reload_current_scene()

# 廣度優先尋路能繞開牆；自動駕駛仍透過與學生相同的 drive 移動。
func grid(pos: Vector3) -> Vector2i:
	return Vector2i(roundi(pos.x / 2 + arena.width / 2.0), roundi(pos.z / 2 + arena.height / 2.0))

func path_to(target: Vector3) -> Array[Vector3]:
	var origin := grid(robot.position)
	var goal := grid(target)
	var queue: Array[Vector2i] = [origin]
	var visited := {origin: origin}
	var index := 0
	while index < queue.size():
		var p := queue[index]
		index += 1
		if p == goal: break
		for d in [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]:
			var n: Vector2i = p + d
			if n.x < 0 or n.y < 0 or n.x >= arena.width or n.y >= arena.height: continue
			if map_lines[n.y][n.x] == "#" or visited.has(n): continue
			visited[n] = p
			queue.append(n)
	var path: Array[Vector3] = []
	if not visited.has(goal): return path
	var current := goal
	while current != origin:
		path.push_front(arena.cell_pos(current.x, current.y))
		current = visited[current]
	return path

func demo_axes(delta: float) -> Vector2:
	if not is_instance_valid(demo_target) or not arena.cubes.has(demo_target):
		var nearest := INF
		for cube in arena.cubes:
			var path := path_to(cube.position)
			if path.size() < nearest:
				nearest = path.size()
				demo_target = cube
				demo_path = path
	while not demo_path.is_empty() and robot.position.distance_to(demo_path[0]) < 0.35: demo_path.pop_front()
	if demo_path.is_empty(): return Vector2.ZERO
	var direction := (demo_path[0] - robot.position).normalized()
	var angle := (-robot.transform.basis.z).signed_angle_to(direction, Vector3.UP)
	stuck_time = stuck_time + delta if robot.position.distance_to(previous_pos) < 0.003 and absf(robot.speed) > 0.5 else 0.0
	previous_pos = robot.position
	if stuck_time > 0.8:
		if stuck_time > 1.3:
			stuck_time = 0
			demo_path = path_to(demo_target.position)
		return Vector2(-0.5, 0.6)
	return Vector2(clampf(1 - absf(angle) * 1.8, 0, 0.85), clampf(-angle * 2.5, -1, 1))

func run_self_test() -> void:
	var failures: Array[String] = []
	if not warnings.is_empty(): failures.append("設定：" + "；".join(warnings))
	if arena.width != map_lines[0].length() or arena.height != map_lines.size(): failures.append("地圖尺寸")
	if arena.starts != 1: failures.append("起點")
	var expected := 0
	for row in map_lines: expected += row.count("*")
	if expected != arena.cubes.size(): failures.append("方塊數量")
	var initial := robot.position
	for i in 30:
		await get_tree().physics_frame
		robot.drive(1.0 / 60, 1, 0, ".")
	if initial.distance_to(robot.position) < 0.1: failures.append("移動未改變位置")
	if not arena.cubes.is_empty():
		var before := score
		collect_cube(arena.cubes[0])
		if score != before + 1 or arena.cubes.size() != expected - 1: failures.append("收集計分")
	else: failures.append("無方塊可測")
	if failures.is_empty():
		print("SELF_TEST PASS 設定檔、地圖 %d×%d、起點、%d 個方塊、實際物理移動、收集分數 +1" % [arena.width, arena.height, expected])
	else: print("SELF_TEST FAIL " + "；".join(failures))
	await get_tree().create_timer(0.5).timeout
	get_tree().quit(0 if failures.is_empty() else 1)
