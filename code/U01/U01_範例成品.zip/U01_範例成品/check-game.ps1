﻿. (Join-Path $PSScriptRoot 'prepare-runtime.ps1')
& (Join-Path $PSScriptRoot 'u01-robot-playground\scripts\檢查.ps1') -Project $PSScriptRoot
exit $LASTEXITCODE
