extends CharacterBody3D
# 小車的所有外觀由設定建立，移動時沿用物理碰撞。
var cfg: Dictionary
var shell: Node3D
var beacon: MeshInstance3D
var speed := 0.0
var hopping := 0.0
var boosted := 0.0
var last_trail := Vector3.INF
var tracks: Array[Node3D] = []
var audio_player: AudioStreamPlayer

func shape(parent: Node3D, mesh: Mesh, pos: Vector3, color: Color, glow := false) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = mesh
	n.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.55
	if glow:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 2.0
	n.material_override = mat
	parent.add_child(n)
	return n

func box(parent: Node3D, pos: Vector3, size_v: Vector3, col: Color, glow := false) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size_v
	return shape(parent, mesh, pos, col, glow)

func ball(parent: Node3D, pos: Vector3, radius: float, col: Color, glow := false) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2
	return shape(parent, mesh, pos, col, glow)

func setup(data: Dictionary) -> void:
	cfg = data
	collision_layer = 2
	collision_mask = 1
	var collider := CollisionShape3D.new()
	var cs := SphereShape3D.new()
	cs.radius = 0.52 * cfg.size
	collider.shape = cs
	collider.position.y = 0.52
	add_child(collider)
	shell = Node3D.new()
	add_child(shell)
	shell.scale = Vector3.ONE * cfg.size
	var blue := Color(cfg.body_color)
	var accent := Color(cfg.accent_color)
	match cfg.body:
		"round": ball(shell, Vector3(0, 0.65, 0), 0.64, blue)
		"ufo":
			var disc := CylinderMesh.new()
			disc.top_radius = 0.65
			disc.bottom_radius = 0.8
			disc.height = 0.23
			shape(shell, disc, Vector3(0, 0.65, 0), blue)
			ball(shell, Vector3(0, 0.85, 0), 0.35, accent)
		_:
			box(shell, Vector3(0, 0.5, 0), Vector3(1.05, 0.5, 1.4), blue)
			box(shell, Vector3(0, 0.86, -0.13), Vector3(0.85, 0.33, 0.72), blue.lightened(0.15))
	box(shell, Vector3(0, 0.63, -0.74), Vector3(0.88, 0.18, 0.1), accent)
	for side in [-1, 1]:
		if cfg.body == "tank":
			box(shell, Vector3(side * 0.59, 0.3, 0), Vector3(0.3, 0.45, 1.6), Color("293449"))
		for z in [-0.46, 0.46]:
			var wheel := CylinderMesh.new()
			wheel.top_radius = 0.29
			wheel.bottom_radius = 0.29
			wheel.height = 0.24
			var w := shape(shell, wheel, Vector3(side * 0.57, 0.29, z), Color("26344a"))
			w.rotation.z = PI / 2
			ball(shell, Vector3(side * 0.71, 0.29, z), 0.11, accent)
		ball(shell, Vector3(side * 0.23, 1.0, -0.47), 0.145, Color(cfg.eye_color), true)
		ball(shell, Vector3(side * 0.23, 1.025, -0.59), 0.065, Color("16334f"))
		box(shell, Vector3(side * 0.33, 0.55, 0.72), Vector3(0.2, 0.12, 0.05), Color("ff5266"), true)
	box(shell, Vector3(0, 1.2, 0.1), Vector3(0.045, 0.5, 0.045), accent)
	beacon = ball(shell, Vector3(0, 1.48, 0.1), 0.12, accent, true)
	if cfg.headlight:
		var light := SpotLight3D.new()
		light.position = Vector3(0, 0.8, -0.7)
		light.rotation.x = -0.3
		light.spot_range = 12
		light.spot_angle = 36
		light.light_color = Color("fff2bc")
		light.light_energy = 2
		shell.add_child(light)
	audio_player = AudioStreamPlayer.new()
	var stream := AudioStreamGenerator.new()
	stream.mix_rate = 22050
	stream.buffer_length = 0.3
	audio_player.stream = stream
	add_child(audio_player)

func drive(delta: float, throttle: float, steer: float, terrain: String) -> void:
	boosted = maxf(0, boosted - delta)
	if terrain == "^": boosted = 2.0
	var factor := 0.5 if terrain == "~" else (1.5 if boosted > 0 else 1.0)
	speed = move_toward(speed, throttle * cfg.max_speed * factor, delta * 12)
	rotate_y(-steer * cfg.turn_speed * delta)
	velocity = -transform.basis.z * speed
	move_and_slide()
	shell.rotation.z = lerpf(shell.rotation.z, steer * speed * 0.025, delta * 8)
	hopping = maxf(0, hopping - delta)
	shell.position.y = sin(hopping / 0.5 * PI) * 0.6
	if cfg.body == "ufo": shell.position.y += 0.18 + sin(Time.get_ticks_msec() * 0.004) * 0.08
	beacon.scale = Vector3.ONE * (0.85 + sin(Time.get_ticks_msec() * 0.006) * 0.15)
	if cfg.trail.show and position.distance_to(last_trail) > 0.28:
		var col := Color(cfg.trail.color)
		if cfg.trail.rainbow: col = Color.from_hsv(fmod(Time.get_ticks_msec() / 4000.0, 1), 0.8, 1)
		var mark := box(get_parent(), Vector3(position.x, 0.028, position.z), Vector3(cfg.trail.width, 0.018, 0.36), col, true)
		mark.rotation.y = rotation.y
		tracks.append(mark)
		last_trail = position
		if tracks.size() > cfg.trail.length: tracks.pop_front().queue_free()

func honk() -> void:
	hopping = 0.5
	audio_player.play()
	var playback := audio_player.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback:
		for i in range(4410):
			var sample := sin(TAU * 660 * i / 22050.0) * 0.18 * (1 - i / 4410.0)
			playback.push_frame(Vector2(sample, sample))
