﻿. (Join-Path $PSScriptRoot 'prepare-runtime.ps1')
& (Join-Path $PSScriptRoot 'u01-robot-playground\scripts\匯出網頁版.ps1') -Project $PSScriptRoot -NoServe
exit $LASTEXITCODE
