﻿# 檔案要經由本機網址開啟，不能直接雙擊 index.html。
try {
    $response = Invoke-WebRequest 'http://localhost:8060/' -UseBasicParsing -TimeoutSec 2
    if ($response.Content -match '機器人遊樂場') {
        Start-Process 'http://localhost:8060/'
        exit 0
    }
} catch {}
& (Join-Path $PSScriptRoot 'u01-robot-playground\scripts\本機測試網頁版.ps1') -Dir (Join-Path $PSScriptRoot '網頁版')
