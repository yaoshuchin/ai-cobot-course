﻿# 只在本專案建立測試環境，不變更系統或技能包設定。
$originalAppData = $env:APPDATA
$env:APPDATA = Join-Path $PSScriptRoot '.runtime'
$localGodot = Join-Path $env:APPDATA 'Godot'
New-Item -ItemType Directory -Force $localGodot | Out-Null
$certPath = (Join-Path $PSScriptRoot 'local-ca-bundle.crt').Replace('\','/')
$settings = "[gd_resource type=`"EditorSettings`" format=3]`n`n[resource]`nnetwork/tls/editor_tls_certificates = `"$certPath`"`nnetwork/connection/check_for_updates = 0`n"
[IO.File]::WriteAllText((Join-Path $localGodot 'editor_settings-4.7.tres'),$settings,(New-Object Text.UTF8Encoding($false)))
$templateRoot = Join-Path $localGodot 'export_templates\4.7.2.stable'
New-Item -ItemType Directory -Force $templateRoot | Out-Null
$g = & (Join-Path $PSScriptRoot 'u01-robot-playground\scripts\找Godot.ps1') -Project $PSScriptRoot
if ($g) {
    $zipPath = Join-Path (Split-Path $g -Parent) 'web_nothreads_release.zip'
    if (-not (Test-Path (Join-Path $templateRoot 'web_nothreads_release.zip'))) {
        if (Test-Path $zipPath) { Copy-Item -LiteralPath $zipPath -Destination $templateRoot }
        else {
            $installed = Join-Path $originalAppData 'Godot\export_templates\4.7.2.stable\web_nothreads_release.zip'
            if (Test-Path $installed) { Copy-Item -LiteralPath $installed -Destination $templateRoot }
        }
    }
}
