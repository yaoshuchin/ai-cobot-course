﻿# 不用安裝任何東西的本機網頁伺服器（只給自己電腦看）：http://localhost:8060/
param([string]$Dir = '.\網頁版', [int]$Port = 8060)
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$root = (Resolve-Path -LiteralPath $Dir).Path
$mime = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'application/javascript'; '.wasm' = 'application/wasm'; '.pck' = 'application/octet-stream';
           '.png' = 'image/png'; '.json' = 'application/json'; '.css' = 'text/css'; '.ico' = 'image/x-icon'; '.svg' = 'image/svg+xml' }
$h = New-Object System.Net.HttpListener
$h.Prefixes.Add("http://localhost:$Port/")
$h.Start()
$Host.UI.RawUI.WindowTitle = "本機測試網頁版 http://localhost:$Port/"
Write-Host "本機測試網址：http://localhost:$Port/   （要停止就關掉這個視窗）" -ForegroundColor Green
Start-Process "http://localhost:$Port/"
while ($h.IsListening) {
    $c = $h.GetContext()
    $p = [Uri]::UnescapeDataString($c.Request.Url.AbsolutePath.TrimStart('/'))
    if ($p -eq '') { $p = 'index.html' }
    $f = Join-Path $root $p
    if ((Test-Path -LiteralPath $f -PathType Leaf) -and ([IO.Path]::GetFullPath($f).StartsWith($root))) {
        $b = [IO.File]::ReadAllBytes($f)
        $ext = [IO.Path]::GetExtension($f).ToLower()
        $c.Response.ContentType = $(if ($mime[$ext]) { $mime[$ext] } else { 'application/octet-stream' })
        $c.Response.OutputStream.Write($b, 0, $b.Length)
    } else { $c.Response.StatusCode = 404 }
    $c.Response.Close()
}
