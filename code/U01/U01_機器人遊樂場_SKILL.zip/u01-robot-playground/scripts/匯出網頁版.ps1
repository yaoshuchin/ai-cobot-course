﻿# 把 Godot 專案匯出成網頁版（專案資料夾裡的「網頁版\」），再開本機測試網址
param([string]$Project = '.', [switch]$NoServe)
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$proj = (Resolve-Path -LiteralPath $Project).Path
$godot = & (Join-Path $PSScriptRoot '找Godot.ps1') -Project $proj
if (-not $godot) { Write-Host '找不到 Godot' -ForegroundColor Red; exit 1 }
$ver = (& $godot --version 2>$null | Select-Object -First 1) -replace '^(\d+\.\d+(\.\d+)?)\.(\w+).*$', '$1.$3'
$tpl = Join-Path $env:APPDATA "Godot\export_templates\$ver"
if (-not (Test-Path (Join-Path $tpl 'web_nothreads_release.zip'))) {
    # 課程網站提供的「網頁匯出元件」放在 Godot 資料夾旁邊就自動安裝
    $zip = Get-ChildItem -LiteralPath (Split-Path $godot -Parent) -Filter 'web_nothreads_release.zip' -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $zip) { Write-Host "缺少網頁匯出元件：請到課程網站下載「Godot網頁匯出元件.zip」，解壓縮到 $(Split-Path $godot -Parent)" -ForegroundColor Red; exit 1 }
    New-Item -ItemType Directory -Force $tpl | Out-Null
    Copy-Item $zip.FullName $tpl
    Set-Content (Join-Path $tpl 'version.txt') $ver -NoNewline
    Write-Host "已安裝網頁匯出元件到 $tpl"
}
if (-not (Test-Path (Join-Path $proj 'export_presets.cfg'))) { Copy-Item (Join-Path $PSScriptRoot '..\assets\export_presets.cfg') $proj }
$outDir = Join-Path $proj '網頁版'
New-Item -ItemType Directory -Force $outDir | Out-Null
Set-Content (Join-Path $outDir '.gdignore') '' -NoNewline   # 讓 Godot 不要把網頁版當成專案素材
$log = & $godot --headless --path $proj --export-release 'Web' (Join-Path $outDir 'index.html') 2>&1 | ForEach-Object { "$_" }
if (-not (Test-Path (Join-Path $outDir 'index.wasm'))) { Write-Host '匯出失敗：' -ForegroundColor Red; $log | Select-Object -Last 15; exit 1 }
Write-Host "匯出完成：$outDir" -ForegroundColor Green
Get-ChildItem $outDir | ForEach-Object { '  {0,-34} {1,10:N0} bytes' -f $_.Name, $_.Length }
if (-not $NoServe) {
    Start-Process powershell -ArgumentList '-NoExit', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot '本機測試網頁版.ps1'), '-Dir', $outDir
    Write-Host '已開啟本機測試伺服器：http://localhost:8060/ （關掉那個黑色視窗就停止）'
}
