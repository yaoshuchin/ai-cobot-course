﻿# 找出 Godot 執行檔（給其他腳本用）：回傳「主控台版」路徑，找不到回傳空字串
param([string]$Project = '.')
$proj = (Resolve-Path -LiteralPath $Project).Path
$dirs = @()
if ($env:GODOT) { $dirs += $env:GODOT }
$dirs += (Join-Path (Split-Path $proj -Parent) 'Godot')
foreach ($d in $dirs) {
    if (Test-Path -LiteralPath $d -PathType Leaf) { $d = Split-Path $d -Parent }
    if (-not (Test-Path -LiteralPath $d)) { continue }
    $c = Get-ChildItem -LiteralPath $d -Filter 'Godot_v4*_console.exe' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
    if ($c) { return $c.FullName }
}
return ''
