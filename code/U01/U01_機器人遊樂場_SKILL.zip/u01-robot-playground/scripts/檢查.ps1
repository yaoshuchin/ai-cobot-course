﻿# 檢查 Godot 專案：1 匯入資源 2 啟動有沒有錯 3 自我測試。最後印出「全部通過」才算完成。
param([string]$Project = '.')
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$proj = (Resolve-Path -LiteralPath $Project).Path
$godot = & (Join-Path $PSScriptRoot '找Godot.ps1') -Project $proj
if (-not $godot) { Write-Host '找不到 Godot：請把 Godot 解壓縮到練習資料夾旁邊的 Godot 資料夾' -ForegroundColor Red; exit 1 }
Write-Host "Godot：$godot"
$bad = 'SCRIPT ERROR|Parse Error|ERROR:|Failed to load'
$steps = @(
    @{ n = '1 匯入資源'; a = @('--headless', '--path', $proj, '--import') },
    @{ n = '2 啟動檢查'; a = @('--headless', '--path', $proj, '--quit-after', '180') },
    @{ n = '3 自我測試'; a = @('--headless', '--path', $proj, '--', '--self-test') }
)
$ok = $true
foreach ($s in $steps) {
    $out = & $godot @($s.a) 2>&1 | ForEach-Object { "$_" }
    $err = $out | Where-Object { $_ -match $bad }
    if ($s.n -like '3*') {
        $line = $out | Where-Object { $_ -match 'SELF_TEST' } | Select-Object -Last 1
        if ($line -match 'SELF_TEST PASS' -and -not $err) { Write-Host "[通過] $($s.n)：$line" -ForegroundColor Green }
        else { $ok = $false; Write-Host "[失敗] $($s.n)：$line" -ForegroundColor Red; $err | Select-Object -First 15 | ForEach-Object { Write-Host "  $_" } }
    } elseif ($err) {
        $ok = $false; Write-Host "[失敗] $($s.n)" -ForegroundColor Red; $err | Select-Object -First 15 | ForEach-Object { Write-Host "  $_" }
    } else { Write-Host "[通過] $($s.n)" -ForegroundColor Green }
}
if ($ok) { Write-Host '全部通過' -ForegroundColor Green; exit 0 } else { Write-Host '還有錯誤，請修正後再檢查一次' -ForegroundColor Yellow; exit 1 }
